<?php
class Datalogic{
	public $FS;
	public $QS;
	public $FOPS;
	public $FFlow;
	public $FCurr;
	public $_FV; //Form value
	public $HaveData=false;
	public $ShowData=false;
	public $MISC_DATA;
	public $WID_DATA;
	public $DELETED_DATA;
	public $Ajax = false;
	
	public $FORM_ERROR=false; //true: has error ; false: no error
	public $_ERROR; //for error tracking Eg. $_ERROR[b.3a.1][name.#1]='some error message'
	public $FORM_DISPLAY=true;
	
	public $Database; //DB object
	public $Login; //Login objects
	public $Settings; //Login objects
	
	public $_D; //data array
	public $_STORED_DATA; //storing and allow user to access stored data.
	public $_DEL; //deletion data array
	public $DEL_START_KEY; //start key for deletion
	public $_DELETE_U= false; //doest not delete, set status=QS[_valueEB][DEL.Status]
	public $INT_COUNTER=0;
	private $temp_arr; //used internally by process column information
	public $QUERY_SETTINGS=array(
		//query: qs name
		"table"=>"_table",
		"params"=>"_params", 
		"colnames"=>"_colnames",
		"strFilter"=>"_filter", 
		"strGroup"=>"_group", 
		"strOrder"=>"_order", 
		"strULimit"=>"_ulimit" , 
		"strLLimit"=>"_llimit",
		"keyID"=>"_keyID",
		"filtercols"=>"_filtercols",
		/*QS OPS related*/
		"ops_return"=>"_ops_return"
	);
	public $FS_AJAX_PROCESS_FSID;
	public $FS_AJAX_PROCESS_FSID_FINAL;
	public $FS_AJAX_ERROR_ID;
	public $FS_AJAX_POST_DATA;
	
	//use for general query initialisations
	public $QUERY_PARAMS; //query parameters
	
	//Diagnostics settings
	public $_D_DIA=false;
	public $FV_DIA=false;
	public $QUERY_DIA=false; //display SELECT details
	public $DEL_DETAILS=false;
	public $DEL_SIMU=false; //true to simulate delete and will block actual delete ops
	public $UPDATE_DIA=false;
	public $INSERT_DIA=false;
	public $INSERT_SIMU=false; //true to simulate insert and will block actual insert ops
	public $RETRIEVE_DIA=false;
	public $FS_RUN_DIA=false;
	public $FS_RUNNER_DIA=false;
	public $FS_input_info_DIA=false;
	public $SHOW_MISC_DATA=false;
	public $SHOW_POST = false;
	public $OPS;

	
	
	
	//MISC TEST SETTINGS
	public $FS_TEST=array(); //unit test FS
	public $TEST_DIV='<div class="_DIA">';
	public $RED_DIV='<div class="_DIA_red">';
	public $BLUE_DIV='<div class="_DIA_blue">';
	private $DIA_LINE='<br>****************************************************<br>';
	
/*
****************************************************
Main Methods
****************************************************
*/

	public function _print_post_fv(){
		_echo ('<h1>_POST</h1>'); _print_r($_POST);
		_echo ('<h1>_FV</h1>'); _print_r($this->_FV);		
	}	
	/*
	****************************************************
	Retrieve data from db, _POST and FS settings
	****************************************************
	*/	
	public function _FORM_RETRIEVE_MAIN( $FStatus='Initial_Load') { 
	_E_TRACE( 'datalogic._FORM_RETRIEVE_MAIN()');	
	//1) POPULATE RUN BASED ON DB
		//Using DB values to drive _FV generations ensures all relevant values defined in QS are printed
		//$this->HaveData is set in fs_ini.php
		if($this->HaveData===true ) { 
			$this->_FORM_DB_run( $FStatus ); //echo 'db run';
			if($this->_D_DIA){
				echo '<h1>this->D</h1>';
				_print_r($this->_D);
			} 
				
		} 
		//_echo('<h1>_FORM_RETRIEVE_MAIN _D</h1>');
		//_print_r($this->_D);
	//2) POPULATE RUN BASED ON $_POST
		//Modifies the form with posted values
		//_echo ('<h1>_FORM_POST_run()._FORM_RETRIEVE_MAIN()</h1>');_print_r($_POST);
		if(isset($_POST)) $this->_FORM_POST_run();
		
		//print_r($this->_FV);
	//3) POPULATE RUN BASED ON FS
		//The last line of generation is driven by FS array. As such in a form without database or any data posted, this will be used to generate form with empty or default values.
		if(isset($this->FS) ) { 
			$this->_FORM_FS_run();
			
		} else {
			//echo $this->RED_DIV; echo 'Error: No FS defined'; echo '</div>';
		}
		//_print_r($this->_FV);
	if($this->FV_DIA) { echo '<hr>'; echo '<h2>_FV._FORM_RETRIEVE_MAIN.datalogic</h2>'; _print_r($this->_FV); }
	
	//FORM reference DELETED PARAMS
	$this->_FORM_DELETE_PARAM();
	
	//4) RETRIEVE DB RELATED INFORMATION	
	$this->_FORM_DB_get_misc_data(); //for main form
		
	$this->_FORM_SEARCH_FILTER_get_misc_data(); //for form filter
	$this->_WIDGET_get_data(); //for widget
	
	}//_FORM_RETRIEVE_MAIN


/*
****************************************************
Sub Methods for _FORM_RETRIEVE_MAIN
****************************************************
*/

	
	private function _FORM_FS_run(){ 
		$FS=$this->FS;
		$_FV_t=$this->_FV;
		//_print_r($this->_FV);		
			
		
		foreach( array_keys($FS) as $datagrpInfo ){
			
			$datagrp_arr=explode('.',$datagrpInfo);
			$datagrp=$datagrp_arr[0];
			
			if($this->FS_RUN_DIA) echo '<h1>',$datagrp,'</h1>';
			//_echo('<h1>datagrpInfo-->'.$datagrpInfo.'</h1>');
			foreach(array_keys($FS[$datagrpInfo]) as $input_infos){ 
				//echo('input_infos-->'.$input_infos.'<br>');
				//FS[$datagrpInfo][input_infos]
				//FS[a][Title], FS[a.4b.1][Item.2.2.2]
				
				$arr_t=explode('.',$input_infos);
				//_print_r($arr_t);
				$arr_size=sizeof($arr_t); //if arr_size >1 ==> nested else non nested
				
				if($arr_size>1){
					//Nested
					//_echo('Nested<br>');
					$tier_info=str_replace($arr_t[0].'.','', $input_infos);
				} else {
					//Non nested
					//_echo('NON-Nested<br>');
					$tier_info='';
				}
				
				//processed tiered info
				$temp_arr='';
				if($tier_info!=''){
					$this->_FORM_FS_RUNNER($tier_info); //populates temp_arr
					$temp_arr=$this->temp_arr;
					//print_r($temp_arr);
				}
				
						
				//Get initial value to populate for the input
				$valueFS=$this->_FS_INI_VALUE($FS[$datagrpInfo][$input_infos]); //_E_TRACE($valueFS,true);
				
				
				
				//LOOP THRU temp_arr to form input_info
				/**************************************/
				$lvl_info='';
				$input_info='';

				if($arr_size>1){
					//NESTED
					//_echo($datagrpInfo.' is NESTED<br>');
					$this->DATA_INFO[ $datagrpInfo ][ 'nested' ] = true; //SET AS NESTED
					foreach($temp_arr as $lvl_info){ //echo  'lvl_info: ',$lvl_info,'<br>';
						
						//form input_info..
						$lvl_info= $lvl_info!='' ?  '.'.$lvl_info : '' ;
						$input_info=$arr_t[0].$lvl_info;
							
						//Create..
						/**************************************/
						$this->createFV($input_info, $datagrpInfo, $valueFS, $_FV_t, $datagrp);

					} //foreach($temp_arr as $lvl_info)
					
					
				} else {
					//NON NESTED	
					//_echo($datagrpInfo.' is NON NESTED<br>');	
					$this->DATA_INFO[ $datagrpInfo ][ 'nested' ] = false; //SET AS NON NESTED.
					
					//Get no. of first tier rows..
					//print_r($this->_FV);
					
					if(is_array($this->_FV)){
						$i = 0;
						
						//For multiple rows eg name.#0, name.#1, name.#2....
						/***************************************************/
						foreach(array_keys($this->_FV) as $k ){
							$k_arr = explode('.',$k);
							if(!empty($k_arr[2])){
								
								$input_info=$arr_t[0].'.#'.$i;
								$this->createFV($input_info, $datagrpInfo, $valueFS, $_FV_t, $datagrp);
								$i++;
							}
						}
						
						//For single rows.. name.#0 only.
						/**************************************************/
						//echo '<h1>b</h1>';
						$input_info=$arr_t[0].'.#0'; //echo $input_info.'<br>';					
						//Create..
						//This to set without database form to .#0 annotations properly initialised the fields.
						/**************************************/
						if(empty($this->_FV[$input_info])) $this->createFV($input_info, $datagrpInfo, $valueFS, $_FV_t, $datagrp);						
						
					} else { 
						//echo '<h1>a</h1>';
						$input_info=$arr_t[0].'.#0'; 
						//echo $input_info.'<br>';
						//Create..
						//This to set without database form to .#0 annotations properly initialised the fields.
						/**************************************************/
						$this->createFV($input_info, $datagrpInfo, $valueFS, $_FV_t, $datagrp);
					}
					
					
					
					
					
					//$this->_FV[$datagrpInfo][$input_info]=isset($_POST['_FN'][$datagrpInfo][$input_info]) ? $_POST['_FN'][$datagrpInfo][$input_info] : $valueFS ;
					//if($this->FS_RUN_DIA) echo '<br>_FV[',$datagrpInfo,'][',$input_info,']=',$this->_FV[$datagrpInfo][$input_info];
				}
				///_print_r($_FV_t);
				
				
				if($this->FS_RUN_DIA) {
					echo $this->TEST_DIV;
					echo 'Datagrp :',$datagrp;
					echo '<br>datagrpInfo: ',$datagrpInfo;
					echo '<br>input infos:',$input_infos;
					echo '<br>tier_info=',$tier_info;
					echo '<br>column name=',$colname;
					echo '<br>Temp arr<br>';
					print_r($temp_arr_processed);
					echo '</div>';
				}
				
			} //foreach(array_keys($FS[$datagrpInfo]) as $input_infos)
			
		} //foreach(array_keys($FS) as $datagrpInfo)

		/*
		IMPORTANT: DO NOT DELETE
		********************************************************
		DATA FORMAT REFERENCE
		********************************************************
		
			EG: With database.
				$this->_FV['a.0#1a.1']['Title#0']=isset($_POST['a']['0#1a.1']['Title#0']) ? $_POST['a']['0#1a.1']['Title#0'] : $this->_D['a.0#1a.1']['Title#0'];
			EG: Without database
				$this->_FV['a']['Title#0']=isset($_POST['a']['Title#0']) ? $_POST['a']['Title#0'] : $this->_D['a']['Title#0'];
		
		********************************************************
		*/
	}
	public function Retrieve_Ajax_Post_Data(){
			//print_r($_POST['Post_Data']);
			
			if(!empty($_POST['Post_Data']) && !is_array($_POST['Post_Data'])){
				$_post_data = json_decode($_POST['Post_Data'], true ); //print_r($_post_data);
				if(is_array($_post_data)){
					foreach( array_keys($_post_data) as $k ){
						$_post_data_filtered[ $_post_data[$k]['name'] ] = $_post_data[$k]['value'];
					}
					//This loop ensures repeated entries are removed.
					foreach( array_keys($_post_data_filtered) as $k ){
						//echo '---------'.$k;
						if($k=='') {
							unset($_post_data_filtered[$k]);
						} else {
							//echo '-->'.$k;
							$k=str_replace('[','(',$k);
							$k = str_replace(']',')',$k); //echo '-->'.$k;
							$this->FS_AJAX_POST_DATA[$k] = $_post_data_filtered[$k];
						}
					}					
				} else {
					PRINT_WARNING_MSG_TEMPLATE('Error retrieving $_POST[Post_Data].','Parsed $_POST[Post_Data] is not an array. Check JSON parsing in JS ajax script.');
				}

			}	
		//echo 'print_r( $this->FS_AJAX_POST_DATA);';
		//print_r( $this->FS_AJAX_POST_DATA);
		return $_post_data_filtered;
	}

	private function createFV($input_info, $datagrpInfo, $valueFS, $_FV_t, $datagrp){
		//_print_r($valueFS);
		//_echo('<h3>input_info='.$input_info.' datagrpInfo='.$datagrpInfo.' valueFS='.$valueFS.' _FV_t='.$_FV_t.' datagrp='.$datagrp.'</h3>');
		//_echo ($this->RED_DIV); 
		//_print_r($_FV_t);
		//_echo ('</div>'); 
		//_echo('<br><br>');
		//Check to see if exist in _FV
		if(isset($_FV_t)) { 
			
			//Check for exceptions
			if(!empty($input_info)){
				$t_arr = explode('.',$input_info); //echo $t_arr[1][1];
				if(!empty($t_arr[0]) && isset($t_arr[1][1])){
					//FS[][]['_position'] = means this form field is not a repeating field. Eg. Tnc check box that appears at the footer position of the form.
					//The second check filters out attempt to creat fieldname.#1, fieldname.#2. Only fieldname.#0 is created in accordance to the above explaination.
					if(!empty($this->FS[$datagrpInfo][$t_arr[0]]['_position']) && $t_arr[1][1]==0){
						//check exist..
						//echo $input_info.'-'.$t_arr[1][1].'-<br>';
						$exist=$this->check_exist_in_FV($_FV_t,$input_info, $datagrp);
					}
				}
				
			}
			
		} else {
			$exist=false; //_echo('DOES NOT EXIST');
		}
		
		//if fv does not exist, create new _FV entries 
		if($exist===false) {
			//_echo ($input_info);
			$this->_FV[$datagrpInfo][$input_info]=isset($_POST['_FN'][$datagrpInfo][$input_info]) ? $_POST['_FN'][$datagrpInfo][$input_info] : $valueFS ;
			
			if($this->FS_RUN_DIA) { 
				echo $this->RED_DIV;
				echo '<br>CREATE _FV[',$datagrpInfo,'][',$input_info,']</div>';
			}
		}
		
	}
	
	private function check_exist_in_FV($_FV_t,$input_info, $datagrp){
		
		if($this->FS_RUN_DIA)  echo '<h3>input_info: ',$input_info,'</h3>';
		
		$exist=false;
		
		foreach(array_keys($_FV_t) as $x){
		
			$arr=explode('.',$x);
			if( $datagrp==$arr[0] ) {
				$fv_temp=$_FV_t[$x];
				//print_r($fv_temp);
				foreach(array_keys($fv_temp) as $y){
				
					if($this->FS_RUN_DIA)  echo '<br>$y:',$y;
					
					if($y==$input_info){
						//echo $x;
						//echo $arr[0],$arr[1];
						$_FV_exist = isset($this->_FV[$x][$input_info]) ? 'y' : 'n';
						$_FN_exist = isset($_POST['_FN['.$x.']['.$input_info.']']) ? 'y' : 'n';
						$_D_exist = isset($this->_D[$x][$input_info]) ? 'y' : 'n';
						//if(isset($this->_FV[$x][$input_info])) $exist=true;						
					}
				}
				//break;
			} //if $datagrp==$arr[0] 
			
		}
		
		if( !isset($_FV_exist) && !isset($_FN_exist) && !isset($_D_exist) ) {
			$exist=false;
		} else {
			$exist=true;
		}
		
		
		if($this->FS_RUN_DIA) { 
			echo $this->RED_DIV;
			echo '<br>_FV[',$x,'][',$input_info,']=',$this->_FV[$x][$input_info],'-->',$_FV_exist;
			echo '<br>_FN[',$x,'][',$input_info,']=',$_POST['_FN['.$x.']['.$input_info.']'],'-->'.$_FN_exist;
			echo '<br>_D[',$x,'][',$input_info,']=',$this->_D[$x][$input_info],'-->'.$_D_exist;
			echo '</div>';
		}
		//echo $exist;
		return $exist;
	}
	
	private function _FS_INI_VALUE($arr){
		
		//print_r($arr);
		
		$value='';
		
		if(isset($arr['_placeholder'])){
			if($arr['_placeholder']!=''){
				//$value=$arr['_placeholder'];
			} else {
				$value=$arr['_dvalue'];
			}
		} elseif(isset($arr['_dvalue'])) {
			$value=$arr['_dvalue'];
		}
		
		return $value;
	}
	
	private function _FORM_FS_RUNNER($str){
	
		//MANUAL FORMAT TESTING
		//DO NOT DELETE
		/*
		$max_a=3;
		$max_b=2;
		$max_c=2;
		$k=1;
		for($a=0;$a<$max_a;$a++){
			for($b=0;$b<$max_b;$b++){
				for($c=0;$c<$max_c;$c++){
					echo $k.') '.$a.$b.$c,'<br>'; 
					$k++;
				}
			}
		}*/

		//$str='3.2.2';
		
		unset($this->temp_arr); //clears temp_arr
		
		$strArr=explode('.',$str);
		$totalresults=1;
		foreach(array_keys($strArr) as $key){
			$columns[]=$key;
			$totalresults=$totalresults*$strArr[$key];
		}
		//print_r($columns);
		if($this->FS_RUNNER_DIA) {
			echo '<h1>',$str,'</h1>';
			echo '[Total results:',$totalresults,']<br>';
		}
		
		$multiplier=$totalresults;
		$size_local='1';
		
		//START OF LOOPING
		foreach(array_keys($columns) as $colkey){
			//echo 'Process column ',$colkey;
			$colnum=$colkey+1;
			
			if(isset($strArr[$colkey-1])){
				$size_local=$size_local*$strArr[$colkey];
			} else {
				$size_local=$strArr[$colkey];
			}
			//echo $size_local; echo 'prev=',$multiplier; echo 'total=',$totalresults; echo 'divider=',$strArr[$colkey];
			$multiplier=$multiplier/$strArr[$colkey];
			//echo 'total/theeee size=',$multiplier;
			
			//Process each column
			$this->process_column($colnum,$strArr[$colkey],$totalresults,$colkey,$multiplier);
		}
		//print_r($this->temp_arr);
	}
	
	
	private function process_column($colnum,$size,$totalresults,$colkey,$multiplier){
		
		//form number series
		for($i=0;$i<$size;$i++){
			$numbers[]=$i;
		}
		
		//get marker last position
		$last_marker=$totalresults/$multiplier;
		
		//form marker arrray to set the array keys for trigger
		for($i=1;$i<=$last_marker;$i++){
			$marker[]=$i*$multiplier;
		}
		
		//Generation
		for($i=0;$i<$totalresults;$i++){
			
			//if, number[] will be set to next result
			if(in_array($i,$marker)){
				$num=next($numbers);
				if( current($numbers)===false){
					//echo $i,'-->reset<br>';
					reset($numbers);
					$num=current($numbers);
				} 
				if($this->FS_RUNNER_DIA) echo $i.') '.$num,'<br>';
				$this->temp_arr['tmp_'.$i]=$this->temp_arr['tmp_'.$i].'#'.$num;
				
			}else{
				$num=current($numbers);
				if($this->FS_RUNNER_DIA) echo $i.') '.$num,'<br>';
				$this->temp_arr['tmp_'.$i]=$this->temp_arr['tmp_'.$i].'#'.$num;
			}
		}
		if($this->FS_RUNNER_DIA) {
			echo $this->TEST_DIV;
			echo '[Col no.',$colnum,']<br>';
			echo 'total:',$totalresults;
			
			echo ' size: ',$size;
			echo '<br>numbers Array<br>';print_r($numbers);
			echo '<br>Marker Array<br>'; print_r($marker);
			echo '</div>';
		}
		
	}
		
	private function _FORM_POST_run(){ 
		//_print_r($this->_FV);
		if($this->RETRIEVE_DIA){
			echo '<h1>_POST</h1>';
			print_r($_POST);
			echo '</hr>';
			//print_r( $_POST ['_FN']['d.6b..8'] ); //['Item.#0#1#0'] ;
		}
		
		//clean up _POST of _DELE
		if(isset($_POST['_DELE'])){
			if(isset($_POST['_FN'])){
				foreach(array_keys($_POST['_FN']) as $k){
					$k_arr = explode('.',$k); 
					if( isset( $_POST['_DELE'][ $k_arr[1].'.'.$k_arr[2] ] ) ){
						unset($_POST['_FN'][$k]);
					}
					
				}				
			}

		}
		//_echo ('<h1>Processed _POST</h1>'); _print_r($_POST);
		
		if(isset($_POST['_FN'])) {	
			$this->_FORM_POST_data_run();
		}
		
	}//_FORM_POST_run
	
	private function _CLEAN_POST($data_infos,$input_info, $post_data){
		//_E_TRACE($input_info,true);
		
		//Retrieve informations
		$data_infos_arr = explode('.',$data_infos);
		$FSID = isset($data_infos_arr[0]) && isset($data_infos_arr[1]) ? $data_infos_arr[0].'.'.$data_infos_arr[1] : '' ; //_E_TRACE($FSID,true);
		
		$input_info_arr = explode('.',$input_info);
		$Colname = isset($input_info_arr[0]) ? $input_info_arr[0] : '' ; //_E_TRACE($Colname,true);
		
		if(isset($this->FS[$FSID][$Colname]['_clean'])){
			//IF THERE IS SPECIFIED METHODS
			if(is_array($this->FS[$FSID][$Colname]['_clean'])){
				// $func has params to do custom settings
				$func = trim(key($this->FS[$FSID][$Colname]['_clean'])); //_E_TRACE($func,true);
				
				$params = $this->FS[$FSID][$Colname]['_clean'][$func]; //_E_TRACE($params,true);
				
				$func = '_CLEAN_'.$func;
				
				if(method_exists($this,$func)){
					$post_data = $this->$func($post_data,$params); //_E_TRACE($post_data,true);
				} else {
					echo 'datalogic._CLEAN_POST() call to undefined '.$func.' method.<br>';
				}
				
			} else {
				//standard default methods
				$func = trim($this->FS[$FSID][$Colname]['_clean']);
				$func = '_CLEAN_'.$func;
				if(method_exists($this,$func)){
					$post_data = $this->$func($post_data); //_E_TRACE($post_data,true);
				} else {
					echo 'datalogic._CLEAN_POST() call to undefined '.$func.' method.<br>';
				}
			}
			
		} else {
			//USE _CLEAN_FILTER_SANITIZE_STRING as defaults
			if(isset($this->FS[$FSID][$Colname]['_type'])){
				$types = array('text','password');
				if(in_array($this->FS[$FSID][$Colname]['_type'],$types)){
					$post_data = $this->_CLEAN_FILTER_SANITIZE_STRING($post_data,$params); //set as default for input='text'
				}
			}
		}
		
		return $post_data;
	}
	
	private function _FORM_POST_data_run(){
		//_print_r($_POST['_FN']);
		foreach(array_keys($_POST['_FN']) as $data_infos){ //echo '----->',$data_infos;
			
			if(is_array($_POST['_FN'][$data_infos])){
				
				//$data_infos_arr=$this->get_datainfos($data_infos);
				//$datagrp=$data_infos_arr['datagrp'];
			
				foreach(array_keys($_POST['_FN'][$data_infos]) as $input_info){
					//$this->_FV['a.0#3a.1']['Title#0']=isset($_POST['_FN']['a.0#3a.1']['Title#0']) ? $_POST['_FN']['a.0#3a.1']['Title#0'] : $this->_D['a.0#3a.1']['Title.#0'];
					//_echo('<h2>_FORM_POST_data_run</h2>');
					
					$_POST['_FN'][$data_infos][$input_info] =$this->_CLEAN_POST($data_infos,$input_info,$_POST['_FN'][$data_infos][$input_info]); 
					//_E_TRACE($_POST['_FN'][$data_infos][$input_info],true);

					//retrieve values
					$this->_FV[$data_infos][$input_info]=isset($_POST['_FN'][$data_infos][$input_info]) ? $_POST['_FN'][$data_infos][$input_info] : '';
					//_print_r($this->_FV); _E_TRACE($this->_FV,true);
					
					if($this->RETRIEVE_DIA){
						echo $this->RED_DIV;
						echo '<h2>',$data_infos,'</h2>';
						echo 'datagrp=',$datagrp,'<br>input_info=',$input_info;
						echo '<br>';
						echo 'VALUE: $this->_FV[',$data_infos,'][',$input_info,']=';
						echo $this->_FV[$data_infos][$input_info];
						echo '<br>';
						echo '$_POST[',$data_infos,'][',$input_info,']';
						echo '<br>';
						echo '<br>';
						echo '</div>';
					}//if
				
				} // foreach input_info
			
			} //if(is_array($_POST[$datagrp]))
			
		} //foreach(array_keys($_POST) 
	}
	private function _WIDGET_get_data(){
		
		if( isset($this->WID) ){
			//print_r($this->WID);
			foreach( array_keys( $this->WID) as $widID ){
				//_echo($widID);

				if(isset($this->WID[ $widID ][ '_method' ])){
					$func = $this->WID[ $widID ][ '_method' ];
					if(method_exists($this,$func)){
						$result = $this->$func(); //_print_r($result);
					}
					
				} elseif(isset($this->WID[ $widID ][ '_qs' ])){ 
				
					foreach( array_keys( $this->WID[ $widID ]) as $k){ //_echo($k);
						//get data
						
							//echo $this->WID[ $block ][ '_qs' ];
							$tableID = $this->WID[ $widID ][ '_qs' ];
							//print_r($this->QUERY_PARAMS[ $tableID ]);
							
							if(isset($param)) unset($param);
							if(is_array( $this->QUERY_PARAMS[ $tableID ] )){
								$param = $this->QUERY_PARAMS[ $tableID ];
							} else {
								$param[] =$this->QUERY_PARAMS[ $tableID ];
							}						

						

					}
					//print_r($param);
					//_echo($tableID);
					$result = $this->_DATALOGIC_QUERY($tableID,$param);
					//echo $k;
					
				
				}
				//_print_r($result); echo '<br>';
				$this->WID_DATA[ $widID ]=$result;
			}
		}
	}
	
	private function _WIDGET_get_data_OLD(){
		
		if( isset($this->WID) ){
			//print_r($this->WID);
			//loop thru the 'block' level
			foreach( array_keys( $this->WID) as $block ){
				foreach( array_keys( $this->WID[ $block ]['_cell']) as $k){
					//get data
					if(isset($this->WID[ $block ]['_cell'][ $k ][ '_qs' ])){
						//echo $this->WID[ $block ]['_cell'][ $k ][ '_qs' ];
						$tableID = $this->WID[ $block ]['_cell'][ $k ][ '_qs' ];
						//print_r($this->QUERY_PARAMS[ $tableID ]);
						
						if(isset($param)) unset($param);
						if(is_array( $this->QUERY_PARAMS[ $tableID ] )){
							$param = $this->QUERY_PARAMS[ $tableID ];
						} else {
							$param[] =$this->QUERY_PARAMS[ $tableID ];
						}						
						//print_r($param);
						$result = $this->_DATALOGIC_QUERY($tableID,$param);
						//echo $k;
						//print_r($result); echo '<br>';
						$this->WID_DATA[]=$result;
					};
					/*
					$result_arr = $this->WID[ $block ]['_cell'][ $k ][ '_result' ]; 
					foreach( array_keys($result_arr) as $result_k ){
						echo $result_k;
					}
					*/
				}
			}
		}
	}
	
	private function _FORM_SEARCH_FILTER_get_misc_data(){
		
		if(isset($this->SEARCH)){		
			
			foreach(array_keys($this->SEARCH ) as $FSID ){
				
				foreach(array_keys($this->SEARCH[ $FSID ]['FS'] ) as $key){
					//echo $key;
					if( isset( $this->SEARCH[ $FSID ]['FS'][$key]['_group_gen']) ){
						$tableID = $this->SEARCH[ $FSID ]['FS'][$key]['_group_gen'];
						$fs_target = $this->SEARCH[ $FSID ]['FS_TARGET'];
						$col_target = $this->SEARCH[ $FSID ]['FS'][$key]['_key'];					
						
						//param processing
						//print_r( $this->QUERY_PARAMS [$this->SEARCH[ $FSID ]['FS'][$key]['_group_gen'] ] );					
						if(isset( $this->QUERY_PARAMS[ $this->SEARCH[ $FSID ]['FS'][$key]['_group_gen'] ]  )){
							
							if(isset($param)) unset($param);
							$param_tmp = $this->QUERY_PARAMS[ $this->SEARCH[ $FSID ]['FS'][$key]['_group_gen'] ];
							if(is_array($param_tmp)){
								$param = $param_tmp;
							} else {
								$param[] = $param_tmp;
							}
						}
						
						if( !isset($this->MISC_DATA[$FSID][$col_target]['_group_gen']) ){
							$this->MISC_DATA[$FSID][$col_target]['_group_gen'] = $this->_DATALOGIC_QUERY($tableID,$param);
						} else {
							//echo 'exist';
						}
						
					}
				}
				
			}
		}
	}
	
	private function _FORM_DB_get_misc_data(){ //echo '<h1>_FORM_DB_get_misc_data</h1>';
		//$this->MISC_DATA
		
		//SCAN FOR MISC DATA
		/*
			Scans for following:
				i) FS[datainfo][colinfo]['_group_gen']
		
			Sample Format:
				MISC_DATA[datainfo][colinfo]['_group_gen']=row data ("displayname"=>"value", ... )
		*/
		if(isset($this->FS)){
			foreach(array_keys($this->FS) as $key){
				foreach(array_keys($this->FS[$key]) as $key2){
					if(isset($this->FS[$key][$key2]['_group_gen'])){
						
						$tableID = $this->FS[$key][$key2]['_group_gen']; //echo $tableID;
						//print_r($this->QUERY_PARAMS[$tableID]);
						$params2 = $this->QUERY_PARAMS[$tableID];
						
						$this->MISC_DATA[$key][$key2]['_group_gen'] = $this->_DATALOGIC_QUERY($tableID,$params2);
						//print_r($this->MISC_DATA[$key][$key2]['_group_gen']);
					}
				}
			}
		}
		if($this->SHOW_MISC_DATA) print_r($this->MISC_DATA);
	}
	
	
	
	private function _FORM_DB_run( $FStatus ){
		/*
		_echo('<h1>'.$FStatus.'</h1>');
		_echo('<h3>_D</h3>');
		_print_r($this->_D);*/
		
		if(isset($this->_D)) $_D=$this->_D;
		//print_r($_D);	
		//eg: $this->_D['a.0#1a.1']['Title.#0'] ==> _D[datagrp.QS_ID.keyID][input_info]
		if(is_array($_D)){
			unset($this->_FV); //This is important!! It clears away old _FV data
			
			foreach( array_keys($_D) as $data_info){			
			
			//_echo('<h3>_FORM_DB_run.data_info</h3>');
			//_print_r($data_info);
			
				if($this->RETRIEVE_DIA){
					echo $this->TEST_DIV;
					echo ' / data info:',$data_info;
					echo '<hr>';
				}
				

				if(!empty($_D[$data_info]) && is_array($_D[$data_info])){
					foreach(array_keys($_D[$data_info]) as $input_info){
						
						if($input_info!='t_keyid'){ //filter out t_keyid which is inserted into _D during query retrieval
						
							//EG: With database.
								//$this->_FV['a.0#1a.1']['Title#0']=isset($_POST['_FN']['a.0#1a.1']['Title#0']) ? $_POST['_FN']['a.0#1a.1']['Title#0'] : $this->_D['a.0#1a.1']['Title.#0'];
							//EG: Without database
								//$this->_FV['a']['Title#0']=isset($_POST['_FN']['a']['Title#0']) ? $_POST['_FN']['a']['Title#0'] : $this->_D['a']['Title.#0'];

							//$datagrpinfo=$datagrp.'.'.$QS_ID.'.'.$keyID;
							
							
							//********************************************************************
							//AJAX UPDATE
							//*******************************************************************
							$_retrieved_ajax_data = $this->Retrieve_Ajax_Post_Data();
							//_echo('<h3>_retrieved_ajax_data</h3>');
							//_print_r( $_retrieved_ajax_data );					
							if(is_array($_retrieved_ajax_data)){
								foreach(array_keys($_retrieved_ajax_data) as $key){
									//_echo($data_info);
									$fnid = '_FN['.$data_info.']['.$input_info.']'; 
									//_echo('<br>fnid='.$fnid.'<br>');
									//_echo('KEY='.$key,'<br>');
									if($key==$fnid) {
										//Update POST[_FN] with ajax posted back data
										$_POST['_FN'][$data_info][$input_info] = $_retrieved_ajax_data[ $key ];
										$Ajaxed = true;
									}
								}		
							}				
							//echo '<h1>POST</h1>'; print_r($_POST);
							//*******************************************************************
							//retrieve values
							//*******************************************************************
							$this->_FV[$data_info][$input_info] = isset($_POST['_FN'][$data_info][$input_info]) ? $_POST['_FN'][$data_info][$input_info] : $_D[$data_info][$input_info];						


							

							
							if($this->RETRIEVE_DIA){ 
								//eg :$a['0#1a.1']['Title.#0']
								echo '<br>';
								echo $this->RED_DIV;
								echo '$this->_FV[',$data_info,'][',$input_info,']=';
								echo $this->_FV[$data_info][$input_info];
								echo '</div>';
								echo '<br>';
								//eg: $_POST['a']['0#1a.1']['Company.#0']
								echo '$_POST[_FN][',$data_info,'][',$input_info,']';
								echo '<br>';
								
								echo '<br>';
							}//RETRIEVE_DIA
						
						}//if
						
						
					}// foreach input_info
				}
				if($this->RETRIEVE_DIA) echo '</div>';
			
			}//foreach data_info
			
			
			//SORT COLUMN RESULTS ACCORDING TO FS SETTINGS
			//***************************************************************************************
			$_fv = $this->_FV; //_print_r($_fv); 
			$_fv_tmp = array();
			$FS = $this->FS; //_print_r($this->FS);
			$tmp = explode('.',$data_info);
			if(!empty($tmp[2])) $_id = $tmp[2];
			
			
			foreach(array_keys( $FS ) as $fsid ){
				//_print_r( $FS[ $fsid ] );
				foreach(array_keys($FS[$fsid]) as $_col ){
					//echo $this->_FV[$fsid.'.'.$tmp[2]][$_col.'.#0'];
					if(is_array($_fv)){
						foreach(array_keys($_fv) as $_fsid_id ){
							//Search _fv, re-arrange and unset
							foreach(array_keys($_fv[ $_fsid_id ]) as $_fv_col ){
								//echo $_fv[ $_fsid_id ][ $_fv_col ];
								//echo $_fv_col;
								$_t_arr = explode('.',$_fv_col);
								$_fv_col_name = $_t_arr[0];
								if($_fv_col_name == $_col) {
									//echo $_fv_col_name.'<br>';
									//put into _fv_tmp
									$_fv_tmp[ $_fsid_id ][ $_fv_col ] = $_fv[ $_fsid_id ][ $_fv_col ];
									unset($_fv[ $_fsid_id ][ $_fv_col ]);
								}
							}
						}						
					}

				}
			}
			//_print_r($_fv_tmp);
			//_print_r($_fv);
			unset($this->_FV);
			$this->_FV = $_fv_tmp;
			
		} //iseet _D
	} //_FORM_DB_run
		
	private $insertIDERROR=false;
	private $tempinsertID;
	private $tableTree;
	
	public function _FORM_UPDATE_INSERT_MAIN(){
		//_echo('<h1>_FORM_UPDATE_INSERT_MAIN</h1>');
		if($this->INSERT_DIA) { echo'<h2>$_POST array</h2>'; print_r($_POST); echo $this->DIA_LINE; }
		unset($this->tempinsertID);
		unset($this->tableTree);
		
		//echo 'QS_ID-->',$QS_ID;
		//_echo('<h2>FS_AJAX_PROCESS_FSID_FINAL</h2>');
		//_print_r($this->FS_AJAX_PROCESS_FSID_FINAL);
		//_echo('<h2>_FN</h2>');
		//_print_r($_POST['_FN']);		
		
		foreach(array_keys($_POST['_FN']) as $datagrpinfo){
			//Check to see if targeted is error free
			//Error free entries are listed in $this->FS_AJAX_PROCESS_FSID_FINAL
			if(!empty($this->FS_AJAX_PROCESS_FSID_FINAL)){
				if(in_array($datagrpinfo, $this->FS_AJAX_PROCESS_FSID_FINAL)){
					//echo 'ok';
				} else {
					//echo 'There is error in this form field. _FN[',$datagrpinfo,']';
					break;
				}				
			}

			//_echo($datagrpinfo);
			//eg [a.0#1a.1]
			$arr=$this->get_datainfos($datagrpinfo); //echo $datagrpinfo;
			$input_id=$arr['ip_id']; //_echo ('<br>input_id---->'.$input_id);
			$QS_ID=$arr['qs_id'];
			$table= $this->QS[ $QS_ID ]['_table'];
			$keyID= $this->QS[ $QS_ID ]['_keyID'];
			$fs_datainfo = $arr['datagrp'].'.'.$QS_ID;
			$QS_OPS_DONE=0;
			
			$have_update = $this->_FOPS_have_update( $fs_datainfo );  //if( $have_update ) { _echo ('<br>have_update---->'.$have_update); } else { _echo('no update'); } ;
			$have_insert = $this->_FOPS_have_insert( $fs_datainfo ) ;	

			
			//_echo('<H1>---------------------------------Update----------------------------------------</h1>');
			if( $input_id!='' && $have_update ){ //_echo('---------------------------------Update');
				/*
				****************************************************************************************************************
				DO UPDATE
				****************************************************************************************************************
				*/
				
				
				//retrieve all columns
				//************************************
				$strSep='';
				$uvalues='';
				$update_datas='';
				$has_FS_OPS=false;
				$has_QS_OPS=false;
				
				//GET ROW DATAS FOR _OPS
				//************************************
				foreach(array_keys($_POST['_FN'][$datagrpinfo]) as $input_info){ 
					$id2_arr=explode('.',$input_info);
					$update_datas[ $id2_arr[0] ] = $_POST['_FN'][$datagrpinfo][$input_info] ;
				}
				
				foreach(array_keys($_POST['_FN'][$datagrpinfo]) as $input_info){
					
					$id2_arr=explode('.',$input_info);
						
					//B) CHECK FOR OPS(FS) AND SET UP OPS(FS) METHOD EXECUTION	
					//************************************					
					if(isset($this->FS[$fs_datainfo])){ 
						foreach( array_keys($this->FS[$fs_datainfo]) as $colname_i ){  
							
							$t_arr = explode('.',$colname_i);
							$value_update ='';
							
							if($id2_arr[0] == $t_arr[0]){
								foreach(array_keys( $this->FS[$fs_datainfo][$colname_i] ) as $colname_ii){  //echo $colname_ii;echo $this->DIA_LINE;
									if($colname_ii=='_ops'){
										//GET METHODS IN _ops
										$op_func = trim(key( $this->FS[$fs_datainfo][$colname_i][$colname_ii] ));
										
										//echo $op_func2 = '_'.$op_func; //old version requires '_'
										$op_func2 = $op_func;
										if(method_exists($this, $op_func2)){ //_echo ('<h2>'.$op_func2.'</h2>');
											//_E_TRACE('op_func',true); _E_TRACE($op_func,true);
											$has_FS_OPS = true;
											//GET COLUMNS USED IN _ops
											$op_func_params['params'] = $this->FS[$fs_datainfo][$colname_i][$colname_ii][$op_func];
											//SET UP ROW DATAS
											$op_func_params['datas'] = $update_datas;
											
											$value_update = $this->$op_func2( $op_func_params ); 
											$uvalues=$uvalues.$strSep.$id2_arr[0].'="'.$value_update.'"'; //if there is _ops, replace the value defined above..
											
											$strSep=', ';
											//cho $uvalues;
											//store values retrieved from _FN
											$FNvalue[ $id2_arr[0] ] = $value_update;
											
										} else {
											echo '<h5>_ops method does not exist.</h5>';
										}
									} 
								}								
							}

						}
					}
					if($has_FS_OPS===false){
						//A) Compile form values for updating
						//************************************						
						$uvalues=$uvalues.$strSep.$id2_arr[0].'="'.$_POST['_FN'][$datagrpinfo][$input_info].'"'; //echo $uvalues;
						$strSep=', ';
						//store values retrieved from _FN
						$FNvalue[ $id2_arr[0] ] = $_POST['_FN'][$datagrpinfo][$input_info];
					}
					
					//c) CHECK FOR OPS(QS) AND SET UP OPS(QS) METHOD EXECUTION	(PERFORMS 1X per row)
					//************************************	
					$QS_OPS = $this->QS[$QS_ID]['_ops'];
					if(isset($QS_OPS) && $QS_OPS_DONE==0){
						$QS_OPS_DONE++;
						$has_QS_OPS= true;
						//print_r($QS_OPS);
						foreach(array_keys($QS_OPS) as $colname){
							foreach(array_keys($QS_OPS[$colname]) as $QS_OPS_func){
								$QS_OPS_params = $QS_OPS[$colname][$QS_OPS_func];
								if(is_array($QS_OPS_params)){
									//Params is array=>func has multiple inputs
									if(method_exists($this, trim($QS_OPS_func) )){ 
										$value_qs_em = $this->$QS_OPS_func( $QS_OPS_params['params'] ,$datagrpinfo, $fs_datainfo , $QS_ID, $id2_arr[1] );
										$uvalues=$uvalues.$strSep.$colname."='".$value_qs_em."'";
									}
								} else {
									//Params is single input
									//echo $this->DIA_LINE; echo $QS_OPS_params;
									if(method_exists($this, trim($QS_OPS_func) )){ 
										$value_qs_em = $this->$QS_OPS_func( $QS_OPS_params ,$datagrpinfo, $fs_datainfo ,$QS_ID, $id2_arr[1] );
										$uvalues=$uvalues.$strSep.$colname."='".$value_qs_em."'";
									}
								}
							}
						}
					}
					

				} //foreach
				

				//CHECK VALUE CHANGES, if there is do updates..
				//************************************
				$do_update = false;
				$not_same = 0;
				//print_r($this->_D);
				//echo $datagrpinfo;
				//echo '<h1>FNvalue</h1>=';print_r($FNvalue);
				$this->_PRINT_DATALOGIC_DIA_MSG('_FORM_RENDERFORM().datalogic');
				
				$this->_D = VALUE_EXIST($_POST['Ajaxed_D']) ?  json_decode ( urldecode( $_POST['Ajaxed_D']), true)  : $this->_D;
				//_print_r( json_decode ( urldecode( $_POST['Ajaxed_D']) ));
				if(!empty($this->_D[$datagrpinfo])){
					foreach(array_keys($this->_D[$datagrpinfo]) as $DColname){
						
						$DColnameArr = explode('.',$DColname);
						//echo $DColnameArr[0];
						if(isset($FNvalue[$DColnameArr[0]])){
							if($DColnameArr[0]!='t_keyid'){
								//echo '<br>'; echo $FNvalue[$DColnameArr[0]],'--'; echo $this->_D[$datagrpinfo][$DColname]; echo '<br>';
								//IF retrieved FN vales = database stored values _D
								if( $FNvalue[$DColnameArr[0]]!= $this->_D[$datagrpinfo][$DColname] ){
									//echo '<br>'; echo $FNvalue[$DColnameArr[0]],'--'; echo $this->_D[$datagrpinfo][$DColname]; echo '<br>';
									$not_same++;
								}
								
							}						
						}
						
					}					
				}

				//echo 'not_same=',$not_same;
				if($not_same>0) $do_update = true;
				
				

				//DO UPDATE
				//************************************
				if( $do_update ){
					//PROCESS AND FINALIZE QS['_valueEB']['Status']

					//SET Colnames NOT MEANT FOR UPDATE
					//NOTE: 'Status' and 'StatusDate' in _valueEB are meant for INSERT operations only.
					//IF YOU WANT TO DO AUTO STATUS DURING UPDATE, SET IT AS AN HIDDEN FIELD
					//USE BACK THIS IN PHASE 2, BUT NEED TO CHANGE A BIT..==>$exclude_colnames=array("AddedBy","AddedByID","AddedByType","AddedDate","Status","StatusDate");
					//$exclude_colnames = array("ModifiedBy","ModifiedByID","ModifiedByType","ModifiedDate","AddedBy","AddedByID","AddedByType","AddedDate");
					$exclude_colnames = array(); //array("AddedBy","AddedByID","AddedByType","AddedDate");
					//ADD EMBED VALUE
					if(isset($this->QS[ $QS_ID ][ '_valueEB' ])){
						foreach(array_keys($this->QS[ $QS_ID ][ '_valueEB' ]) as $colname){ 
								//echo $this->QS[ $QS_ID ][ '_valueEB' ][ $colname ];
							//RETRIEVE VALUES
							$colval = $this->QS[ $QS_ID ][ '_valueEB' ][ $colname ];
						
							//UPDATE columns not in exclude_colnames
							if(!in_array($colname,$exclude_colnames)){
									//echo '>',$colname,'-';
								if($colval=='NOW()'){
									$uvalues=$uvalues.$strSep.$colname."=".$colval; 
								} else {
									$uvalues=$uvalues.$strSep.$colname.'="'.$colval.'"'; 
								}
							}
								
						}						
					}

					
					if($this->UPDATE_DIA) {
						echo $this->RED_DIV;
						echo 'UPDATE ',$table,' SET ',$uvalues,' WHERE ',$keyID,'=',$input_id; echo '<br>';
						echo '</div>';
					}
				
				
					//************************************
					//Additional Ops functions
					//************************************
					//$value_opped = $this->check_ops( $ops_params ); //echo '<h1>value_opped-->',$value_opped,'</h1>';
					//if($value_opped) $temp[$x][$colname_info] = $value_opped;
							
					$count = $this->Database->core_query_update($table,$uvalues,$keyID,$input_id);
					$DONE = $count>0 ? true : false;
					
					
				} //if( $do_update ){
				
				
			} elseif( $have_insert ) {
				/*
				****************************************************************************************************************
				DO INSERT
				****************************************************************************************************************
				*/
				//_echo ('INSERT');
				//FORM columns
				//1) Form an array of this format to group all data set tog
				//temp[b.4a.#0#0#0][Item]=fdfdffdfd 
				//temp[datagrpinfo.tier_info][colname]=value
				unset($this->teminsertID);
				unset($temp);
				
				
				
				//extract FS column info for checking
				$FS_chk_arr=$this->getFSColumns($this->FS[$datagrpinfo]); //echo '<h1>FS_chk_arr</h1>'; print_r($FS_chk_arr);
				
				//Check for special columns cases
				// [?p4]rwd, [?p1]r=read, [?p2]w=write, [?p3]d=delete, [?p4]e=exclude all sql operations
				//This set which FS[colname] is not be operated on.
				if(!empty($FS_chk_arr)){
					foreach($FS_chk_arr as $colCHK){
						$no_of_occurence = substr_count($colCHK,'?p4');
						if($no_of_occurence>0){
							//exclude from FS_chk_arr
							unset($FS_chk_arr[ $colCHK ]);
						}
					}					
				}

				//echo '<h1>FS_chk_arr finalized</h1>'; print_r($FS_chk_arr);
				
				
				//FORM temp ARRAY
				//************************************************************************
				foreach(array_keys($_POST['_FN'][$datagrpinfo]) as $input_info){
					//form values for updating
					//echo $input_info;
					$cols_arr=explode('.',$input_info); //echo '<h1>cols_arr</h1>'; echo $cols_arr[1]; //print_r($cols_arr);
					$colname=$cols_arr[0];
					
					if(is_array($FS_chk_arr)){
						if(array_key_exists($colname,$FS_chk_arr)){
							//echo 'exist!!!!!!!!!!';
						} else {
							//echo $this->RED_DIV;
							//echo 'Error!!!</div>';
							//$this->insertIDERROR=true;
							break;
						}
					}
					
					
					$tier_info=$cols_arr[1];
					if(isset($cols_arr[2])){
						if($cols_arr[2]!= '') $field_syscode='.'.$cols_arr[2];
					} else {
						$field_syscode = '';
					}
					$temp[$datagrpinfo.'*'.$tier_info][$colname.$field_syscode]=$_POST['_FN'][$datagrpinfo][$input_info];
				} //foreach
				

				unset($params);
				if($this->INSERT_DIA) { echo'<h1>$temp array</h1>'; echo 'array to be processed---->'; print_r($temp); echo '<br><br>';}
				
				
					

				if($this->insertIDERROR===false && isset($temp)) {
					
					//Loop to do insertion
					foreach(array_keys($temp) as $x){ //echo '<br>-->',$x,'<--';
					
						$x_arr=explode('*',$x);
						$datagrpinfo_tmp=$x_arr[0];
						$dataArr=explode('.',$datagrpinfo_tmp);
						$tierArr=explode('#',$x_arr[1]); //echo '<h1>tierArr(INSERT...)</h1>',$tierArr[1];
						end($tierArr);
						$tierArrLast=key($tierArr)-1; // offset minus 1 
						$table = $this->QS[ $dataArr[1] ][ '_table' ];
						$tablenext = isset( $this->QS[ $dataArr[1] ][ '_tablenext' ] ) ? $this->QS[ $dataArr[1] ][ '_tablenext' ] : '' ;
						$this->tableTree[$x_arr[0]][]=$x_arr[1];
						

						
						//echo $this->DIA_LINE; echo 'x_arr for ',$x,'<br>';print_r($x_arr); echo $this->DIA_LINE;
						
						$colnames='';
						$colvalues='';
						$ivalues='';
						$allvalues=''; //compiles all values for data insertion. note: h0 code tagged values will not be considered
						$strSep='';
						$field_syscode='';
						$params='';
						
						foreach(array_keys($temp[$x]) as $colname_info){
							//echo 'colname_info--->',$colname_info,'<br>';
							$c_arr=explode('.',$colname_info); //print_r($c_arr);
							$colname=$c_arr[0]; //echo $colname,'<br>';
							
							
							//A) Additional Ops FS functions
							//************************************************************************
							//CHECK FOR OPS
							//set up ops parameters
							$ops_params['datagrpinfo'] = $datagrpinfo;
							$ops_params['colname'] = $colname;
							$ops_params['colname_info'] = $colname_info;
							$ops_params['x'] = $x;
							$ops_params['temp'] = $temp;
							//print_r($ops_params);
							//_E_TRACE($ops_params,true);
							$value_opped = $this->check_ops( $ops_params ); //echo '<h1>value_opped-->',$value_opped,'</h1>';
							//If there is ops, update $temp[$x][$colname_info] to $value_opped
							if($value_opped) $temp[$x][$colname_info] = $value_opped;		
							
							//echo '<h1>$colnames='.$colnames.'</h1>';
							$colnames=$colnames.$strSep.$colname;
							$colvalues=$colvalues.$strSep.':'.$colname;
							
							$ivalues=$ivalues.$strSep."'".$temp[$x][$colname_info]."'";
							$params[':'.$colname] = $temp[$x][$colname_info]; //Form params
							
							if(isset($c_arr[1])) {
								if($c_arr[1]=='h0') $field_syscode=$c_arr[1];
							}							
							
							//Filter out code 'h0' which means it's hidden and when all other fields are empty, this value will not be inserted. Else it might create unneeded empty entires in db
							if($field_syscode!='h0') $allvalues=$allvalues.$temp[$x][$colname_info];
							$strSep=', ';
						
						} //foreach(array_keys($temp[$x]) as $colname_info){
						
						
						//Do insert only if  $allvalues != ''
						if($allvalues!=''){
							
							//DO INSERTION
							/******************************************/
							//Check for parent indexID
							$x_arr_arr=explode('.',str_replace('#','.#',$x_arr[1]) ); //print_r($x_arr_arr);
							$parentTier= isset($x_arr_arr[2]) ? $x_arr_arr[1] : ''; 
							if(isset($x_arr_arr[2])){
								$isParentTier=false;
							} else {
								$isParentTier=true;
							}
							
							//Get parent ID
							$TreeSize=sizeof($this->tableTree);
							for($i=0;$i<$TreeSize;$i++){
								if(key($this->tableTree)!=$x_arr[0]){
									next($this->tableTree);
								} else{
									break;
								};
							}
							prev($this->tableTree); //echo key($this->tableTree);
							$ParentID = $this->tempinsertID[ key($this->tableTree).'*'. $parentTier ];
							
							$tmp_arr = explode('.',$dataArr[1]);
							if(isset($this->QS[ $tmp_arr[0] ]['_filter'])) $filter = $this->QS[ $tmp_arr[0] ]['_filter'];
							
							
							
							//if parent indexID exist, insert it into table
							//i) find the current indexID column name
							$currTableKeyN=$this->QS[ $dataArr[1]  ][ '_prevtablekeyID' ];
							//ii) insert into $colnames, $colvaues, $params
							if($parentTier!=''){
								$colnames = $colnames.', '.$currTableKeyN;
								$colvalues =  $colvalues.', :'.$currTableKeyN;
								$params[':'.$currTableKeyN] = $ParentID; 
								$ivalues=$ivalues.", '".$ParentID."'"; //for diagnostic
							}
							//echo $x_arr[0];
							
								
							//_compulsory_insertkey
							//************************************************************************
							if(isset($this->QS[ $dataArr[1] ][ '_compulsory_insertkey' ])){
								$_compulsory_insertkey = $this->QS[ $dataArr[1] ][ '_compulsory_insertkey' ];
								//echo '<h1>$_compulsory_insertkey</h1>';print_r($_compulsory_insertkey);
								
								//loop thru _compulsory_insertkey
								foreach($_compulsory_insertkey as $ckey){
									$colnames = $colnames.', '.$ckey;
									$colvalues =  $colvalues.', :'.$ckey;
									$params[':'.$ckey] = $this->QUERY_PARAMS[ $dataArr[1] ]; 
									$ivalues = $ivalues.", '".$this->QUERY_PARAMS[ $dataArr[1] ]."'"; //for diagnostic
									//echo '------->',$this->QUERY_PARAMS[ $dataArr[1] ];
								}
							}

							//PROCESS QS _valueEB
							//************************************************************************
							//SET $exclude_colnames
							//USE BACK THIS IN PHASE 2-----> $exclude_colnames=array("ModifiedBy","ModifiedByID","ModifiedByType","ModifiedDate"); //echo '<h1>',$temp[$x]['VehicleTypeID'],'</h1>';
							//$exclude_colnames=array("ModifiedBy","ModifiedByID","ModifiedByType","ModifiedDate","AddedBy","AddedByID","AddedByType","AddedDate");
							$exclude_colnames=array("ModifiedBy","ModifiedByID","ModifiedByType","ModifiedDate");
							
							if(isset($temp[$x]['Status'])){
								$exclude_colnames[]="Status"; //Add 'Status' to $exclude_colnames
							}
							
							if(isset($this->QS[ $dataArr[1] ][ '_valueEB' ])){
								//print_r($this->QS[ $dataArr[1] ][ '_valueEB' ]);
								$value_embed= $this->QS[ $dataArr[1] ][ '_valueEB' ];
								foreach(array_keys($value_embed) as $colname){
									
									//FOR INSERT, process columns not in exclude_colnames
									if(!in_array($colname,$exclude_colnames)){
										$colnames = $colnames.', '.$colname;
										if($value_embed[$colname]=='NOW()'){
											$colvalues =  $colvalues.', NOW()';
										} else {
											$colvalues =  $colvalues.', :'.$colname;
											$params[':'.$colname] = $value_embed[$colname];
										}
										$ivalues = $ivalues.", '".$value_embed[$colname]."'"; //for diagnostic
									}																	
									
								}
							}
							//PROCESS QS _ops
							//************************************************************************
							if(isset($this->QS[ $dataArr[1] ][ '_ops' ])){
								$qs_ops = $this->QS[ $dataArr[1] ][ '_ops' ];
								foreach(array_keys($qs_ops) as $qs_ops_colname_insert){ 
									$qs_ops_func_insert = key( $qs_ops[$qs_ops_colname_insert] ); //_echo($qs_ops_func_insert);
									if(is_array($qs_ops[$qs_ops_colname_insert][$qs_ops_func_insert])){

										//echo '<h1>MULTIPLE VALUE</h1>';
										//echo $qs_ops_colname_insert,'-',$qs_ops_func_insert;
										//Params is array=>func has multiple inputs
										if(method_exists($this, $qs_ops_func_insert)){ 
											$value_qs_insert = $this->$qs_ops_func_insert( $this->QS[ $dataArr[1] ][ '_ops' ][$qs_ops_colname_insert][$qs_ops_func_insert]['params'] ,$datagrpinfo, $fs_datainfo , $QS_ID, '#'.$tierArr[1] );
											//echo '----->',$value_qs_insert,$tierArr[1],'<----';
											$colnames = $colnames.', '.$qs_ops_colname_insert;
											$colvalues =  $colvalues.', :'.$qs_ops_colname_insert;
											$params[':'.$qs_ops_colname_insert] = $value_qs_insert;
											$ivalues = $ivalues.", '".$value_qs_insert."'"; //for diagnostic
										}
										
									} else {
										//echo '<h1>SINGLE VALUE</h1>';
										if(method_exists($this, $qs_ops_func_insert)){ 
											$value_qs_insert = $this->$qs_ops_func_insert( $this->QS[ $dataArr[1] ][ '_ops' ][$qs_ops_colname_insert][$qs_ops_func_insert] ,$datagrpinfo, $fs_datainfo , $QS_ID, '#'.$tierArr[1] );
											//echo '----->',$value_qs_insert,$tierArr[1],'<----';
											$colnames = $colnames.', '.$qs_ops_colname_insert;
											$colvalues =  $colvalues.', :'.$qs_ops_colname_insert;
											$params[':'.$qs_ops_colname_insert] = $value_qs_insert;
											$ivalues = $ivalues.", '".$value_qs_insert."'"; //for diagnostic
										}
									}
									
								}
								
							}
							
							
								
							if($this->INSERT_DIA){
								echo $this->TEST_DIV;
								echo '<h1>dataArr[1] : ',$dataArr[1],'</h1>' ;
								echo '<br>tmp_arr[0]: ',$tmp_arr[0];
								echo '<br>filter: ',$filter;
								echo '<br>colnames: ',$colnames;
								echo '<br>data info (x_arr[0]):',$x_arr[0];
								echo '<br>Tier info (x_arr[1]):',$x_arr[1];
								echo '<br>Parent Tier: ',$parentTier; //Eg #0, #0#1...
								echo '<br>Parent Table',$parentTable;
								echo '<br>Parent ID : ',$ParentID;
								echo '<br>currTableKeyN :',$currTableKeyN;
								echo '<br>tempinsertID array : <br>';
								print_r( $this->tempinsertID );
								echo '<br>tableTree array : <br>';
								print_r ( $this->tableTree );
								echo '<br><strong>params:</strong>';
								print_r($params);
								echo '<br>';
							}

								if( ($isParentTier===true && $ParentID=='') || ( $isParentTier===false && $ParentID!='' )){
									//INSERT QUERY
									if($this->INSERT_SIMU===false) {
										$lastID=$this->Database->core_query_insert($table, $params, $colnames ,$colvalues);
										
									} else {
										$lastID=rand(10000,10010);
									}
									
									if($lastID!==false) $_SESSION['_INSERT_COUNTER']++;
									
								} else {
									$lastID=false;
								}
								
								
								if($lastID===false) {
									//No insertion done
									echo $this->RED_DIV; echo 'Error inserting data(s).<!--',$colnames,'--></div>';
									$this->insertIDERROR=true;
									$DONE = false;
								} else {
									//Insertion is done
									//update the FV[][] data..
									$colnamesArr=explode(',',str_replace(' ','',$colnames));
									$ivaluesArr=explode(',',str_replace("'",'',$ivalues) );
									
									foreach(array_keys($colnamesArr) as $i){
										//set
										$showInsertedData = isset( $this->FS_LAYOUT[$datagrpinfo]['_fs_type']['_show_data_after_insert'] ) ? $this->FS_LAYOUT[$datagrpinfo]['_fs_type']['_show_data_after_insert'] : true;
										if($showInsertedData) $this->_FV[$datagrpinfo.'.'.$lastID][$colnamesArr[$i].'.'.$x_arr[1]]=$ivaluesArr[$i];
										//unset
										unset( $this->_FV[$datagrpinfo][$colnamesArr[$i].'.'.$x_arr[1]] );
										
										if($this->INSERT_DIA){
											//Create new _FV
											echo $this->DIA_LINE;
											echo '[tempinsertID array]';
											print_r( $this->tempinsertID );
											echo '<br>Create _FV['.$datagrpinfo.'.'.$lastID.'][',$colnamesArr[$i].'.'.$x_arr[1].']=',$ivaluesArr[$i],'<br>';
											//unset old _FV
											echo 'Unset _FV['.$datagrpinfo.'][',$colnamesArr[$i].'.'.$x_arr[1].']<br>';
											
										} //if($this->INSERT_DIA){
									}
								 
									//place into teminsertID to store the infos
									$this->tempinsertID[$x]=$lastID;
									//$this->tableTree[$datagrpinfo_tmp]=$x_arr[1];
									
									//REMOVE FROM _POST
									//if(isset($_POST['_FN'][$datagrpinfo])) unset($_POST['_FN'][$datagrpinfo]);
									//echo '<h1>updated _POST INSERT</h1>';print_r($_POST);
									$DONE = true;
									
								}
								

							
							if($this->INSERT_DIA && $lastID!==false){
								echo $this->RED_DIV;
								echo '<br>datagrpinfo: ',$datagrpinfo;
								echo '<br>x :  ',$x;
								echo '<br>lastID: ',$lastID;
								echo '<br>'; echo '$params: ';print_r($params);
								echo '<br><br>tempinsertID array : <br>';
								print_r( $this->tempinsertID );
								echo '<br><br>Temp Array: <br>';
								print_r ( $temp );
								echo '<h1>';
								echo 'INSERT INTO ',$table,' (',$colnames,') VALUES (',$ivalues,')'; 
								echo '</h1>';
								echo '</div>';	//RED_DIV
								echo '</div>'; //TEST_DIV
							}
							
						}//if($allvalues!=''){
					
					} //foreach $temp	

					
				} //if no error
				
			
			} //DO INSERT

		}
		
		return $DONE;
	}
	
	
	public function getFSColumns($fs_arr){
		
		$fs_col_arr='';
		if(isset($fs_arr)){
			foreach(array_keys($fs_arr) as $k){
				$keyname = explode('.',$k); //echo $k;
				$fs_col_arr[ $keyname[0] ]=$keyname[0];
			}
			
		} else {
			$fs_col_arr=false;
		}
		
		return $fs_col_arr;
	}
	
	//COMPILE ALL THE DELETED DATAS
	public function _FORM_DELETE_PARAM(){
		//print_r( $_POST['_DELE'] );
		//print_r($this->_FV);	
		if(isset($this->FS)){
			foreach(array_keys($this->FS) as $h){
				//echo $h;
				$h_arr = explode('.',$h);
			
				if(isset($_POST['_DELE'])){
					foreach( array_keys($_POST['_DELE']) as $k ){
						//echo $k;
						$k_arr = explode('.',$k);
						//echo $k_arr[0];
						//echo $k_arr[0];
						if($k_arr[0]==$k_arr[0]){
							//add to delete parameter reference
							$key = $h.'.'.$k_arr[1];
							if(isset($this->_FV[ $key])){
								//print_r($this->_FV[ $key]);
								$this->DELETED_DATA [ $key ] = $this->_FV[ $key];
								//print_r($this->DELETED_DATA);
							}
						}
					}			
				}
			}
		}
		
	}
	
	private $_DEL_REF;
	public function _FORM_DELETE_MAIN(){
		//print_r(json_decode($_POST['Chked_Hist']));
		
		if(!empty($_POST['_CHKED'])){
			if(is_array($_POST['_CHKED'])){
				foreach(array_keys($_POST['_CHKED'])as $fsid_id ){
					$tmp = explode('.',$fsid_id);
					//safety check: i expect an array of size 3 from given $_POST['_CHKED']
					if( sizeof($tmp)==3 ){
						$_DELE[] = array($tmp[1],$tmp[2]);
					}
				}
			}
		}
		
		
		//GET FROM AJAX
		if(!empty($_POST['Chked_Hist'])) {
			$arr = json_decode($_POST['Chked_Hist']);
			//_print_r($arr);
			
			foreach($arr as $k){
				//_echo($k);
				$tmp = explode('.',$k);
				//_print_r($tmp);
				//safety check: i expect an array of size 3 from given $_POST['Chked_Hist']
				if( sizeof($tmp)==3 ){
					$_DELE[]=array($tmp[1],$tmp[2]);
				};
			}

			//_print_r($_DELE);
		}
		//_print_r($_POST['Ajax_Action']);
		$_AJAX_ATN = isset($_POST['Ajax_Action']) ? $_POST['Ajax_Action'] : '';
		
		//DELETION
		if( isset($_DELE) || $_AJAX_ATN=='_AJAX_DEL' ){	
			//echo 'DO DELETE';print_r($_DELE);
			if($this->DEL_DETAILS) print_r($_DELE);
			
			//_echo('AJAXED FSID='.$_POST['FSID']);

			//_print_r($_DELE);
			foreach(array_keys($_DELE) as $id){
				//_echo ('<h1>'.$id.'-'.$_DELE[$id][0].'-'.$_DELE[$id][1].'</h1>');
				$QSID = $_DELE[$id][0] ; //_echo('QSDID='.$QSID);
				$DataID = $_DELE[$id][1] ; //_echo('DataID='.$DataID);
				if($this->DEL_DETAILS) { echo $this->BLUE_DIV; echo $this->DIA_LINE; print_r( $id ); echo '</div>';  }
				
				unset($vparam);
				unset($dparam);
				unset($this->QUERY_PARAMS);
				
				if($DataID!=''){
					
					if(isset($_POST['FSID'])){
						//This means ajax has occured do a check to see if this is the fsid to exe proc.
						$temp_arr = explode('.',$_POST['FSID']);
						if( $QSID==$temp_arr[1] ) $dparam[ $QSID ][ $this->QS[ $QSID ][ '_keyID' ] ]=$DataID; //print_r($dparam);
					} else {
						//Normal html form submission
						$dparam[ $QSID ][ $this->QS[ $QSID ][ '_keyID' ] ]=$DataID; //print_r($dparam);
					}
					
					
					unset($this->_DEL);
					unset($this->_DEL_REF);
					if($this->DEL_DETAILS) { 
						echo $this->BLUE_DIV,'<h1>Delete Operations Start</h1>'; 
						echo 'table=',$this->QS[ $QSID ]['_table']; 
						echo ' tableID=',$QSID,' keyid=',$this->QS[ $QSID ][ '_keyID' ],' value=',$DataID,'</div>';  
					}
					//$dparam['3a']['CompanyID']=1; // checkbox value=3a.1
					//echo '<h1>QUERY_PARAMS</h1>'; print_r($dparam);
					
					
					if(is_array($dparam)){
						//_echo('Delete');
						$done_del = $this->_FORM_DELETE( $dparam );
					} else {
						PRINT_WARNING_MSG_TEMPLATE('_FORM_DELETE_MAIN().datalogic. $dparam is not array.');
					}
							
					
				} else {
					echo 'No deletion';
					$done_del = false;
				}//if
			}//foreach
		}//if
		return $done_del;
	}//_FORM_DELETE_MAIN
	
	public function _FORM_DELETE( $dparam ){
		$Q_TYPE='Delete';
		$QS=$this->QS;
		
		//FORM _DEL for deletion
		foreach(array_keys($dparam) as $QS_ID){
			foreach(array_keys($dparam[$QS_ID]) as $y){
				//echo '<h1>y-->',$y,'</h1>';
				$params[]=$dparam[$QS_ID][$y]; //echo '<h1>',$dparam[$QS_ID][$y],'</h1>';
				$this->DEL_START_KEY=$y;
				//_echo('<h2>_FORM_DELETE._FORM_QUERY_WRAPPER</h2>');
				$this->_FORM_QUERY_WRAPPER($params ,$QS_ID, '', '', '', $Q_TYPE); //echo '<h1>--->',$QS_ID,'</h1>';
			}
		}
		
		//echo '<h1>this->_DEL</h1>'; print_r($this->_DEL);
		//echo '<h1>this->QUERY_PARAMS</h1>'; print_r($this->QUERY_PARAMS);
		
		$_DEL=$this->_DEL;
		$QS_ID='';
		
		if($this->DEL_DETAILS) echo $this->RED_DIV,$this->DIA_LINE,'<h1>Delete Results</h1>';

		if(is_array($_DEL) || $_DEL!=''){
			foreach(array_keys($_DEL) as $QS_ID){
		
			foreach(array_keys($_DEL[$QS_ID]) as $id){
				
				$strSep='';
				$index='';
				$indexQ='';
				$paramsQ='';
				$do_del=true;
				
				foreach(array_keys($_DEL[$QS_ID][$id]) as $x){
					//echo $id;
					if($_DEL[$QS_ID][$id][$x]!=''){
						$index=$index.$strSep.$id.'='.$_DEL[$QS_ID][$id][$x];
						$indexQ=$indexQ.$strSep.$id.'=? ';
						$paramsQ[]=$_DEL[$QS_ID][$id][$x];
						$strSep=' OR ';
						
						$this->_DEL_REF[] = $QS_ID.'.'.$_DEL[$QS_ID][$id][$x] ;
						
					} else {
						$do_del=false;
					}
				}
				//echo $index;
				
				
			} //foreach
			
			
			
			if($do_del===true){
				if($this->DEL_DETAILS) {
					echo '<br>DELETE FROM ',$QS[$QS_ID]['_table'],' WHERE ',$index; echo '<br>';
					print_r($this->_DEL_REF);
					//Remove deleted stuff from _FV
					
				}
				foreach(array_keys($this->_FV) as $fv_key){
						$fv_key_arr = explode('.',$fv_key);
						$search = $fv_key_arr[1].'.'.$fv_key_arr[2]; //echo $search,'<br>';
						if(array_search($search, $this->_DEL_REF)!==false){
							if($this->DEL_DETAILS) echo 'exist:',$fv_key,'<br>';
							unset($this->_FV[$fv_key]);
							unset($_POST['_FN'][$fv_key]);
						}
					}
				/*
				echo '<br>params:';
				print_r($paramsQ);
				echo '<br>index: ',$indexQ;
				echo '<br>';
				*/
				
				
				//echo $this->Database->core_query_delete('t_invoice', array(867,866),  'InvoiceID=? OR InvoiceID=?');
				
				if($this->_DELETE_U===false){
					//Actual delete
					if($this->DEL_SIMU===false) $this->Database->core_query_delete( $QS[$QS_ID]['_table'] , $paramsQ ,  $indexQ);
				} else {
					
					//Updates status to preset status					
					if(isset($QS[$QS_ID]['_valueEB'])){
						$strSep='';
						foreach( array_keys($QS[$QS_ID]['_valueEB']) as $EBcolname){
							$allow_arr=array('StatusDate','Del_u.Status');
							//echo $EBcolname;
							if(in_array($EBcolname,$allow_arr)){
								if($EBcolname=='Del_u.Status'){
									$uvalues.=$strSep."Status='".$QS[$QS_ID]['_valueEB'][$EBcolname]."'";
								}elseif( $EBcolname=='StatusDate' ) {
									$uvalues.=$strSep.$EBcolname."=".$QS[$QS_ID]['_valueEB'][$EBcolname];
								}
								$strSep=', ';
							}
						}
					}
					//echo $uvalues;
					//echo $index;
					$keyIDArr = explode('=',$index);
					$keyID =$keyIDArr[0];
					$input_id = $keyIDArr[1];
					if($this->DEL_SIMU===false) $this->Database->core_query_update($QS[$QS_ID]['_table'] ,$uvalues,$keyID,$input_id);
				}
					
				
				
				
				
			} else {
				if($this->DEL_DETAILS) echo ' NO DELETE. ',$QS[$QS_ID]['_table'],' WHERE ',$index; echo '<br>';
			}
			
		}//foreach
		}
		if($this->DEL_DETAILS) echo '</div>';
		
		return $do_del;
	}

	public function _FORM_QUERY_MAIN($Q_TYPE='Select'){
		
		$vparam=$this->QUERY_PARAMS;
		$FS=$this->FS;
		
		if(isset($FS)) {
			foreach(array_keys($FS) as $key){
				
				//print_r( $this->FOPS[$key] );
				$FOPS_k = RETRIEVE_VALUE($this->FOPS[$key],false);
				if($FOPS_k!==false){
					foreach(array_keys($FOPS_k) as $i){
						//echo $i;
						foreach(array_keys($FOPS_k[$i]) as $k){
							
							switch ($k){
								case '_showdata':
									$showdata = RETRIEVE_VALUE( $FOPS_k[$i]['_showdata'], false );
									if($showdata){
										//echo $key.' get data';
										$GET_DATA[$key] = true;
									} else {
										$GET_DATA[$key] = false;
									}								
								break;
								
								
							}

						}
						
					}
				}
				
				if($GET_DATA[$key]) {
					$datainfos=explode('.',$key); //echo $key;
						
					//filter no database case
					if( isset($datainfos[1]) ){
						unset($params);
						$QS_ID=$datainfos[1];
						
						//use QS_ID to search FS for datagrp
						$datagrp=$datainfos[0];//$this->getmaindatagrp($QS_ID);
						
						if(is_array($vparam[$QS_ID])) {
							$params = $vparam[$QS_ID];
						} else {
							$params[]=$vparam[$QS_ID];
						}		
						if(!empty($this->QS[$QS_ID]['_table'])){ 
							//print_r($this->QS[$QS_ID]['_table']);
							$this->_FORM_QUERY_WRAPPER($params ,$QS_ID, '', '', $datagrp, $Q_TYPE);
						} else {
							
							if(!empty($this->QS[$QS_ID]['_method'])){ 
								
								$funcName = $this->QS[$QS_ID]['_method'];
								
								//use method to retrieve datas here..
								if(method_exists($this,$funcName)){
									
									$param['FSID'] = $key;
									
									$this->$funcName($param);
								}
							}
							
							
						}
						
					}
				}
			}
		}
		//print_r($GET_DATA);
	}
	
	public function _SEARCH_FILTER( $strFilter,$QS_ID ,$datagrp ){
		$FSID = $datagrp.'.'.$QS_ID;
		//SEARCH FILTER SETTINGS
		if(isset( $this->SEARCH[$FSID] )){

				//echo $this->SEARCH;
				//echo $QS_ID;
				//1) RETRIEVE AND FILTER QUERY PARAMETERS
				$url_queries = '';
				
				$URL_QUERY = $this->Site->REQUEST_PARAMS_P;  //_echo('URL_QUERY==>'); _print_r($URL_QUERY);
				
				foreach( array_keys($URL_QUERY) as $k ) {
				//_echo($k);
				$_blank = trim($URL_QUERY[$k])=='' ? 'blank' : 'not_blank' ;
				//_echo('_blank==>'.$_blank.'   ');
					$k = strtolower($k);

					//echo $k;
					//echo $datagrp.'.'.$QS_ID;
					//print_r($this->FS[$datagrp.'.'.$QS_ID]);
					if( isset( $this->SEARCH[ $FSID ]['FS']  ) && trim($URL_QUERY[$k])!='' ){ 
						//echo '{--'.$k.'='.$this->Site->REQUEST_PARAMS_P[$k].'--}';

							foreach(array_keys($this->SEARCH[ $FSID ]['FS']) as $i){ 
									
								if( $this->SEARCH[ $FSID ]['FS'][ $i ][ '_url_key' ]==$k ) { 
									
									if(isset( $this->SEARCH[ $FSID ]['FS'][ $i ][ '_opperand' ] )) $_opperand = ' '.$this->SEARCH[ $FSID ]['FS'][ $i ][ '_opperand' ].' ';
									
									//CHECK _ctype
									if(isset( $this->SEARCH[ $FSID ]['FS'][ $i ][ '_ctype' ] )) {
										
										$_ctype = $this->SEARCH[ $FSID ]['FS'][ $i ][ '_ctype' ];
										if($_ctype=='numeric'){
											//if(!ctype_digit( $this->Site->REQUEST_PARAMS_P[$k] )){
											if(!ctype_digit( $URL_QUERY[$k] )){
												$this->Site->ERROR_REDIRECT();
											}
										} elseif ($_ctype=='alpha'){
											//if(!ctype_alpha( $this->Site->REQUEST_PARAMS_P[$k] )){
											if(!ctype_alpha( $URL_QUERY[$k] )){
												$this->Site->ERROR_REDIRECT();
											}
										} elseif ($_ctype=='std'){											
											//_STRING_CHECK_STD( $this->Site->REQUEST_PARAMS_P[$k] );
											//echo $Mode = $this->AJAX ? 'ajax' : '';
											_STRING_CHECK_STD( $URL_QUERY[$k]);
										}
									}
									
									if(isset($this->SEARCH[ $FSID ]['FS'][ $i ]['_operator'])){							
										
										switch ($this->SEARCH[ $FSID ]['FS'][ $i ]['_operator']){
											
											case 'less_equal':
												$_operators = '<=';											
											break;
											
											case 'more_equal':
												$_operators = '>=';										
											break;
											
											case 'greater':
												$_operators = '<';									
											break;
											
											case 'less':
												$_operators = '<';									
											break;
											
											case 'like':
												$_operators = 'LIKE';									
											break;
											
											case 'rlike':
												$_operators = 'RLIKE';									
											break;
												
											case 'equal':
												$_operators = "=";
											break;
											
											case 'not_equal':
												$_operators = '<>';
											break;
											
										}
										
										
										
									
										$_operators = ' '.$_operators.' ';
										//if(trim($this->Site->REQUEST_PARAMS_P[$k]!='')) $url_queries = $url_queries.$_opperand.$this->SEARCH['SETTINGS']['FS'][ $i ][ '_key' ].$_operators."'".$this->Site->REQUEST_PARAMS_P[$k]."'";
										//ORIGINAL
										//if(trim($URL_QUERY[$k]!='')) $url_queries = $url_queries.$_opperand.$this->SEARCH['SETTINGS']['FS'][ $i ][ '_key' ].$_operators."'".$URL_QUERY[$k]."'";
										//print_r($URL_QUERY);
										if(trim($URL_QUERY[$k]!='')) { 
											//CHECK FOR SPECIAL MYSQL QUERY FUNCTIONS ELSE FORM NORMAL FILTER																
											if(isset( $this->SEARCH[$FSID]['FS'][ $i ][ '_concat' ] )) {
												$concat = $this->SEARCH[ $FSID ]['FS'][ $i ][ '_concat' ];
												$url_queries = $this->_CONCAT_QUERY( $concat , $URL_QUERY[$k], $_operators, $_opperand );

												//_echo ('url_queries===>'.$url_queries);
												//_echo($URL_QUERY[$k]);
											} else {
												//_echo('<h3>Normal case</h3>');
												$url_queries = $url_queries.$_opperand.$this->SEARCH[ $FSID ]['FS'][ $i ][ '_key' ].$_operators."'".$URL_QUERY[$k]."'";
											}
											
										} else {
											//NO OPERATORS CASE
											
											//if( $this->SEARCH[ $FSID ]['FS'][ $i ]['_url_key']==$k ){
											if( $this->SEARCH[ $FSID ]['FS'][ $i ]['_url_key']==$k ){
												//$sel_option = ucwords( $this->Site->REQUEST_PARAMS_P[$k]);
												$sel_option = ucwords( $URL_QUERY[$k]);
												//echo $this->SEARCH['SETTINGS']['FS'][ $i ]['_customfilter'][$sel_option];
											}
											//if(trim($this->Site->REQUEST_PARAMS_P[$k]!='') && isset($this->SEARCH['SETTINGS']['FS'][ $i ]['_customfilter'][$sel_option])) {
											if(trim($URL_QUERY[$k]!='') && isset($this->SEARCH[ $FSID ]['FS'][ $i ]['_customfilter'][$sel_option])) {
												$url_queries = $url_queries.$_opperand.$this->SEARCH[ $FSID ]['FS'][ $i ]['_customfilter'][$sel_option];
											} else {
												//error...
												//$this->Site->ERROR_REDIRECT();
											}
										}
									} else {
											//NO OPERATORS CASE
											
											//if( $this->SEARCH[ $FSID ]['FS'][ $i ]['_url_key']==$k ){
											if( $this->SEARCH[ $FSID ]['FS'][ $i ]['_url_key']==$k ){
												//$sel_option = ucwords( $this->Site->REQUEST_PARAMS_P[$k]);
												$sel_option = ucwords( $URL_QUERY[$k]);
												//echo $this->SEARCH['SETTINGS']['FS'][ $i ]['_customfilter'][$sel_option];
											}
											//if(trim($this->Site->REQUEST_PARAMS_P[$k]!='') && isset($this->SEARCH['SETTINGS']['FS'][ $i ]['_customfilter'][$sel_option])) {
											if(trim($URL_QUERY[$k]!='') && isset($this->SEARCH[ $FSID ]['FS'][ $i ]['_customfilter'][$sel_option])) {
												$url_queries = $url_queries.$_opperand.$this->SEARCH[ $FSID ]['FS'][ $i ]['_customfilter'][$sel_option];
											} else {
												//error...
												//$this->Site->ERROR_REDIRECT();
											}
									}

								}
							}


					}
				}
				//_echo ('<h3>'.$url_queries.'</h3>');
				//$url_queries = http_build_query ($this->Site->REQUEST_PARAMS_P); echo $url_queries;

				$strFilter = $strFilter.$url_queries;

			
		}
		//echo '<h2>'.$strFilter.'</h2>';
		return $strFilter;
	}
	//Form query strings for CONCAT SEARCHES
	private function _CONCAT_QUERY( $concat , $URL_QUERY ,$_operators, $_opperand  ){

		//echo '<h1>_SEARCH_FILTER().datalogic</h1>';
		$SearchString = urldecode(trim($URL_QUERY));
		$SearchStringArr = explode(' ', $SearchString );
		//print_r( $SearchStringArr );
		//Form Concat string filter
		$concat_str ='';
		$comma ='';
		foreach($concat as $colname){
			$concat_str = $concat_str." ".$comma." IFNULL(".$colname.",'')";
			$comma =',';
		}
		$concat_filter = 'CONCAT('.$concat_str.')';
												
		$url_queries='';
		foreach($SearchStringArr as $Search){
			$url_queries = $url_queries.$_opperand.$concat_filter.$_operators."'".$Search."'";
		}	
		
		return $url_queries;
	}
	public function _ORDERBY_FILTER( $QS_ID, $datagrp ){
		$orderby = '';
		$FSID = $datagrp.'.'.$QS_ID;
		//SEARCH FILTER SETTINGS
		if(isset( $this->FSORT )){
			if( isset($this->FSORT[$FSID])){
					
				//echo $this->FSORT;
				//echo $QS_ID;
				//1) RETRIEVE AND FILTER QUERY PARAMETERS
				$orderby = '';
				$strSep = '';
				foreach( array_keys($this->Site->REQUEST_PARAMS_P) as $k ) {
					//_ETXT( '$this->Site->REQUEST_PARAMS_P[$k]' );
					//_ETXT( $k );
					//$this->Site->REQUEST_PARAMS_P[$k];
					//echo $k;
					//echo $datagrp.'.'.$QS_ID;
					//print_r($this->FS[$datagrp.'.'.$QS_ID]);
					if( isset( $this->FSORT[$FSID]['FS']  ) ){ 
						//echo '{--'.$k.'='.$this->Site->REQUEST_PARAMS_P[$k].'--}';
							
							foreach(array_keys($this->FSORT[$FSID]['FS']) as $i){								
								
								if( $this->FSORT[$FSID]['FS'][ $i ][ '_url_key' ]==$k ) {
									
									//echo $this->Site->REQUEST_PARAMS_P[$k];
									//Check for alphabetic character(s)
									if(!ctype_alpha($this->Site->REQUEST_PARAMS_P[$k])) {
										$this->Site->ERROR_REDIRECT();
									}
									//check for correct input a|d
									switch( $this->Site->REQUEST_PARAMS_P[$k] ){
										case 'a':
											$sortDirn = '';
										break;
										
										case 'd':
											$sortDirn = 'DESC';
										break;
										
										default:
											echo 'k='.$k;
											//CHK IF SEARCH _url_key == FSORT _url_key.
											
											if(isset($this->SEARCH[$FSID]['FS'])){
												$SEARCH = $this->SEARCH[$FSID]['FS'];
												$error = false;
												foreach(array_keys($SEARCH) as $c){
													if( $SEARCH[$c]['_url_key'] ==$k){
														$error = true;														
													}
												}
												if($error===true){
													
													PRINT_WARNING_MSG_TEMPLATE('fs.php setup error.','_url_key cannot be repeated in FSORT and SEARCH settings.');
												} else {
													//request variables are not allowed
													$this->Site->ERROR_REDIRECT();
												}
											}
											
											
									}
									
									$orderby = $orderby.$strSep.$this->FSORT[$FSID]['FS'][ $i ][ '_key' ].' '.$sortDirn;
									$strSep = ', ';

								}
								
							}


					}
				}

			}
			
		} else {
			if(isset($this->QS[$QS_ID]['_order'])){
				//_E_TRACE($this->QS[$QS_ID]['_order'],true);
				$orderby = $this->QS[$QS_ID]['_order'];
			}
		}
		//echo $orderby;
		return $orderby;
	}
	
	private function _LIMIT( $QS_ID, $datagrp ){

		$_LIMIT['strULimit'] = isset($this->QS[$QS_ID]['_ulimit']) ?  $this->QS[$QS_ID]['_ulimit'] : '';
		$_LIMIT['strLLimit'] = isset($this->QS[$QS_ID]['_llimit']) ?  $this->QS[$QS_ID]['_llimit'] : '';
			
		return $_LIMIT;
	}
	
	//$params->params for PDO query execution
	//$QS_ID->the id the table
	public function _FORM_QUERY_WRAPPER( $params,$QS_ID ,$param_counter=0,$tracker="", $datagrp="" ,$Q_TYPE, $prevkeyID='' ) {
		
		$QS=$this->QS;
		$do_query = true;
		
		//$table=$QS[$QS_ID]['_table'];
		//$strFilter=$QS[$QS_ID]['_filter']; //echo '<h1>strFilter---->',$strFilter,'</h1>';		
		//$colnames=$QS[$QS_ID]['_colnames']; 
		//if(isset($QS[$QS_ID]['_order'])) $strOrder=$QS[$QS_ID]['_order']; 
		
		foreach(array_keys($this->QUERY_SETTINGS) as $variable){
			//$$variable = isset( $this->QS[ $QS_ID ][ $this->QUERY_SETTINGS[ $variable ] ] ) ? $this->QS[ $QS_ID ][ $this->QUERY_SETTINGS[ $variable ] ] : '';	
			if( isset($this->QS[ $QS_ID ][ $this->QUERY_SETTINGS[ $variable ] ] ) ) $$variable = $this->QS[ $QS_ID ][ $this->QUERY_SETTINGS[ $variable ] ];
		}
		if(empty($this->QS[ $QS_ID ]['_table'])) $do_query = false;
		
		
		
		//DELETE RELATED SETTINGS.........
		if($Q_TYPE=='Delete'){
			
			//reset INT_COUNTER for delete case and end of loop
			//end of loop is determined by no nextable
			if(isset($QS[$QS_ID]['_tablenext'])){
				$this->INT_COUNTER=0;
				if($QS[$QS_ID]['_tablenext']=='') $this->INT_COUNTER=0;
				
			}
			
			//echo '<h1>COUNTER-->',$this->INT_COUNTER,'</h1>';
			if( $this->INT_COUNTER==0 ){
				$skey= $this->DEL_START_KEY; //_echo ('<h1>DEL_START_KEY--->'.$skey.'</h1>'); 
				$strFilter=$skey.'=?';
				//echo '->',$this->INT_COUNTER;							
			
			}
		}
		
		//SEARCH FILTER PROCESSING
		if($do_query) $strFilter = $this->_SEARCH_FILTER( $strFilter,$QS_ID, $datagrp );
		//_echo('strFilter-->'.$strFilter);
		
		//ORDERBY PROCESSING
		if($do_query) $strOrder = $this->_ORDERBY_FILTER( $QS_ID, $datagrp);
		//$this->_ORDERBY_FILTER( $QS_ID );
		
		//LIMIT PROCESSING
		if($do_query) {
			$_LIMIT = $this->_LIMIT( $QS_ID, $datagrp);
			$strULimit = $_LIMIT['strULimit'];
			$strLLimit = $_LIMIT['strLLimit'];
		}
				
		if(($this->QUERY_DIA && $Q_TYPE=='Select') || ($this->DEL_DETAILS && $Q_TYPE=='Delete')){ 
			echo $this->TEST_DIV; ?><h3>Query</h3><?php echo $table,'<br>'; echo $colnames,'<br>'; echo $strFilter,'<br>'; echo 'params:'; print_r($params); echo '<br>',$QS_ID; echo '<br>param_counter:',$param_counter; echo '<br>tracker:', $tracker; echo '</div>';
		}
		
		//QUERY
		//_echo('<h1>Q_TYPE'.$Q_TYPE.'</h1>');
		//$r=$this->_FORM_QUERY($param_counter, $QS_ID, $table, $params, $colnames, $strFilter ,'','','','',$tracker, $datagrp, $Q_TYPE, $prevkeyID); 
		//echo $QS_ID, $table, $params, $colnames, $strFilter ,$strGroup,$strOrder,$strULimit,$strLLimit,$tracker, $datagrp, $Q_TYPE, $prevkeyID;
		if($do_query) $r=$this->_FORM_QUERY($param_counter, $QS_ID, $table, $params, $colnames, $strFilter ,$strGroup,$strOrder,$strULimit,$strLLimit,$tracker, $datagrp, $Q_TYPE, $prevkeyID); 
		
		//RECURSIVE CALL
		if($r!==false){
			if(($this->QUERY_DIA && $Q_TYPE=='Select') || ($this->DEL_DETAILS && $Q_TYPE=='Delete')){ 
				echo $this->TEST_DIV; ?><h3>$r</h3><?php print_r($r); echo '</div>';
			}
			//echo "<h1>RECURSIVE CALL</h1>";
			unset($params);
			
			if(isset($r['params'])){
				foreach(array_keys($r['params']) as $counter){ 
				
					$params=array($r['params'][$counter]); 
					$prevkeyID=$r['prevkeyID'][$counter]; //echo 'prevKEYID-->'; print_r($prevkeyID);
					$QS_ID=$r['QS_ID']; 
					$tracker=$r['tracker'].'#'.$counter;
					//echo '<strong>TRACKER:',$tracker,'</strong>';
					
					if($Q_TYPE=='Delete') $this->INT_COUNTER++;
					
					if($do_query)  $this->_FORM_QUERY_WRAPPER($params,$QS_ID, $counter, $tracker, $datagrp, $Q_TYPE, $prevkeyID);
				}
			}
			
		}
		if($this->QUERY_DIA) echo "<hr>";	
	}
	
	//1) Performs query
	//1a)Match $row (result) to $variable
	//2) Returns
	//2a)$r['QS_ID'] : Unique of next table
	//2b) $r['params'] : PDO params for next 'inner join'
	public function _FORM_QUERY($param_counter, $QS_ID, $table, $params, $colnames="*", $strFilter="", $strGroup="", $strOrder="", $strULimit="", $strLLimit="", $tracker="",$datagrp="", $Q_TYPE='Select',$prevkeyID=''){
		//Initialise
		$r=false;
		
		//RETRIEVE QS INFORMATION
		$nextID=isset($this->QS[$QS_ID]['_tablenextID']) ? $this->QS[$QS_ID]['_tablenextID'] : "";//get next query ID 
		//echo '<h1>',$nextID,'</h1>';
		$nextTable=isset($this->QS[$QS_ID]['_tablenext']) ? $this->QS[$QS_ID]['_tablenext'] : ""; //next table ID 
		//echo '<h1>',$nextTable,'</h1>';
		$keyID=isset($this->QS[$QS_ID]['_keyID']) ? $this->QS[$QS_ID]['_keyID'] : ""; //primary keyID 
		//echo '<h1>',$keyID,'</h1>';
			
		//Set nextID
		if($nextTable!="") $nextkeyID[]=$row[$key][$nextID]; //echo 'nextkeyID-->'; print_r($nextkeyID);
		
		if($Q_TYPE=='Delete'){
			$strULimit='';
			$strLLimit='';
		}
		
		//QUERY
		//echo $table,'-colnames-',$colnames,'-strFilter-',$strFilter,'-strGroup-',$strGroup,'-strOrder-',$strOrder,'-strULimit-',$strULimit,'-strLLimit-',$strLLimit;
		//!!!!!!** cannot use _DATALOGIC_QUERY due to recursive setups
		//print_r('PARAMS--->'.$params);
		$row=$this->Database->core_query_select($table, $params, $colnames, $strFilter, $strGroup, $strOrder, $strULimit, $strLLimit) ; 
		
		$row_no=sizeof($row);
		
		if(($this->QUERY_DIA && $Q_TYPE=='Select') || ($this->DEL_DETAILS && $Q_TYPE=='Delete')){ echo $this->TEST_DIV; ?><h3>[$ROW]</h3><?php print_r($row); echo '</div>'; }
			
		//SET UP RESULTS
		if($Q_TYPE=='Select' || $Q_TYPE=='Delete') $row_result=$this->assignvalue($row, $QS_ID, $tracker , $datagrp, $prevkeyID); //echo '<h1>row_result</h1>'; print_r($row_result);

		if($Q_TYPE=='Delete') {
			//echo $QS_ID;
			$nextkeyID=$this->getnextkeyID($row, $QS_ID , $datagrp);
			$this->setdeletedata($row,$QS_ID,$keyID);
		}

		
		//RETURNS EMPTY $r if there's no 'inner join'
		if($nextTable!=""){
			$r['QS_ID']=$nextTable;
			$r['params']=$row_result['nextkeyID']; 
			$r['prevkeyID']=$row_result['currkeyID']; 
			$r['tracker']=$tracker;
			//echo '<span class="red">$R-->'; print_r($r); echo '</span>';
		} 
		//echo "<hr>";
		return $r;
	}
	
	//AUOT RETRIEVES AND POPULATES DATAS FOR Database.core_query_select()
	public function _DATALOGIC_QUERY($tableID,$params,$source=''){
		
		$result = false;
		//retrieve query parameters settings from QS / Source where updates to query setting attributes has been done
		foreach(array_keys($this->QUERY_SETTINGS) as $variable){
			if($source==''){
				if(isset( $this->QS[ $tableID ][ $this->QUERY_SETTINGS[ $variable ] ] ))  $$variable = $this->QS[ $tableID ][ $this->QUERY_SETTINGS[ $variable ] ] ;
			} else {
				if(isset( $source[ $tableID ][ $this->QUERY_SETTINGS[ $variable ] ] ))  $$variable = $source[ $tableID ][ $this->QUERY_SETTINGS[ $variable ] ] ;
			}
			
		}
		//print_r($params);	
		
		if(is_array($params)) {
			//echo 'array..do nothing';
		} else {
			//echo 'not array';
			$params = array($params);
		}
		
		$result = $this->Database->core_query_select($table, $params, $colnames, $strFilter, $strGroup, $strOrder, $strULimit, $strLLimit);
		
		return $result;
	}
	
	public function setdeletedata($row,$QS_ID,$keyID){
		//echo $keyID;
		//print_r($QS_ID);
		$empty=true;

		foreach(array_keys($row) as $x){
			foreach(array_keys($row[$x]) as $y){
				if($y==$keyID){
					$empty=false;
					if($this->DEL_DETAILS){
						echo $this->RED_DIV; 
						//print_r($params);
						echo '_DEL[',$QS_ID,']';
						echo '[',$keyID,'][]=';
						echo $row[$x][$keyID];
						echo '<br></div>';
					}
					
					$this->_DEL[$QS_ID][$keyID][]=$row[$x][$keyID];
				}//if
			}//for
		}//for	
		
		if($empty) { 
			echo $this->RED_DIV;
			echo 'Primary key ($keyID) not inserted in QS "_filter" setting. <br>Error: DELETE FROM ... WHERE (MISSING KEY)=?</div>';
		}		
	}
	
	
	public function check_q_tracker($tracker){
		
		//echo '<span class="red">tracker:'; print_r( $tracker ); echo '</span>';
		
		$arr=explode("#", $tracker);
		
		//print_r($arr);
		$arrsize= sizeof($arr);

		$error=false;

		//checks
		if($tracker!=""){
			if($arrsize==0){
				echo '<span class="red"><br>ERROR: tracker is 0.</span>';
				$error=true;
			}
			
			/*if( odd_even_check($arrsize)=='odd') {
				echo '<span class="red"><br>ERROR: tracker is odd number.</span>';
				$error=true;
			}*/
		}
		return $error;
		
	}
	public function _IS_NESTED_DATA( $FSID ){
		$IS_NESTED_DATA = false; 
		if(isset( $this->DATA_INFO[ $FSID ][ 'nested' ])){
			$IS_NESTED_DATA= $this->DATA_INFO[ $FSID ][ 'nested' ]===false ? false : true ;		
		}
		//if($this->DATA_INFO[ $FSID ][ 'nested' ]===false) echo'f';		
		return $IS_NESTED_DATA;
	}
	//Check FOPS
	public function _FOPS_check( $FSID, $Type=''){
		$boolean;
		$FOPS = $this->FOPS [ $FSID ];		
		
		if($Type!=''){
			if(!empty($FOPS)){
				//_ETXT( $FOPS, 'FOPS/FSID' );
				
				foreach( array_keys($FOPS) as $i){
					
					foreach( array_keys($FOPS[$i]) as $k ){
						if($k==$Type){
							//$FOPS[$i][$k];						
							if($FOPS[$i][$k]===true){
								//_ETXT( $FOPS[$i][$k], 'yeah' );
								$boolean = true;
							}							
						}
					}									
				}				
			}			
		} else {
			$boolean = false;
			PRINT_DIA_TEMPLATE('Undefined $Type at _FOPS_check() ',$Type);
		}
		return $boolean;
	}
	
	//Check for FOPS[ FSID ][0]['_update']
	public function _FOPS_have_update( $FSID ){
		$boolean = false;
		//_ETXT( $FOPS, 'FOPS/FSID' );		
		$boolean = $this-> _FOPS_check( $FSID, $Type='_update');
		
		if(isset($this->_OPS_UPDATE)) {
			if($this->_OPS_UPDATE){
				//have ops update
				$boolean = true;
			}
		}
		
		return $boolean;
	}
	
	//Check for FOPS[ FSID ][0]['_insert']
	public function _FOPS_have_insert( $FSID ){
		$boolean = false;
		//_ETXT( $FOPS, 'FOPS/FSID' );		
		$boolean = $this-> _FOPS_check( $FSID, $Type='_insert');
		return $boolean;
	}	
	
	//Check for FOPS[ FSID ][0]['_delete']
	public function _FOPS_have_delete( $FSID ){
		$boolean = false;
		//_ETXT( $FOPS, 'FOPS/FSID' );		
		$boolean = $this-> _FOPS_check( $FSID, $Type='_delete');
		return $boolean;
	}
	
	public function _FOPS_check_core_ops ( $FSID ){
				
		$Update = $this->_FOPS_have_update( $FSID );
		$Insert = $this->_FOPS_have_insert( $FSID );
		$Delete = $this->_FOPS_have_delete( $FSID );
		
		return $boolean = $Update ==true && $Insert == true && $Delete == true ? true : false; 
		
	}
	
	//Updates $_POST with Post_Data captured from Ajax form process
	public function _update_Post_FN ( $Post_Data, $Post_Value ){

		
		if(!empty($Post_Data)){
			//Parse Post_data
			$Post_Data = str_replace('_FN','',$Post_Data);
			$Post_Data = str_replace('[','',$Post_Data);
			$Arr = explode(']',$Post_Data);
			unset($Arr[2]); //remove the last empty array due to the way the data is parsed.
			//_print_r($Arr);
			
			//Reform the data
			$rArr['_FN'][$Arr[0]][$Arr[1]] = $Post_Value;
			//_print_r($rArr);	
			$_POST['_FN'][$Arr[0]][$Arr[1]] = $Post_Value;
			//_print_r($_POST['_FN'][$Arr[0]][$Arr[1]] );
			//_echo($Arr[0].$Arr[1]);
		}

	}	
	private function check_ops ( $ops_params ){
		//print_r($ops_params);
		$datagrpinfo = $ops_params['datagrpinfo'];
		$colname = $ops_params['colname'];
		$colname_info = $ops_params['colname_info'];
		$x = $ops_params['x'];
		$temp = $ops_params['temp'];
		
		
		$final_value = false;
		//print_r($this->FS);
		if( isset($this->FS[ $datagrpinfo ])){
			foreach(array_keys($this->FS[ $datagrpinfo ]) as $colnameKey){ //echo $colnameKey;
				$colnameKeyArr = explode('.',$colnameKey);
					if($colnameKeyArr[0] == $colname){ //echo $colname;
						if(isset($this->FS[ $datagrpinfo ][ $colnameKey ][ '_ops' ])){
							$opsArr = $this->FS[ $datagrpinfo ][ $colnameKey ][ '_ops' ]; //echo '_opsArr--->';print_r($opsArr);
							
							foreach(array_keys($opsArr) as $op_func){ //echo $op_func;
								//$op_func2 = '_'.$op_func; //old version requires '_'
								$op_func2 = $op_func;
								//call function
								if(method_exists($this, $op_func2)){ //echo 'x==>',$x,'<br>';
								
									$op_func_params['params'] = $opsArr[$op_func];
									$op_func_params[ 'datas' ] = $temp[$x];
									$op_func_params['FSID'] = $ops_params['datagrpinfo'];
									//$op_func_params['colname_info'] = $ops_params['colname_info'];
									$op_func_params['colname'] = $ops_params['colname'];
									$op_func_params['x'] = $ops_params['x'];
									//$op_func_params['temp'] = $ops_params['temp'];
									
									//_E_TRACE($op_func_params,true);
									$final_value = $this->$op_func2( $op_func_params); //echo '<h1>',$temp[$x][$colname_info],'</h1>';
								} else {
									echo 'Error: Function does not exist.';
								}

							}
											
						}
					} //if($colnameKeyArr[0] == $colname)
			} //foreach			
		}

		//echo '<h1>final_value',$final_value,'</h1>';
		
		return $final_value;
	}

	
	public function getnextkeyID($row, $QS_ID, $datagrp){ //echo '<h1>',$QS_ID,'</h1>';

			$nextkeyID=array();
			$QS->$this->QS;

			foreach(array_keys($row) as $key){ 
			
				//echo '$row[',$key,'][',$this->QS[$QS_ID]['_tablenextID'],']<br>';
				$nextkeyID[$key]=$row[$key][$this->QS[$QS_ID]['_tablenextID']];

				//if($this->DEL_DETAILS) echo '<br><br>';
			}//foreach
		

		return $nextkeyID;
	}
	
	public function assignvalue($row, $QS_ID, $tracker, $datagrp, $prevkeyID){
		//_echo('assignvalue');
		//echo 'prevkeyID--->',$prevkeyID;
		//checks tracker for proper formatting
		$error=$this->check_q_tracker($tracker);
		
		if($error===false){
		
			$nextkeyID=array();
			$QS=$this->QS;
			//_print_r($row);
			foreach(array_keys($row) as $key){ 
			
				unset($temp);
				foreach(array_keys($row[$key]) as $rowkey){ 
					//FORM ID
					//end reuslt : _D[ datagrp[columnname+tracker] ] eg _D[ a[Title.#0#0#0] ]
					
					$input_infos =$rowkey.'.'.$tracker.'#'.$key;
					
					//Filter for primary key
					if($QS[$QS_ID]['_keyID']==$rowkey){
						$temp['t_keyid']=$row[$key][$rowkey]; //_echo ('<h2>tempID:',$temp['t_keyid'],'</h2>');
					} else {
						$temp[$input_infos]=$row[$key][$rowkey];
					}
					
					
					$arr['nextkeyID'][$key]=$row[$key][$this->QS[$QS_ID]['_tablenextID']];
					$arr['currkeyID'][$key]=$temp['t_keyid'];
					
				}//foreach
				
				if($this->QUERY_DIA) print_r($temp); //_print_r($temp);

				//Assign values into _D arr
				foreach(array_keys($temp) as $input_infos){
				
					//echo $datagrp,'<br>';
					//echo 'prevkeyID--->',$prevkeyID;
					$prevkeyIDL = $prevkeyID=='' ? '' : '.'.$prevkeyID ; //echo 'prevkeyIDL-->',$prevkeyIDL;
					$QS_IDL = $QS_ID=='' ? '' : '.'.$QS_ID;
					
					if( $temp['t_keyid']=='' && $QS_ID!='' ) $t_keyidL='.';
					if( $temp['t_keyid']=='' && $QS_ID=='' ) $t_keyidL='';
					if( $temp['t_keyid']!='' ) $t_keyidL='.'.$temp['t_keyid'] ;
										
					$data_info=$datagrp.$QS_IDL.$t_keyidL.$prevkeyIDL; //echo '>datagrp='.$datagrp.' QS_IDL='.$QS_IDL.' t_keyidL='.$t_keyidL.' prevkeyIDL='.$prevkeyIDL.' $temp[t_keyid]='.$temp['t_keyid'],'<br>';
					
					
					if($this->QUERY_DIA){ echo $this->RED_DIV; echo '_D[',$data_info,'][',$input_infos,']=';  echo $temp[$input_infos]; echo '</div>'; } 
					$this->_D[ $data_info ][$input_infos]=$temp[$input_infos];

					
				}
				
				if($this->QUERY_DIA) echo '<br><br>';
			}//foreach
		//_print_r($this->_D);
		}//no error

		return $arr;
	}

	
	public function getmaindatagrp($QS_ID){
		$FS=$this->FS;
		$datagrp=false;
		//echo '<span class="red">'; echo $QS_ID; echo '</span>';
		
		foreach(array_keys($FS) as $key){
			if(strpos($key,$QS_ID)!==false){
				$arr=explode('.',$key);
				$datagrp=$arr[0];
			}
		}
		return $datagrp;
	}
	
	public function getdatagrp(){
		
		$FS=$this->FS;
		
		foreach(array_keys($FS) as $x){
			$x_arr=explode('.',$x);
			
			$datagrp[]=$x_arr[0];
		}
		
		return $datagrp;
	}
	
	public function get_inputinfos($input_infos){
	
		$arr=explode('.',$input_infos);
		//print_r($arr);
		
		$r['colname']=$arr[0];
		
		return $r;
		
	}

	public function get_datainfos($data_infos){

		$arr=explode('.',$data_infos);
		
		//eg: $data_infos = 'datagrp'.'input_info'.'input row id';
		//eg: a.0#3a.1
		
		$r['datagrp']=isset($arr[0]) ? $arr[0] : '' ;
		$r['qs_id']=isset($arr[1]) ? $arr[1] : '' ;
		$r['ip_id']= isset($arr[2]) ? $arr[2] : '' ;
		$r['parent_id']= isset($arr[3]) ? $arr[3] : '' ;
		
		return $r;
	}
	
	//get tier infos
	public function get_tier_infos($FV_NameTier){
		//echo $FV_NameTier;
		$FV_NameTierArr = explode('.',$FV_NameTier); //eg: Name.#0#1#0
		//_print_r($FV_NameTierArr); //eg. #0#1#0
		$r['Name'] = $FV_NameTierArr[0];
		
		//$FV_NameTierArr[1]='#5#3#0';
		if(isset($FV_NameTierArr[1])){
			$FV_NameTierArrExplode = explode('#',$FV_NameTierArr[1]); //print_r($FV_NameTierArrExplode);
			$r['TierLevel'] = sizeof($FV_NameTierArrExplode) -1 ;
			$r['Tiers'] = $FV_NameTierArr[1];
			
			
			
			if($r['TierLevel'] == 1){
				$r['TierPrev'] = '';
			} else {
				//form retain portion
				$strSep='';
				$r['TierPrev']='';
				for( $k=0; $k<$r['TierLevel'] ; $k++){
					$r['TierPrev'] = $r['TierPrev'].$strSep.$FV_NameTierArrExplode[$k];
					$strSep='#';
				}
			}
			
			//echo $r['TierPrev'];
			
		} else {
			$r['TierLevel'] = 1;
			$r['TierPrev'] = '';
		}
		
		$r['TierPrev'] = $r['TierPrev'].'#';
		
		return $r;
	}
	

	/*
	****************************************************
	retrieve FS input_info
	****************************************************
	*/
	public function FS_input_info($grpinfos,$input_infos, $returnGrpinfos=false){
		if( $this->FS_input_info_DIA) { 
			echo $this->DIA_LINE;
			echo '<h3>pre-processed grpinfos:',$grpinfos,'<br>input_infos:',$input_infos,'</h3>';
		}
		$r='';
		$FS=$this->FS;
		
		//Get datagrp from grpinfos
		$arr=explode('.',$grpinfos);
		$datagrp=$arr[0];
		
		//get input_infos size
		$arr_info=explode('.',str_replace('#','.',str_replace('.','',$input_infos)));
		$arr_info_size=sizeof($arr_info); //echo '-->',$arr_info_size; print_r($arr_info);
		$input_infos_size= $arr_info_size==2 ? 1 : $arr_info_size ;
		$search_key=$arr_info[0];

		foreach(array_keys($FS) as $x){ 
			$x_arr=explode('.',$x);
			if($datagrp==$x_arr[0]){
				//echo '<br>datagrp:',$datagrp,'<br>x_arr[0]:',$x_arr[0];
				//print_r($FS[$x]);
				$T_FS=$FS[$x];
				if($returnGrpinfos) $r=$x;
				break;
			}
		}
		
		//print_r($T_FS);
		if($returnGrpinfos===false && isset($T_FS)) {
			foreach(array_keys($T_FS) as $y){
				$y_arr=explode('.',$y);
				$ysize=sizeof($y_arr); //echo $y_arr[0],'-',$search_key,'-',$ysize,'-',$input_infos_size,'<br>';

				if($y_arr[0]==$search_key ){ //&& $ysize==$input_infos_size){
					if( $this->FS_input_info_DIA) { 
						echo '<br>y_arr[0]',$y_arr[0];
						echo '<br>search_key: ',$search_key;
						echo '<br>ysize: ',$ysize;
						echo '<br>input size: ',$input_infos_size;
					}
					$r=$y;
					break;
				}
			}
		}
		
		if( $this->FS_input_info_DIA) { 
			if($returnGrpinfos) { 
				echo $this->RED_DIV; echo '<h3>Return GrpInfo: ',$r,'</h3></div>'; 
			} else {
				echo $this->RED_DIV; echo '<h3>Return input_infos: ',$r,'</h3></div>'; 
			} 
		}
		
		return $r;
	}
	public function _get_sibling_datas_queryID ( $FSID ,$Tier ){
		$FV = $this->_FV;
		$ID = false;
		foreach(array_keys($FV) as $FSID_ID ){
			//echo $FSID_ID;
			foreach(array_keys($FV[$FSID_ID]) as $k){
				//echo $k.'<br>';
				$k_arr = explode('.',$k);
				if(!empty($k_arr[1])){
					if( $k_arr[1]==$Tier ) {
						//echo $FSID_ID.'<br>';
						$ID_arr = explode('.', $FSID_ID); //print_r($ID_arr);
						if(isset($ID_arr[2])) $ID = $ID_arr[2];
						break;
					}
				}
			}
		}
		//echo $ID;
		return $ID;
	}	
	/*
	****************************************************
	retrieve FS array info
	****************************************************
	*/
	public function get_FS($datagrpinfos, $colname, $info){
		$result = false;
		foreach(array_keys($this->FS[$datagrpinfos]) as $key2){ 
			$key2Arr = explode('.', $key2);
			if($key2Arr[0] == $colname){
				if(isset($this->FS[$datagrpinfos][$key2][$info])) {
					//echo $this->FS[$datagrpinfos][$key2][$info];
					$result = $this->FS[$datagrpinfos][$key2][$info];
				}
			}
		}
		
		return $result;
	} //get_FS

	/*
	****************************************************
	Find and retrieve _FV data 
	****************************************************
	*/
	public function extract_FV( $FSID, $ColumnName ){
		
		$found = false;
		if(!empty($this->_FV)){			
			$_FV = $this->_FV;	//print_r($_FV);	
			foreach( array_keys($_FV) as $string ) {

				$pos = strpos($string, $FSID);
				if ($pos !== false) {
					foreach(array_keys($_FV[$string]) as $k) {
						
						$pos2 = strpos($k, $ColumnName);
						if($pos2!==false) $found[$string.'~'.$k] = $_FV[$string][$k];			
					}

				}		
			}
			//print_r($found);			
		}
		
		return $found;
	}
/*
****************************************************	
FS "mod" methods
Modifies data displays
****************************************************
*/
public function _mod_demo(){
	echo 'hello, this is _mod_demo';
}
public function _mod_get_D_involved($inputs, $parent_method ){
	//print_r($this->_D);
	//print_r($inputs);
	//Retrieve FS columns involved
	$_d_used = false;
	if(!empty($inputs['mod'])){
		
		foreach(array_keys($inputs['mod']) as $key ){
			if($parent_method == $key) $fs_columns_involved = $inputs['mod'][$key];
		}
		
		$FSID = $inputs['grpinfos'];

		//get current tier involved
		$tier = $inputs['tiers'];
		
		//get id
		$id = $inputs['id'];
				
		//print_r($this->_D);
		//Retrieve columns values..
		foreach($fs_columns_involved as $k){
			if($k!=='t_keyid'){
				$_d_used[$k] = $this->_D[$FSID.'.'.$id][$k.'.'.$tier];
			} else {
				$_d_used[$k] = $this->_D[$FSID.'.'.$id][$k];
			}
			
		}		
	}
	return $_d_used;
}
public function _mod_get_columns_involved($inputs, $parent_method ){
	//Retrieve FS columns involved
	$fv_used = false;
	if(!empty($inputs['mod'])){
		foreach(array_keys($inputs['mod']) as $key ){
			if($parent_method == $key) $fs_columns_involved = $inputs['mod'][$key];
		}
		
		$FSID = $inputs['grpinfos'];

		//get current tier involved
		$tier = $inputs['tiers'];
		
		//get id
		$id = $inputs['id'];
		
		//Retrieve columns values..
		foreach($fs_columns_involved as $k){
			$fv_used[$k] = $this->_FV[$FSID.'.'.$id][$k.'.'.$tier];
		}		
	}
	return $fv_used;
}
/*
****************************************************
FS OPS Methods
****************************************************
NOTe:
FOR FS OPS, values returned by methods here will be appended as value automatically during INSERT OR UPDATE loop in _FORM_UPDATE_INSERT_MAIN

Examples of how this is entered in FS in front end
"_ops"=>array("sum"=>array("Block","PostalCode")),	
"_ops"=>array("md5"=>array("colname")),
*/

public function _multiply( $op_func_params ){ 
	$opsArr = $op_func_params['params']; //_print_r($op_func_params['params']); //params defined in FS
	$dataset = $op_func_params[ 'datas' ]; //print_r($op_func_params[ 'datas' ]); //your row datas
	
	//echo '<br>_opsArr--->';print_r($opsArr); echo '<br>dataset--->';print_r($dataset);
	
	//FORM VARIABLE KEY FIRST
	$sum_arr = array();
	foreach($opsArr as $variable){
		$sum_arr[$variable] = $dataset[$variable ]; 
	}
	//echo '<br>--->';print_r($sum_arr);

	
	$total = 1;	
	foreach(array_keys($sum_arr) as $x){
		if(!is_numeric($sum_arr[ $x ])){
			echo $sum_arr[ $x ].' is not numeric.';
		} else {
			$total = $total * $sum_arr[ $x ];
		}
		
	}
	//echo '<h1>',$total,'</h1>';
	return $total;
	
}

public function _sum( $op_func_params ){ 
	$opsArr = $op_func_params['params']; //_print_r($op_func_params['params']); //params defined in FS
	$dataset = $op_func_params[ 'datas' ]; //print_r($op_func_params[ 'datas' ]); //your row datas
	
	//echo '<br>_opsArr--->';print_r($opsArr); echo '<br>dataset--->';print_r($dataset);
	
	//FORM VARIABLE KEY FIRST
	$sum_arr = array();
	foreach($opsArr as $variable){
		$sum_arr[$variable] = $dataset[$variable ]; 
	}
	//echo '<br>sum_arr--->';print_r($sum_arr);

	
	$total = 0;	
	foreach(array_keys($sum_arr) as $x){
		$total = $total + $sum_arr[ $x ];
	}
	//echo '<h1>',$total,'</h1>';
	return $total;
	
}

public function _M_Y_append_D ( $op_func_params ){ //_echo ('_M_Y_append_D');
	return $op_func_params[ 'datas' ][ $op_func_params[ 'params' ][0] ].'-00'; 
}

public function _sqlmd5( $op_func_params ){ 
	//print_r ($op_func_params[ 'params' ]);
	//print_r ($op_func_params[ 'datas' ]);
	return $result = MD5($op_func_params[ 'datas' ][ $op_func_params[ 'params' ][0] ]); 
}



public function _loginAdmin(){	

	$Username=$this->_FV['a.1a']['Username.#0'];
	$Password=$this->_FV['a.1a']['Password.#0'];
	
	$this->Login->_DO_ADMIN_LOGIN($Username,$Password);	
}

/*
****************************************************
SANITIZE Methods
****************************************************
*/
public function _CLEAN_FILTER_SANITIZE_EMAIL( $email , $params='' ){ 
	//_E_TRACE('_FILTER_SANITIZE_EMAIL');
	$email = makesafe_string($email); // further hardened.
	return filter_var($email, FILTER_SANITIZE_EMAIL);
}
public function _CLEAN_FILTER_SANITIZE_STRING( $str , $params='' ){ 
	//_E_TRACE('_FILTER_SANITIZE_EMAIL');
	$str = makesafe_string($str); // further hardened.
	//$str = filter_var($str, FILTER_SANITIZE_STRIPPED);
	//$str = filter_var($str, FILTER_SANITIZE_ENCODED, FILTER_FLAG_STRIP_HIGH);
	return filter_var($str, FILTER_SANITIZE_STRING,FILTER_FLAG_ENCODE_HIGH );
}
/*
****************************************************
Diagnostic Methods
****************************************************
*/

public function _print_D_DIA($Title=''){
	if($this->_D_DIA){
		PRINT_DIA_TEMPLATE ('_D.'.$Title, $this->_D);
	}
}
public function _print_POST_DIA( $Title=''){
	if($this->SHOW_POST){
		PRINT_DIA_TEMPLATE ('_POST.'.$Title, $_POST);
	}
}
public function _print_POST_D_DIA( $Title=''){
	if($this->SHOW_POST){
		PRINT_DIA_TEMPLATE ('_POST[Ajaxed_D] non urlencoded.'.$Title, $_POST['Ajaxed_D']);
	}
}
public function _PRINT_DATALOGIC_DIA_MSG($Title){
	$this->_print_POST_DIA($Title);
	$this->_print_D_DIA($Title);	
	$this->_print_POST_D_DIA($Title);	
}
/*
****************************************************
QS OPS Methods
****************************************************
*/

//Forms keywords concatenate without column name
public function _qs_concatenate ($QS_paramArr ,$datagrpinfo, $fs_datainfo, $QS_ID, $TierInfo){
	
	$string='';
	$strSep='';
	//print_r($QS_paramArr);	
	//echo '<br>datagrpinfo: ',$datagrpinfo, '<br>fs_datainfo: ',$fs_datainfo, '<br>QS_ID: ',$QS_ID, '<br>TierInfo: ',$TierInfo;
	foreach($QS_paramArr as $params){

		//echo '<br>$_POST[_FN]['.$datagrpinfo.']['.$params.'.'.$TierInfo.']=',$_POST['_FN'][$datagrpinfo][$params.'.'.$TierInfo],'<br>';
		if(isset($_POST['_FN'][$datagrpinfo][$params.'.'.$TierInfo])){
						
			//Insert value into string
			if($_POST['_FN'][$datagrpinfo][$params.'.'.$TierInfo]!='') $string = $string.$strSep.' '.$_POST['_FN'][$datagrpinfo][$params.'.'.$TierInfo];
		
		}
		
		$strSep=' ';
	}
	
	return $string;
}


//Forms keywords concatenate with column name
public function _qs_kw_concatenate ($QS_paramArr ,$datagrpinfo, $fs_datainfo, $QS_ID, $TierInfo){
	
	$string='';
	$strSep='';
	//print_r($QS_paramArr);	
	//echo '<br>datagrpinfo: ',$datagrpinfo, '<br>fs_datainfo: ',$fs_datainfo, '<br>QS_ID: ',$QS_ID, '<br>TierInfo: ',$TierInfo;
	foreach($QS_paramArr as $params){
		$_alias='';
		echo '<br>$_POST[_FN]['.$datagrpinfo.']['.$params.'.'.$TierInfo.']=',$_POST['_FN'][$datagrpinfo][$params.'.'.$TierInfo],'<br>';
		if(isset($_POST['_FN'][$datagrpinfo][$params.'.'.$TierInfo])){
						
			//Insert value into string
			if($_POST['_FN'][$datagrpinfo][$params.'.'.$TierInfo]!=''){
				//get alias name
				if(isset($this->FS[$fs_datainfo][$params]['_alias'])){
					$_alias = $this->FS[$fs_datainfo][$params]['_alias'];
				} else{
					//for case there is no alias defined.
					$_alias = $params;
				}
				
				$string = $string.$strSep.$_alias.' '.$_POST['_FN'][$datagrpinfo][$params.'.'.$TierInfo];
			}			
		}
		
		$strSep=' ';
	}
	
	return $string;
}



public function _qs_dfirst ($QS_param ,$datagrpinfo, $fs_datainfo, $QS_ID, $TierInfo){
	
	$return = '';
	//print_r($this->QS[$QS_param]);
	if(isset($this->QS[$QS_param])){

		foreach(array_keys($this->QUERY_SETTINGS) as $variable){
			if(isset( $this->QS[ $QS_param ][ $this->QUERY_SETTINGS[ $variable ] ] )) $$variable = $this->QS[ $QS_param ][ $this->QUERY_SETTINGS[ $variable ] ] ;			
		}
		
		if(isset($filtercols)){
			foreach($filtercols as $f_colname){
				//echo $_POST['_FN'][$datagrpinfo][$f_colname.'.'.$TierInfo];
				$params[]=$_POST['_FN'][$datagrpinfo][$f_colname.'.'.$TierInfo];
			}
		}

		$result = $this->Database->core_query_select($table, $params, $colnames, $strFilter, $strGroup, $strOrder, $strULimit, $strLLimit);
		//print_r($result);
		
		if(isset($ops_return)){ 
			$return = $result[0][ $ops_return ];	
			//Insert into _FN
			$_POST['_FN'][$datagrpinfo][$ops_return.'.'.$TierInfo] = $return;
			
		}		
		
	}
	return $return;
}

public function email_get_form_table($display_columns){
	//print_r( $_POST['_DELE'] );
	
	$FV = $this->_FV;
	//print_r($FV);
	//print_r($this->DELETED_DATA);
	
	//IF THERE ARE DATA DELETED REPLACE FV WITH DELETED_DATA
	if(isset($this->DELETED_DATA)){
		if(sizeof($this->DELETED_DATA)>0){
			$FV = $this->DELETED_DATA;
		}
	}
	
	foreach(array_keys( $FV ) as $key){
		//echo $key;
		$keyArr = explode('.',$key);
		$FS_key = $keyArr[0].'.'.$keyArr[1];
		
		$exception_arr = array('select','select_display');
		
		$Body.= '<br><table>';
		foreach(array_keys($FV[ $key ]) as $key2){
				
				$key2pArr = explode('.',$key2);
				$key2p = $key2pArr[0];
				//echo $this->FS[ $FS_key ][ $key2p ][ '_type' ];
				
				if(in_array($key2p,$display_columns)){
					$Body.= '<tr>';
					if(strlen(str_replace(' ','',$FV[ $key ][ $key2 ]))!=0) {
						if( !in_array( $this->FS[ $FS_key ][ $key2p ][ '_type' ] , $exception_arr ) ){
							$Body.= '<td style="width:100px;"><strong>';
							$Body.= $this->FS[ $FS_key ][ $key2p ][ '_alias' ];
							$Body.= '</strong></td>';
							$Body.= '<td style="width:200px;">';
							$Body.= ' : '.$FV[ $key ][ $key2 ];
							$Body.= '</td>';
						} else {
							$datagrp = $this->FS[ $FS_key ][ $key2p ][ '_group_gen' ];
							$id_key = $this->QS[$datagrp]['_group_gen_id']; //echo '------->',$id_key;
							$group_gen_displayname = $this->QS[$datagrp]['_group_gen_displayname']; //echo '------->',$group_gen_displayname;
							
							//Retrieve for vehicle number from misc data..
							foreach(array_keys($this->MISC_DATA) as $k){ 
								foreach(array_keys($this->MISC_DATA[$k]) as $k2){ 
										
										if(isset($this->MISC_DATA[$k][$k2]['_group_gen'])){ 
											foreach(array_keys($this->MISC_DATA[$k][$k2]['_group_gen']) as $i){ 
											
												//echo trim( $this->MISC_DATA[$k][$k2]['_group_gen'][ $i ][ $id_key ]),' == ',trim($FV[ $key ][ $key2 ]),'<br>';
												if( trim( $this->MISC_DATA[$k][$k2]['_group_gen'][ $i ][ $id_key ]) == trim($FV[ $key ][ $key2 ]) ){
													
													//echo '-x---->',$FV[ $key ][ $key2 ];
													//echo $this->MISC_DATA[$k][$k2]['_group_gen'][ $i ][ $id_key ],' == ',$FV[ $key ][ $key2 ],'<br>';
													$Body.= '<td style="width:100px;"><strong>';
													$Body.= $this->FS[ $FS_key ][ $key2p ][ '_alias' ];
													$Body.= '</strong></td>';
													$Body.= '<td style="width:200px;">';
													$Body.= ' : '.$this->MISC_DATA[$k][$k2]['_group_gen'][ $i ][ $group_gen_displayname ];
													$Body.= '</td>';
												}
											}
										}

								}
							}
						}
						
					}
					$Body.= '</tr>';
					
				}	
				
		}
		
		$Body.= '</table>';
		
	}
	return $Body;
}
public function email_create_body( $params ){
	//BODY
	if(isset($params['Body'])){
		$Body.=$params['Body'];
	} else{
		$Body.='Hello,';
	}
	$Body.= '';	
	
	//PUTS FORM INFO INTO EMAIL BODY
	if($params[ 'Fields' ]) $Body.= $this->email_get_form_table($params[ 'Fields' ]);
	$Body.= '<br><br>';
	
	//SIGNATURE
	if(isset($params['Signature'])){
		$Body.=$params['Signature'];
	} else{
		$Body.='System Notification';
	}
	return $Body;
}

public function email_set_mailer_datas( $params ){
	
	$arr = false;
	$email_datas = array(
			'Username', 
			'Password' , 
			'Replyto' ,
			'Replytoname' ,
			'From' ,
			'Fromname' ,
			'To' ,
			'Body' ,
			'Subject' ,
			'Host' ,
			'Port' ,
			'SMTPAuth' ,
			'SMTPDebug' ,
			'SMTPSecure' ,
			'_SENDMAIL' 
		);
	
	//SETTING UP FOR TESTING PURPOSE
	//*************************************************************	
	if( isset($this->Settings->_MAIL_TEST) && isset($_GET['_email_test']) ){
		
		//RETRIEVE BASED ON test settings
		if( $_GET['_email_test']==1 ) {
			//Use developer test settings 
			$mail_settings = $this->Settings->_MAIL_TEST;
		} elseif( $_GET['_email_test']==2 ) {
			//Use local fs test settings
			$mail_settings = $params['_TEST'][0];
			//print_r($test_mail);
		}
		

	} else {
		//USE NORMAL SETTINGS
		
		//1) Check which global mail setting to use
		
		if(isset($params['mail'])){
			if (strpos($params['mail'], '[') !== FALSE && strpos($params['mail'], ']') !== FALSE){
				$t_arr = explode('[',$params['mail']);
				$mail_arr = $t_arr[0];
				$t_arr[1] = str_replace(']','',$t_arr[1]);

				$mail_settings_t = $this->Settings->$mail_arr;	
				//print_r($mail_settings_t[ $t_arr[1] ]);
				$mail_settings = $mail_settings_t[ $t_arr[1] ];
				//print_r($mail_settings);
				//print_r($params);
				
				//Replace with params aka the local overrides...
				foreach(array_keys($mail_settings) as $k){
					//echo $k;
					if(isset($params[$k])){
						//echo $k;
						$mail_settings[$k] = $params[$k];
					}
				}
			
			} else{
				$mail_settings = $this->Settings->$params['mail'];
			}
					
			//echo '<hr>'; echo $params['mail'];  print_r($mail_settings);			
		}
		
		
		
		
		//2x) Check which local mail setting to use	
		/*
		if(isset($params['_L_SETTING'])){
			//RETRIEVE /REPLACE from local
			foreach(array_keys($params['_L_SETTING'][0]) as $key){
				$mail_settings[$key] = $params['_L_SETTING'][0][$key];
			}
		} 
		*/
		//echo '<hr><h1>'; echo $params['mail'],'</h1>';  print_r($mail_settings);	
		//_E_TRACE($mail_settings,true);
		
	}
	
	//RETRIEVE
	//*************************************************************	
	foreach( $email_datas as $key ){
			
			if( isset($mail_settings[ $key ]) ){
				if($mail_settings[ $key ]!=''){
					//PULL FROM SETTINGS
					$arr[ $key ] = $mail_settings[ $key ];
				}
			} else {
				//PULL FROM fs inputs
				$arr[ $key ] = $params[ $key ];
				
			}		
	}
	//print_r($arr);
	return $arr;
}

public function email_update_template_unit( $params , $keyName){
	
	//echo $this->_FV['a.1a']['FirstName.#0'];
	$FV = $this->_FV;
	
	foreach(array_keys($FV) as $grp){
		foreach(array_keys($FV[$grp]) as $column ){
			$c_arr = explode('.', $column);
			//echo $c_arr[0];
			$key = $c_arr[0];
			$needle = '['.$key.']';
			
			$grp_fs_arr = explode('.',$grp);
			$grp_fs = $grp_fs_arr[0].'.'.$grp_fs_arr[1];
			
			//echo '<br>===========>',$grp_fs,'-',$c_arr[0],'-',$this->FS[$grp_fs][$c_arr[0]]['_type'];
			if($this->FS[$grp_fs][$c_arr[0]]['_type']!='select'){
				$value = $FV[$grp][$column];
			} else {
				//$value = $FV[$grp][$column];
				
				$keyID = $this->QS[ $this->FS[$grp_fs][$c_arr[0]]['_group_gen'] ][ '_group_gen_id' ]; //echo '===========>'.$keyID;
				$group_gen_displayname = $this->QS[ $this->FS[$grp_fs][$c_arr[0]]['_group_gen'] ][ '_group_gen_displayname' ];
				
				
				
				if(sizeof($this->MISC_DATA)>0){
					$MISC_DATA_group_gen = $this->MISC_DATA[$grp_fs][$c_arr[0]]['_group_gen']; //echo '===========>'; print_r($MISC_DATA_group_gen);
					foreach( array_keys($MISC_DATA_group_gen) as $i ){
						//echo $i;
						//echo trim($MISC_DATA_group_gen[$i][$keyID]),' == ',trim($FV[$grp][$column]),'<br>';
						if( trim($MISC_DATA_group_gen[$i][$keyID]) == trim($FV[$grp][$column]) ) {
							//echo trim($MISC_DATA_group_gen[$i][$keyID]),' == ',trim($FV[$grp][$column]),'<br>';
							$value = $MISC_DATA_group_gen[$i][$group_gen_displayname];//c_arr[0]]; 
							//echo $c_arr[0];
							//print_r($MISC_DATA_group_gen[$i]);
							//echo $MISC_DATA_group_gen[$i][$column];
						}
					}
				}
			}
			//DO replacement
			$params[ $keyName ] = str_replace( $needle , $value , $params[ $keyName ]);
			
			/*
			if($keyName=='To') {
				//print_r( $this->_FV );
				echo $params[ $keyName ][0];
				print_r( $params );
			}
			*/
			
			
		}
	}	
	//print_r( $params );
	return $params;
}

public function email_update_template( $params ){
	//array to execute string replace
	$replace_arr = array('Body','Subject','To');
	foreach($replace_arr as $keyName ){
		//echo $keyName;
		$params = $this->email_update_template_unit( $params , $keyName );		
	}
	return $params;
}

public function _email( $params='' ){ 
	//_E_TRACE($params, true);
	//_E_TRACE($this->OPS['FSID'], true);
	global $_DIR_MAPP;
	require_once($_SERVER['DOCUMENT_ROOT'].'/../_includes/plugins/phpmailer/class.phpmailer.php');
	require_once($_SERVER['DOCUMENT_ROOT'].'/../_includes/plugins/phpmailer/class.phpmailer_driver.php');
	
	
	$params['Body'] = $this->email_create_body($params); //Will combine with form body if stated
	
	$params = $this->email_update_template( $params );	//replace email templates with values	
	//echo '<h2>',$params['Subject'],'</h2>';
		
	$arr = $this->email_set_mailer_datas( $params ); //_E_TRACE($arr, true);
	
	//*************************************************************	
	//PHP MAILER ACTIONS
	//*************************************************************		
	if($arr!==false){
		//Instantiate new mail object
		$mailer_name = 'PHP_mailer';//.mt_rand(10,100); 
		//_E_TRACE($mailer_name, true);
		$$mailer_name = new PHPMailer(true);
		//Instantiate PHPmailer driver
		$ProccessMail = new PHPMailer_Driver($arr,$$mailer_name);
		$SentStatus = $ProccessMail->sendMail();
		//_E_TRACE($SentStatus, true);
		if($SentStatus=='false') $this->FORM_ERROR= true;
		
	} else {
		echo $RED_DIV,'ERROR: Mail data setup error.</div>';
	}		
	
}

//******************************
/* EXAMPLE:
	$table='client';
	$pkey = 'ClientID';
	$targetcol = 'Email';
*/
//******************************
public function reset_password($table,$pkey,$targetcol ,$targetValue){
	
	//Retrieve from FV
	
	//Check if Email exist?
	/*
	if email does not exist, do not send out email
	*/
	$returnPW = false;
	$strFilter = $targetcol.'=?';
	$params1 = array($targetValue); //_E_TRACE($params1,true);
	//_E_TRACE('table='.$table.' params='.$params1.' pkey='.$pkey.' strF='.$strFilter, true);
	$row= $this->Database->core_query_select($table, $params1, $pkey, $strFilter);
	
	$size = sizeof($row);//_E_TRACE('size='.$size,true);
	$error = $size==1 ? false : true ;
	
	if($error===false){
		//_E_TRACE('error is false',true);
		$Password = random_password();
		$PasswordMD5 = MD5( $Password );
		$uvalues = "Password='$PasswordMD5'";
		$input_id = $row[0][ $pkey ];
		$count =$this->Database->core_query_update($table,$uvalues,$pkey,$input_id);
		//echo $count;
		
		if($count==1){
			$returnPW = $Password;
		}
	} else {
		//_E_TRACE('error is true',true);
	}
	
	return $returnPW;

}

//******************************
//OTHER SYSTEM STANDARD METHODS
//******************************	
public function get_GST(){
	$GST='';
	$table = 'country';
	$strFilter = 'Country=?';
	$colnames = 'DefaultGST';
	$parameters = array( 'Singapore' );

	$row = $this->Database->core_query_select($table, $parameters, $colnames, $strFilter, "", "", "", "");	
	//print_r($row);
	$GST = $row[0]['DefaultGST'] / 100 ;	
	return $GST;
}
//start date cannot be greater than end date
public function check_date_sequence($d1,$d2){
	$error = false;
	
	$d1_o = new DateTime( $d1 ); 
	$_d1_Y = $d1_o->format( 'Y');
	$_d1_m = $d1_o->format( 'm');
	$_d1_t = $d1_o->format( 't');
	
	$d2_o = new DateTime( $d2 ); 
	$_d2_Y = $d2_o->format( 'Y');
	$_d2_m = $d2_o->format( 'm');
	$_d2_t = $d2_o->format( 't');
	
	//year1 > year2
	if($_d1_Y>$_d2_Y) $error = true;
	
	//year1==year2, m1>m2
	if($_d1_Y==$_d2_Y) {
		if($_d1_m>$_d2_m){
			$error = true;
		}
	}
	//year1==year2, mth1==mth2, d1>d2
	if($_d1_Y==$_d2_Y && $_d1_m==$_d2_m) {
		$error = true;
	}
	if($_d1_Y==$_d2_Y && $_d1_m==$_d2_m && $_d1_t==$_d2_t) $error = false;

	//if($_d1>$_d2) $error = true;
	
	return $error;
}
public function check_date_sequence_unit_test(){
	
	$arr[0][0] ='2016-06-15';
	$arr[0][1] ='2016-07-30';
	
	$arr[1][0] ='2016-07-10';
	$arr[1][1] ='2016-07-12';
	
	$arr[2][0] ='2018-07-10';
	$arr[2][1] ='2016-07-12';
	
	$arr[3][0] ='2016-07-10';
	$arr[3][1] ='2016-07-01';
	
	$arr[4][0] ='2016-06-10';
	$arr[4][1] ='2016-07-01';
	
	$arr[5][0] ='2016-07-01';
	$arr[5][1] ='2016-07-01';
	
	echo '<h3>check_date_sequence_unit_test</h3>';
	
	foreach(array_keys($arr) as $i){
		echo $arr[$i][0].' to '.$arr[$i][1];
		$error = $this->check_date_sequence($arr[$i][0],$arr[$i][1]);
		
		echo $op = $error===true ? ' d1 bigger' : ' d1 smaller/same..ok';
		echo '<br>';
	}
		
}
}
?>
