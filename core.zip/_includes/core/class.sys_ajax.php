<?php

class Sys_Ajax{

public $Database; //Database object
public $Formchecks;  //FormChecks object

//**************************************
//TESTING
public function test(){

	$json_arr = array(
		"name"=>$_POST['name'],
		"IUNum"=>$_POST['IUNum'],
		"VehicleTypeID"=>'15'
	);

	/* Send as JSON */
	header("Content-Type: application/json", true);
	echo json_encode( $json_arr );

}
//*********************************
//AJAX BOILER PLATE
//*********************************
public function AJAX_BOILER_PLATE(){
	_E_TRACE_AJAX('AJAX_BOILER_PLATE().sysajax');
	global $_DIR_MAPP;
	include($_SERVER['DOCUMENT_ROOT'].$_DIR_MAPP.'_includes/core/sys_ajax_ini.php');

	if( isset($_POST['Ops_Name']) ){

		if(method_exists($this, $_POST['Ops_Name'])){ 
				_E_TRACE_AJAX('$_POST[Ops_Name]='.$_POST['Ops_Name']);
				$this->$_POST['Ops_Name']();
			
			} else {
				_E_TRACE_AJAX('Invalid ajax method ');
				$json_arr = array(
					"Error"=>"Invalid ajax method ".$_POST['Ops_Name']."() found. Method probably not created or spelling error."
				);
				//Send as JSON 
				header("Content-Type: application/json", true);
				echo json_encode( $json_arr );		
			}
	} else {
		//Standard
		
		$this->default_form_ajax();
	}
		
}

//*********************************
//THIS IS THE DEFAULT AJAX FORM METHOD
//It covers pagination, search filters, forms inputs
//*********************************	
public function default_form_ajax(){
	_E_TRACE_AJAX('default_form_ajax().sysajax');
	_E_TRACE_AJAX('CURRID-->'.$_POST['CURRCID']);
	_E_TRACE_AJAX('UrlLink-->'.$_POST['UrlLink']);
	
	$FSID = isset($_POST['FSID']) ? $_POST['FSID'] : ''; //a.1a is the default for login page

	$Error = $FSID=='' ? 'FSID is undeclared' : '';
	//if(isset($_POST['AJAX_ERROR'])) $Error = $_POST['AJAX_ERROR']; originally used for _STRING_CHECK_STD
	
	_E_TRACE_AJAX('_FORM_LOGICS().default_form_ajax');
	$this->Layout->HTMLFORM->_FORM_LOGICS();
	if($this->Datalogic->FORM_ERROR) {
		//$Error = "There are missing form fields or error entries.";
	}
	
	ob_start();
		//print_r($_GET);
		//print_r($_POST);
		//$tmp['lol'] = 'duhzzz'; $tmp['yuck'] = 'ooooo';
		//$tmp = json_encode($tmp);
		//_echo($tmp);
		//print_r(json_decode($_POST['Post_Data'], true));
		//print_r(json_decode($_POST['Post_Add_Data'], true)); // must set to true for associative array
		//echo $this->Pagination_TOTAL_PG;
		//if($this->Datalogic->FORM_ERROR) echo 'sys_ajax:YES ERROR';
		//_echo('<h1>HELLOOO</h1>');
		//print_r($this->Datalogic->_FV);
		//_echo('<h1>HELLOOO END</h1>');
		_E_TRACE_AJAX('_FORM_RENDERFORM().default_form_ajax'); 
		$this->Layout->HTMLFORM->_FORM_RENDERFORM($FSID); //_echo('<h1>HELLOOO END</h1>');		
		//_print_r($_POST['AJAXID']);
		//echo $_SERVER['DOCUMENT_ROOT'].$Srclink;
		//$_SERVER['DOCUMENT_ROOT'].$_DIR_MAPP.'_includes/core/sys_ini.php';
		$Body=ob_get_contents();
	ob_end_clean();

	$json_arr = array(
		"Body"=>$Body,//.session_id().'acode-->'.constant("_ACODE"),
		"Error"=>$Error,
		"Pagination_TOTAL_PG"=>$this->Pagination_TOTAL_PG
	);
	/* Send as JSON */
	header("Content-Type: application/json", true);
	echo json_encode( $json_arr );	
}
}



?>