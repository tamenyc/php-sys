<?php

class HtmlComponents{

	public $Database;
	public $Datalogic;
	
	public $HTML_COMPOS; //parameters settings
	
	public $Pagination_MAX_DISPLAY; //Total # of display results
	public $Pagination_TOTAL; //Total # of results
	public $Pagination_TOTAL_PG; //Total # of pages
	public $Pagination_STARTKEY; //query limit start
	public $Pagination_CURRPAGE; //pagination current page

	

	//****************************************************

	//PAGINATION methods

	//****************************************************

	public function _PAGINATION( $FSID ){

		$Pagination_PAGE_BTN_MAX = $this->HTML_COMPOS[$FSID]['pagination']['Pagination_PAGE_BTN_MAX'] ;
		$Pagination_CURRPAGE = $this->Pagination_CURRPAGE;
		$Pagination_TOTAL_PG = $this->Pagination_TOTAL_PG;
		
		//echo '..',$this->Site->REQUEST_PARAMS_STRING;

		if( $Pagination_TOTAL_PG>1){
			
			$prev_page  = $Pagination_CURRPAGE-1;
			$next_page  = $Pagination_CURRPAGE+1;
			?>
			<div class="_PAGINATION row">
			<div class="col-md-12">
			<ul class='pagination pagination-md pull-right'>
			<li  class="_PAGINATION_BTN"><a href="<?php echo $this->Site->_FORM_URL_QUERY_STR('page=1');?>" data-pagin="1" >First</a></li>
			<?php if($Pagination_CURRPAGE-1>0){ ?><li  class="_PAGINATION_BTN"><a href="<?php echo $this->Site->_FORM_URL_QUERY_STR('page='.$prev_page);?>" class="_PAGINATION_BTN" data-pagin="<?php echo $prev_page;?>">Prev</a></li><?php }?>

			<?php 
			$divided = floor($Pagination_CURRPAGE / $Pagination_PAGE_BTN_MAX);

			//echo '<br>DIVIDED-->',$divided;

			

			if( fmod( $Pagination_CURRPAGE, $Pagination_PAGE_BTN_MAX) != 0) {

				$i_start = $divided*$Pagination_PAGE_BTN_MAX+1;				

			} else {

				$i_start = ($divided-1)*$Pagination_PAGE_BTN_MAX+1;

			}

			//echo '<br>I_START-->',$i_start;

			

			$i_end = $i_start + $Pagination_PAGE_BTN_MAX-1;

			//echo '<br>I_END-->',$i_end;

			

			//TO LIMIT NO# OF PAGINATION BUTTONS BASED ON Pagination_TOTAL_PG OBTAINED FROM QUERY

			if($i_end>$Pagination_TOTAL_PG) $i_end = $Pagination_TOTAL_PG;

			for($i=$i_start;$i<= $i_end; $i++){ 

				$class = '';
				if( $Pagination_CURRPAGE == $i ) $class ='class="active"';

			?>
			<li <?php echo $class; ?> ><a href="<?php echo $this->Site->_FORM_URL_QUERY_STR('page='.$i);?>" data-pagin="<?php echo $i;?>"><?php echo $i; ?></a></li>
			<?php } ?>
			<li class="_PAGINATION_BTN"><span class="input-group _GOTO"><input type="text" name="_GOTO" value="" class="_GOTO pull-right form-control" placeholder="Go to page"></span></li>
			<?php if($Pagination_CURRPAGE!=$Pagination_TOTAL_PG){ ?><li  class="_PAGINATION_BTN"><a href="<?php echo $this->Site->_FORM_URL_QUERY_STR('page='.$next_page);?>" class="_PAGINATION_BTN" data-pagin="<?php echo $next_page;?>">Next</a></li><?php }?>
			
			<li class="_PAGINATION_BTN"><a href="<?php echo $this->Site->_FORM_URL_QUERY_STR('page='.$Pagination_TOTAL_PG);?>" class="_PAGINATION_BTN" data-pagin="<?php echo $Pagination_TOTAL_PG;?>">Last</a></li>
			
			</ul>
			</div>
			<!--
			<div class="col-md-2 pagination">
			<div class="input-group">
			<input type="text" name="_GOTO" value="" class="_GOTO pull-right form-control" placeholder="Go to page">
			</div>
			</div>
			-->
			</div>

			<?php

		}



	}

	 



	public function _PAGINATION_set_display_result_num( $FSID ){
		//INITIALISE
		$temp_arr = explode('.',$FSID );
		$datagrp = $temp_arr[0];
		$QS_ID = $temp_arr[1];
		$strFilter = '';
		
		 // get the current page or set a default  
		 if (isset($_GET['page']) && is_numeric($_GET['page'])) {  
		   // cast var as int  
			$page = (int) $_GET['page'] - 1; 			
			if($page<0) $this->Site->ERROR_REDIRECT();			

		} else {
		   // default page num		   
		   if(!isset($_GET['page'])){
			  $page = 0;

		   } elseif(!is_numeric($_GET['page'])) {

			   $this->Site->ERROR_REDIRECT();
		   }
		   

		} // end if

		$this->Pagination_CURRPAGE = $page+1;		

		//CHECKS
		if($page<0) $page = 1 ;		

		//SET PAGINATION START KEY
		//_ETXT($page,'$page');
		$this->Pagination_STARTKEY = $page*$this->Pagination_MAX_DISPLAY;
		//_ETXT($this->Pagination_STARTKEY,'$Pagination_STARTKEY');
		$parameters = $this->HTML_COMPOS[$FSID]['pagination']['parameters'];
		$QS_DATA = $this->HTML_COMPOS[$FSID]['pagination']['qs_target']; 		
		$table = $this->Datalogic->QS[ $QS_DATA ]['_table']; 
		
		//PULLED FROM SEARCH FILTER
		//echo '<h1>'.$QS_ID .'--'.$datagrp,'</h1>';
		$strFilter =  $this->Datalogic->_SEARCH_FILTER( $strFilter,$QS_ID ,$datagrp );
		//echo '1) ',$strFilter,'<br>';

		//IF NO filter...assign original filter
		if( isset($this->Datalogic->QS[ $QS_DATA ]['_filter']) ) $strFilter = $this->Datalogic->QS[ $QS_DATA ]['_filter'].'  '.$strFilter;
		//echo '2)',$strFilter,'<br>';

		//SET TOTAL NUMBER OF RESULTS FROM QUERY
		$this->Pagination_TOTAL = $this->Database->core_count( $table , $strFilter, $parameters );
		//_echo( '<h1>Pagination_TOTAL-->'.$this->Pagination_TOTAL.'</h1>' );

		//SET TOTAL NUMBER OF PAGES
		$this->Pagination_TOTAL_PG = ceil( $this->Pagination_TOTAL / ( $this->Pagination_MAX_DISPLAY ) ) ;
		//echo $page; echo '<br>'.$this->Pagination_TOTAL_PG;
		//IF $_GET[page] , goes to page 1

		if( $page!=0 && ($page > $this->Pagination_TOTAL_PG-1 || $page < 0) ) {	

			$patterns[]= '/(page=[0-9]+)/';
			$replacements[] = 'page=1'; 
			$string = preg_replace($patterns, $replacements, $_SERVER['REQUEST_URI']);
			//_echo($string);
			$url = $this->Site->_HTTP.$_SERVER['HTTP_HOST'].$string;
			$url = str_replace('_ajax/','',$url);
			_E_TRACE_AJAX('_PAGINATION_set_display_result_num().htmlcomponents url='.$url);
			if( $this->Datalogic->Ajax === true ){
				//DO js redirect
				//echo $url;
				/*<script>//window.location.href = <?php echo $url; ?></script>*/
			} else {
				//DO NORMAL PHP REDIRECT
				header("Location:".$url."");
			}
			 
			//$this->Site->ERROR_REDIRECT();
		}

		//return $this->Pagination_TOTAL;

	}	

	

	public function _PAGINATION_INI( $HTML_COMPOS ){

	if(is_array($HTML_COMPOS)){
		foreach( array_keys($HTML_COMPOS) as $FSID ){ 
			
			if( isset($HTML_COMPOS[$FSID]['pagination']['max_display']) ){

				if($HTML_COMPOS[$FSID]['pagination']['max_display']!=''){

					

					//echo $temp_arr[0].$temp_arr[1];
					$this->HTML_COMPOS = $HTML_COMPOS;
					//print_r($this->HTML_COMPOS);
					
					$this->Pagination_MAX_DISPLAY = $this->HTML_COMPOS[$FSID]['pagination']['max_display'];
					$this->_PAGINATION_set_display_result_num( $FSID );
					$_STARTKEY = $this->Pagination_STARTKEY;
					$_LIMIT = $this->Pagination_MAX_DISPLAY;
					
					$this->Datalogic->QS[ $this->HTML_COMPOS[$FSID]['pagination']['qs_target'] ]['_llimit'] = $_STARTKEY;
					$this->Datalogic->QS[ $this->HTML_COMPOS[$FSID]['pagination']['qs_target'] ]['_ulimit'] = $_LIMIT;
					
				}

			}				
		}
	}
	

	}



	//****************************************************

	//ROW SORTING methods

	//key is the column key for sorting

	//****************************************************	

	public function _ROW_SORT( $key , $_alias , $FSID ){ 
		//REMOVE OTHER sort query from link to prevent unneeded sort query from building up
		$LinkSort =  false;
		//FSORT['SETTINGS']['SORT_TYPE'] = single --> means url will only contain one sort parameters, multiple --> url will contain multiple sort param
		if(isset($this->Datalogic->FSORT[$FSID]['SORT_TYPE'])){

			$single_sort = $this->Datalogic->FSORT[$FSID]['SORT_TYPE'] == 'single' ? true : false ;
			//_ETXT( $single_sort );
			//echo $this->Datalogic->FSORT['SETTINGS']['SORT_TYPE'];
			//FORM _url_key REF ARRAY

			$key_arr = array();

			foreach( array_keys($this->Datalogic->FSORT[ $FSID ]['FS'] ) as $i ){
				//echo $this->Datalogic->FSORT[ $FSID ]['FS'][$i]['_url_key'];
				$url_key_arr[ $this->Datalogic->FSORT[ $FSID ]['FS'][$i]['_url_key'] ] = true;
			}
			//print_r($url_key_arr);
		}
		//Retrieve SEARCH _key
		if(isset($this->Datalogic->SEARCH[ $FSID ]['FS'])){
			$SEARCH = $this->Datalogic->SEARCH[ $FSID ]['FS'];
			if(is_array($SEARCH)){
				foreach(array_keys($SEARCH) as $c){
					if(isset($SEARCH[$c]['_key'])){
						$SEARCH_KEY[] = $SEARCH[$c]['_key'];
					}
				}
			}	
		}
		//print_r($SEARCH_KEY);
		
		foreach( array_keys($this->Datalogic->FSORT[ $FSID ]['FS'] ) as $i ){ 
			
			if( $this->Datalogic->FSORT[ $FSID ]['FS'][$i]['_key']==$key ){
				
				$_url_key = $this->Datalogic->FSORT[ $FSID ]['FS'][$i]['_url_key'];		
				//print_r($url_key_arr);				

				//REMOVE OTHER SORT STRING QUERY FROM URL FOR SINGLE PARAM SORT
				if( $single_sort ){ 

					//RETRIEVE QUERY STRING
					$string =$this->Site->REQUEST_PARAMS_STRING_P;		
					$patterns[]= '/(page=[0-9])/';
					$replacements[] = 'page=1'; 
					$string = preg_replace($patterns, $replacements, $string);
					
					//REMOVE existing and SAME sort query:: comment off for the time being
					foreach( array_keys($url_key_arr) as $_f_key ){
						//echo $_f_key.'<br>';
						if(!empty($SEARCH_KEY)){
							if(!in_array($_f_key,$SEARCH_KEY)){
								$patterns[]= '/('.$_f_key.'=\w+|'.$_f_key.'=\w+&)/';
								$replacements[] = '';	
							}
						} else {
							$patterns[]= '/('.$_f_key.'=\w+|'.$_f_key.'=\w+&)/';
							$replacements[] = '';	
						}
						
						

					}
					//Remove existing $_url_key query
					$patterns[]='/('.$_url_key.'=\w+|'.$_url_key.'=\w+&)/';
					$replacements[] = '';
					//print_r($patterns);				

					$single_url_string = preg_replace($patterns, $replacements, $string);
					$single_url_string = trim($single_url_string)=='' ? $single_url_string : $single_url_string.'&';
					$single_url_string= urldecode( $single_url_string );				

					//remove '&&' and replace with '&'
					$single_url_string = str_replace('&&','&', $single_url_string);
					//change '?&' to '?'
					$single_url_string = str_replace('?&','?', $single_url_string);					
					//if($single_url_string=='?&') $single_url_string = '?';
				}

				$url_f =  substr($single_url_string.$_url_key, 0,1)=='?' ? $single_url_string.$_url_key : '?'.$single_url_string.$_url_key;  

				//SET THE LINK
				if( isset($_GET[$_url_key]) ){
	
					if( $_GET[$_url_key]=='a') {
						
						if( !$single_sort ){

							$alink = '<a href="'.$this->Site->_FORM_URL_QUERY_STR($_url_key.'=d').'">'.$_alias.'<i class="_DSC"></i></a>';

						} else {
							$alink = '<a href="'.$url_f.'=d'.'">'.$_alias.'<i class="_DSC"></i></a>';

						}
					

					} elseif( $_GET[$_url_key]=='d') {
						
						if( !$single_sort ){

							$alink = '<a href="'.$this->Site->_FORM_URL_QUERY_STR($_url_key.'=a').'" data-fsort="a" data-fsortkey="'.$_url_key.'" data-FSID="'.$FSID.'">'.$this->Datalogic->FSORT['SETTINGS']['FS'][$i]['_key'].'<i class="_ASC"></i></a>';

						} else {
							$alink = '<a href="'.$url_f.'=a'.'">'.$_alias.'<i class="_ASC"></i></a>';

						}						

					}						

				} else {						

					if( !$single_sort ){	

						$alink = '<a href="'.$this->Site->_FORM_URL_QUERY_STR($_url_key.'=a').'" data-fsort="a" data-fsortkey="'.$_url_key.'" xdata-FSID="'.$FSID.'">'.$_alias.'<i class="_NEUTRAL"></i></a>';

					} else { 
						//echo $single_url_string;
						$link2 = '?'.str_replace('?','',urldecode($single_url_string.$_url_key));
						$alink = '<a href="'.$link2.'=a'.'">'.$_alias.'<i class="_NEUTRAL"></i></a>';

					}

				}
				
				//LINK OUTPUT
				if($alink!=''){
					return $LinkSort =  '<span class="_FSORT">'.$alink.'</span>';
				} 
			}

		}
		
		return $LinkSort;
		
	}

}



?>