<?php
/**
hahaha
*/
class HTMLFORM{

	//MISC TEST SETTINGS
	public $TEST_DIV='<div class="_DIA">';
	public $RED_DIV='<div class="_DIA_red">';
	private $DIA_LINE='<br>****************************************************<br>';
	

	//Diagnostics settings
	public $get_inputinfos_fs_array_DIA=false;
	public $table_tdth_DIA=false;
	public $table_td_DIA=false;
	public $_INPUTtrace=false;
	public $_headerRedirect=true;
	
	//Form messages
	public $_SUCCESS_MESSAGE ='';
	public $_FORM_SUCCESS =false;

	
	
/*
****************************************************
HTMLFORM APEX METHODS
****************************************************
*/	
	
	//****************************************************
	//_FORM  LOGICS method
	//****************************************************

	public function _FORM_LOGICS(){	
		
		
		_E_TRACE( 'htmlform._FORM_LOGICS()' );
				
		
		/***************************************************************************/	
		//Check ajax update	
		$have_update = $this->Datalogic->_FOPS_have_update( $_POST['FSID'] );
		if( !empty($_POST[Post_Data][0]) && $have_update ) { //_ETXT( 'size='.count($_POST[Post_Data]).' Post_Data='.$_POST[Post_Data] ,'EmptyArray');
			//Has values
			//_print_r ( $Post_Data );
			if(!empty($Post_Data[0]) && !empty($Post_Data) ){ //_print_r( $Post_Data[0] );
				$Post_Data = json_decode($_POST[Post_Data], true);
				//Updates $_POST with Post_Data captured from Ajax form process
				$this->Datalogic->_update_Post_FN ( $Post_Data[0]['name'], $Post_Data[0]['name'] );
			}
			
		}
		
		//Check ajax add
		$have_insert = $this->Datalogic->_FOPS_have_insert( $_POST['FSID'] );
		if( !empty($_POST['Post_Add_Data']) && $have_insert){
			$Post_Add_Data = json_decode($_POST['Post_Add_Data'], true);
			//_print_r($Post_Add_Data); // must set to true for associative array
			foreach(array_keys($Post_Add_Data) as $i ){
				//_print_r($Post_Add_Data[$i]);
				$this->Datalogic->_update_Post_FN( $Post_Add_Data[$i]['name'],$Post_Add_Data[$i]['value'] );
			}
			
		}

		
		
		$this->HtmlComponents->_PAGINATION_INI( $this->HtmlComponents->HTML_COMPOS ); 
		//_echo ( __METHOD__ );	
		//if(isset($this->Datalogic->FOPS['_showdata'])) $this->Datalogic->QUERY_PARAMS=$vparam;
		
		/***************************************************************************/		
		//QUERY DB
		/***************************************************************************/	
		if(sizeof($this->Datalogic->QS)>0) $this->Datalogic->_FORM_QUERY_MAIN();
		//_print_r($this->Datalogic->_D);
			
		
		/***************************************************************************/	
		//SETTINGS INI
		/***************************************************************************/	
		$this->Datalogic->_FORM_DISPLAY=true;
		$this->Datalogic->_FORM_ERROR=false;
		
			//Determine cases to shut down form display
			$FOPS = $this->Datalogic->FOPS;
			$update_exist = false;
			$showdata_exist = false;
			$add_exist = false;
			//Scan over form page logics. Should work for multiple forms.
			if(!empty($FOPS)){
				foreach(array_keys($FOPS) as $_fsid){
					foreach(array_keys($FOPS[$_fsid]) as $i){
						if(isset($FOPS[$_fsid][$i]['_update'])){
							if($FOPS[$_fsid][$i]['_update']==true) $update_exist = true;
						}
						if(isset($FOPS[$_fsid][$i]['_showdata'])){
							if($FOPS[$_fsid][$i]['_showdata']==true) $showdata_exist = true;
						}
						if(isset($FOPS[$_fsid][$i]['_insert'])){
							if($FOPS[$_fsid][$i]['_insert']==true) $add_exist = true;
						}					
					}

				}				
			}

			//Pure "edit" case must have data else do not display form
			if( $update_exist===true && $showdata_exist===true && $add_exist===false ){
				//_echo('Pure "edit" case');				
				if(empty($this->Datalogic->_D)) {
					//_echo('No data');
					$this->Datalogic->_FORM_DISPLAY=false;
				} else {
					//_echo('have data');
				}
			} else {
				//echo 'ok';
			}

		
		/***************************************************************************/	
		//RETRIEVE AND MATCH DATA
		/***************************************************************************/	
			//_echo('<h1>Initial _D before matching with _POST</h1>'); _print_r($this->Datalogic->_D);
			//_print_r($this->Datalogic->FOPS);

			
		$this->Datalogic->_FORM_RETRIEVE_MAIN();
			//_echo('<h1>Initial _D!!!</h1>'); 
			//_print_r($this->Datalogic->_D);
			//_print_r($this->Datalogic->_FV);
			//_E_TRACE($this->Datalogic->FORM_ERROR,true);
			
		/***************************************************************************/	
		//CHECKS AND SUBSEQUENT PROCESSES
		/***************************************************************************/	
		//_E_TRACE('CHECKS AND SUBSEQUENT PROCESSES',true);
			if(isset($_POST['_SUBMIT']) || $this->Datalogic->Ajax===true ){ 
				

				
				
				//***************************************
				//PERFORMS FORM CHECK
				//***************************************
				//method will set $this->Datalogic->FORM_ERROR = true if there's error
				$this->Formchecks->_FORM_CHECKS(); //if($this->Datalogic->FORM_ERROR) echo 'YES ERROR';
				//$this->Datalogic->_print_post_fv();
				//***************************************
				//PERFORMS UPDATE / INSERT
				//***************************************
				$DO_INSERT_UPDATE = false;
				//CHECKS SETTINGS FOR update and insert ops
				foreach(array_keys($this->Datalogic->FOPS) as $FSID) {
					foreach(array_keys($this->Datalogic->FOPS[$FSID]) as $c) {
						if(isset($this->Datalogic->FOPS[ $FSID ][ $c ]['_update']) || isset($this->Datalogic->FOPS[ $FSID ][ $c ]['_insert'])) {
							$DO_INSERT_UPDATE = true;
							//_echo('ok');
							//_print_r($_POST);
						}
					}
				}
				//echo '<h1>ERROR-->'.$this->Datalogic->FORM_ERROR,'</h1>';
				//_print_r($this->Datalogic->FS_AJAX_PROCESS_FSID_FINAL);
				//_print_r($_POST['_FN']);
				
				//PERFORMS UPDATE / INSERT
				//***************************************
				/*
				if(isset($this->Datalogic->QS) && ( $this->Datalogic->FORM_ERROR===false || !empty($this->Datalogic->FS_AJAX_PROCESS_FSID_FINAL) ) && $DO_INSERT_UPDATE){	
					//echo 'DO_INSERT_UPDATE';
					$_SESSION['_INSERT_COUNTER']=0;
					$DONE_UPDATE_INSERT = false;
					if( isset($_POST['_FN']) ) {
						//Perform Insert or Update	
												
						$DONE_UPDATE_INSERT = $this->Datalogic->_FORM_UPDATE_INSERT_MAIN();	

					}					
				}*/
				
				
				
				//***************************************
				//PEFORMS FORM OPS
				//***************************************
				//Note: performing ops will follow the sequence set by FOPS except '_delete' and '_delete_u' which will be done first by default.
				//'_showdata' is more of a setting...
				if(!$this->Datalogic->FORM_ERROR){ 
					//DO..
					//if all above operations are success
					//$this->Datalogic->FORM_DISPLAY=false;
				
				
				//***************************************
				//PERFORMS DELETE
				//***************************************
				$DONE_DEL = false;
				foreach(array_keys($this->Datalogic->FOPS) as $FSID ) { 
					foreach(array_keys($this->Datalogic->FOPS[$FSID]) as $c) {
						if(isset($this->Datalogic->FOPS[ $FSID ][ $c ]['_delete'])) {
							//echo 'DELETE!!!!';
							//will really delete
							$this->Datalogic->_DELETE_U=false;
							if(isset($this->Datalogic->QS)) $DONE_DEL = $this->Datalogic->_FORM_DELETE_MAIN();
						} elseif (isset($this->Datalogic->FOPS[ $FSID ][ $c ]['_delete_u'])) {
							//sets status=QS[_valueEB][DEL.Status], does not really delete
							$this->Datalogic->_DELETE_U=true; 
							//_echo('Deleted');
							//_E_TRACE('Do delete_U',true);
							if(isset($this->Datalogic->QS)) $DONE_DEL = $this->Datalogic->_FORM_DELETE_MAIN();	
						
						}
					}
					
				}
				
					foreach(array_keys($this->Datalogic->FOPS) as $FSID) { 
						foreach(array_keys($this->Datalogic->FOPS[$FSID]) as $c) {
							foreach(array_keys($this->Datalogic->FOPS[$FSID][ $c ]) as $ops) { 
								if($ops!='_delete' && $ops!='_showdata' && $ops!='_insert' && $ops!='_update' && $ops!='_delete_u'){
									
								//echo '<h1>',$ops,'</h1>';print_r( $this->Datalogic->FOPS[$FSID][ $c ][ $ops ] ); echo '<hr>';
									unset($this->Datalogic->OPS);
									if(method_exists($this->Datalogic, $ops)){
										
										if(is_array( $this->Datalogic->FOPS[$FSID][ $c ][ $ops ] )){
											//_E_TRACE($ops,true);
											//_E_TRACE('ops='.$ops.' fsid='.$FSID.' 1',true);
											$this->Datalogic->OPS['FSID']=$FSID; //IMPORTANT!!! : This is to pass FSID into the ops function for operational purposes should FSID be needed.
											if($this->Datalogic->FORM_ERROR===false) $this->Datalogic->$ops( $this->Datalogic->FOPS[$FSID][ $c ][ $ops ][$FSID] );											
										} else { 
											//_E_TRACE($ops,true);
											$this->Datalogic->OPS['FSID']=$FSID;  //echo $ops;
											if($this->Datalogic->FORM_ERROR===false) $this->Datalogic->$ops();
											
										}
										
									} else {
										echo $ops,' does not exist.';
									}						
								} elseif ($ops=='_insert' || $ops=='_update'){ 
									//***************************************
									//PERFORMS UPDATE / INSERT
									//***************************************
									if(isset($this->Datalogic->QS) && ( $this->Datalogic->FORM_ERROR===false || !empty($this->Datalogic->FS_AJAX_PROCESS_FSID_FINAL) ) && $DO_INSERT_UPDATE){	
										//echo 'DO_INSERT_UPDATE';
										$_SESSION['_INSERT_COUNTER']=0;
										$DONE_UPDATE_INSERT = false; 
										if( isset($_POST['_FN']) ) {
											//Perform Insert or Update	
											//_E_TRACE($ops,true);		
											//_E_TRACE($this->Datalogic->_FV,true);
											$DONE_UPDATE_INSERT = $this->Datalogic->_FORM_UPDATE_INSERT_MAIN();	
											
											/*
											if(empty($_POST['_DELE'])){
												//_echo('reQ');
												unset($this->Datalogic->_D);
												if(sizeof($this->Datalogic->QS)>0) $this->Datalogic->_FORM_QUERY_MAIN();
												$this->Datalogic->_FORM_RETRIEVE_MAIN();
											}
											*/
						
										}					
									}									
								} 
							}
						}
					}
					
				}
			} 
		//note: for $DONE_UPDATE_INSERT===true, $this->Datalogic->FORM_ERROR===false
		/***************************************************************************/	
		//UPDATE QUERY AND FORM. ( IF THERE IS AJAX DELETE, UPDATE... )
		/***************************************************************************/	
		if($this->Datalogic->Ajax===true && ( $DONE_UPDATE_INSERT===true || $DONE_DEL===true ) ){
				//if($this->Datalogic->FORM_ERROR) echo 'YES ERROR';
				//_echo('<h1>DONE_UPDATE_INSERT='.$DONE_UPDATE_INSERT.'</h1>');
				//_echo('<h1>DONE_DEL='.$DONE_DEL.'</h1>');
				//_echo('<h1>REQUERIED _D!!!?</h1>');	
			
			
			//RESET QUERY_PARAMS TO ORIGINAL
			$this->Datalogic->QUERY_PARAMS = $this->Datalogic->QUERY_PARAMS_INITIAL;
			//REMOVES _D MOD BY PREVIOUS PROC
			unset($this->Datalogic->_D);			
			//REQUERY TO FORM FINAL _D
			if(sizeof($this->Datalogic->QS)>0) $this->Datalogic->_FORM_QUERY_MAIN(); //_print_r($this->Datalogic->_D);
			
			//Cleans up _FV
			if(isset($_POST['_FN'])){ //_print_r($_POST['_FN']);
				foreach(array_keys($_POST['_FN']) as $FNID ){ //echo $FNID;
					//This statement implies it is not in newly retrieved _D. After Ajax proc, the data on longer shows up. 
					//Hence, should be removed from _FV to prevent it from being populated back to the form field.
					if(isset($this->Datalogic->_D)){
						if(!in_array($FNID, $this->Datalogic->_D)){
							unset($this->Datalogic->_FV[$FNID]);
						}						
					} else {
						//echo $FNID;
						//_print_r($this->Datalogic->_D);
						unset($this->Datalogic->_FV[$FNID]);
					}

				}				
			}

			
				//_print_r($this->Datalogic->_D);	
			//REASSIGN FORM VALUES
			$this->Datalogic->_FORM_RETRIEVE_MAIN();
			
			//PAGINATIONS INI
			$this->HtmlComponents->_PAGINATION_INI( $this->HtmlComponents->HTML_COMPOS ); 
		}
		

		
		/***************************************************************************/	
		//CHECK IF THERE IS AJAX PASSED BACK _GET VIA _POST
		/***************************************************************************/	
		$_GET_P_ARR = isset($_POST['Ajaxed__GET']) ? json_decode ( urldecode( $_POST['Ajaxed__GET']), true ) : '';
		if(is_array($_GET_P_ARR)){
			$_GET_P  = http_build_query($_GET_P_ARR);
			//_ETXT( $_GET_P );
			
			$_GET_final = '?'.$_GET_P;
			$this->Site->REQUEST_PARAMS_STRING_P = '?'.$_GET_P;
		} else {
			$_GET_final = $this->Site->REQUEST_PARAMS_STRING_P;
		}
		/***************************************************************************/	
		//GET DESTINATION AND DO URL REDIRECTIONS
		/***************************************************************************/	
		if(isset($this->Datalogic->FFlow)){ 
			foreach(array_keys($this->Datalogic->FFlow) as $FSID) {
				//url redirection
				if(isset($this->Datalogic->FFlow[$FSID][ '_url' ])){
					
					if( !is_array($this->Datalogic->FFlow[$FSID][ '_url' ])) {						
						//'_url' = 'client/invoices/'
						
						if(strchr($this->Datalogic->FFlow[$FSID][ '_url' ], 'http')=='') {
							//cases like '_url' = 'client/invoices/'
							$url = $this->Site->_HTTP.$_SERVER['HTTP_HOST'].'/'.$this->Datalogic->FFlow[$FSID][ '_url' ].$_GET_final;
						} else {
							//cases like '_url' = 'http://www.domain.com'
							$url = $this->Datalogic->FFlow[$FSID][ '_url' ];
						}
						
					} else {
						//cases like 
						/*
							'_url'=>array(
								'client/invoices/'=>array(
									'v'=>'_retrieve_merchant_transaction_param', 
									) 			
							),
						*/
						//_E_TRACE('a',true);
						$_url_tmp = key($this->Datalogic->FFlow[$FSID][ '_url' ]);
						
						$url_query_params ='';
						$strSep ='';
						foreach(array_keys($this->Datalogic->FFlow[$FSID][ '_url' ][$_url_tmp]) as $i){
							if(method_exists($this->Datalogic,$this->Datalogic->FFlow[$FSID][ '_url' ][$_url_tmp][$i])){
							//_E_TRACE('b',true);
								$_url_ops = $this->Datalogic->FFlow[$FSID][ '_url' ][$_url_tmp][$i]; //_E_TRACE($_url_ops,true);
								$url_query_params = $url_query_params.$strSep.$i.'='.$this->Datalogic->$_url_ops();								
							}
							$strSep = '&';
						}
						if($url_query_params!='') $url_query_params = '?'.$url_query_params;
						
							
						if( strchr( $_url_tmp ,'http')=='' ){
							//_E_TRACE('c',true);
							$url = $this->Site->_HTTP.$_SERVER['HTTP_HOST'].'/'.$_url_tmp.$url_query_params;
						} else {
							$url = $_url_tmp.$url_query_params;
						}
					}
					
				} else{
					//_E_TRACE('d',true);
					$url = $this->Site->_HTTP.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'].$_GET_final;
				}
				
			}			
		}
		
		//echo $url;			
		if($_GET['Submit']==='True' ){ 
			
			if( $this->Datalogic->FORM_ERROR===false) {
				if($this->_headerRedirect===false) echo '<h1>NO ERROR</h1>';
				//echo $url;
				//echo $_SERVER['HTTP_HOST'];
				
				//DO FORM_SUCCESS_MSG SETTINGS
				$_SESSION['FORM_ERROR'] = false;
				$_SESSION ['FORM_SUCCESS_MSG'] = $this->Datalogic->FFlow[$FSID][ '_form_success_msg' ];
				$_SESSION['FORM_SUCCESS'] = true;

				//IF NO ERROR GO TO NEXT STAGE	
				//error_log('htmlform->header--->Location: '.$url, 0);		
				_E_TRACE( 'htmlform._FORM_LOGICS().submit=true and no form error.header . $url='.$url );
				//_echo( 'htmlform._FORM_LOGICS().submit=true and no form error.header . $url='.$url );		
				
				//Pass $_GET params fwd..//put this chunk into site?
				if(!empty($_GET)){
					foreach(array_keys($_GET) as $get_k){
						$sys_arr = array('Submit','_first','_second','_third','v');
						if(!in_array($get_k,$sys_arr)){
							$get_processed[$get_k] = $_GET[$get_k]; 
						}
					}					
				}
				if(count($get_processed)>0){
					$start = '&';
					$url_params = $start.http_build_query($get_processed);
				} else {
					$url_params ='';
				}
				
				$url_final = $url.$url_params;
				
				if($this->_headerRedirect) header("Location:".$url_final.""); 
				
				
			} elseif($this->Datalogic->FORM_ERROR){ 
				//_E_TRACE($this->Datalogic->FORM_ERROR,true);
				if($this->_headerRedirect===false)  echo '<h1>ERROR</h1>'; //_E_TRACE('form error', true);
				
				//DO FORM_SUCCESS_MSG SETTINGS
				$_SESSION['FORM_ERROR'] = true;
				unset( $_SESSION ['FORM_SUCCESS_MSG'] );
				unset( $_SESSION['FORM_SUCCESS'] );

				
				//$url = $this->Site->_HTTP.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
			}	

		} else {
			
			//DO FORM_SUCCESS_MSG SETTINGS..
			//if(isset( $_SESSION['FORM_SUCCESS_MSG'])){
			if(isset($_SESSION['FORM_SUCCESS'])){
				//script back to self with success message
				if(isset($_SESSION['FORM_ERROR'])){
					if($_SESSION['FORM_ERROR']===false){
						
						$this->_SUCCESS_MESSAGE = $_SESSION ['FORM_SUCCESS_MSG'];
						$this->_FORM_SUCCESS = true;
						unset( $_SESSION ['FORM_SUCCESS_MSG'] );
						unset( $_SESSION ['FORM_SUCCESS'] );

						
						if(isset($this->Datalogic->FFlow[$FSID][ '_form_success_display' ])){
							if($this->Datalogic->FFlow[$FSID][ '_form_success_display' ]===false) $this->Datalogic->_FORM_DISPLAY = false;
						}
					}
				}
			} else {
				//new entry w/o message
				$_SESSION['FORM_ERROR'] = false; 

				unset( $_SESSION ['FORM_SUCCESS_MSG'] );
				unset( $_SESSION['FORM_SUCCESS'] );
				_E_TRACE( 'htmlform._FORM_LOGICS().new entry w/o message' );
			}
		}
	}

	//****************************************************
	//_INPUT method
	//****************************************************
	public function _INPUT($grpinfos,$input_infos,$show_label=true,$input_info_fs='',$FV_GrpInfos='',$FV_NameTier , $misc='' , $inputs_direct=''){
		
		//_echo('<br>grpinfos='.$grpinfos.'<br>input_infos='.$input_infos.'<br>show_label'.$show_label.'<br>input_info_fs'.$input_info_fs.'<br>FV_GrpInfos='.$FV_GrpInfos.'<br>FV_NameTier='.$FV_NameTier.'<br>misc='.$misc.'<br>inputs_direct='.$inputs_direct);
		
		if($this->_INPUTtrace){
			echo __METHOD__,'<br>';	
			$classname=str_replace('::'.__FUNCTION__,'',__METHOD__);
			$reflectionMethod = new ReflectionMethod(new $classname(), __FUNCTION__);
			$reflectionMethodParams = $reflectionMethod->getParameters();
			$reflectionMethodParamsNum = $reflectionMethod->getNumberOfParameters();

			//echo "Number of arguments: $reflectionMethodParamsNum <br>";

			for ($i = 0; $i < $reflectionMethodParamsNum; $i++) {
				$reflectionMethodTargetAru = get_object_vars($reflectionMethodParams[$i]);
				//print_r($reflectionMethodTargetAru);
				$ArgumentName = $reflectionMethodTargetAru['name'];
				echo "[ $ArgumentName ] -->" . $$ArgumentName . "<br>"; 
				if(is_array($$ArgumentName)) print_r($$ArgumentName);
			}
		} //methodTrace
		

		/*
		Format references
		****************************************************
		
		[non db eg:]
		1i) Non nested
		<input name="_FN[a][Title.#0]" value="<?php echo $this->Datalogic->_FV['a']['Title.#0']; ?>" />
		FS[a][Title]
		
		1ii) Nested
		<input name="_FN[b][Item.#0#0#1]" value="<?php echo $this->Datalogic->_FV['b']['Item.#0#0#1'];?>" />
		FS[b][Item.2.2.2]
		
		[DB eg:]
		2i) Non nested
		<input name="_FN[a.0#1a.1][Title.#0]" value="<?php echo $this->Datalogic->_FV['a.0#1a.1']['Title.#0']; ?>" />
		FS[a.0#1a.1][Title]
		
		2ii) Nested
		<input name="_FN[b.6a.2][Item.#0#0#1]" value="<?php echo $this->Datalogic->_FV['b.6a.2']['Item.#0#0#1'];?>" />
		FS[b.6a.2][Item.2.2.2]
		
		3) Field with code eg h0
		_FN[b.6a.2][Item.#0#0#1.h0]
		FS[b.6a.2][Item.2.2.2]['_code']=h0
		
		
		!End reference notes.
		*/
		
		//PROCESSING DIRECT INPUTS INJECT
	if($inputs_direct!=''){
			unset($inputs);
			$direct_input = true; 
			//print_r($inputs);
			
			foreach(array_keys($inputs_direct) as $dkey){
				$inputs[ $dkey ] = $inputs_direct [ $dkey ]; 
			}
			
			$type = $inputs_direct['type'];
		} else {
			$direct_input = false; 
	}
		
		
	if( $direct_input===false ){
			
		
		//RETRIEVE PARAMS
		//****************************************************
		$IS_SPAMBLOCK = strstr($input_infos,'_SPAMBLOCK')? true : false ;
		
		
		if($input_info_fs=='' && $IS_SPAMBLOCK===false) $input_info_fs=$this->Datalogic->FS_input_info($grpinfos,$input_infos); //echo '<br>input_info_fs: ',$input_info_fs;//EG: This converts Address#0#0#0 to Address.2.2.2
		
		
		$grpinfos_fs=$this->Datalogic->FS_input_info($grpinfos,$input_infos,true);
		
		//FS
		$inputs['grpinfos']=$grpinfos;
		$inputs['input_info_fs']=$input_info_fs;

		$TierInfoArr = $this->Datalogic->get_tier_infos($FV_NameTier);
		$inputs['tier_level'] = $TierInfoArr['TierLevel'];
		$inputs['tier_name'] = $TierInfoArr['Name'];
		$inputs['tiers'] = $TierInfoArr['Tiers'];
		$inputs['tier_prev'] = $TierInfoArr['TierPrev'];
		$inputs['tier_generic'] = '_FN['.$inputs['grpinfos'].']['.$inputs['tier_name'].'.'.$inputs['tier_prev'];//.'_POS]';

		
		if($FV_GrpInfos!='' && $FV_NameTier!='' ) { 
			$inputs['name']='_FN['.$FV_GrpInfos.']['.$FV_NameTier.']'; //_echo ( '_FN['.$FV_GrpInfos.']['.$FV_NameTier.']' );
			
			//inputs[id] -> current data id from query results eg ClientID, InvoiceID..etc
			$id_tmp = str_replace($grpinfos.'.','',$FV_GrpInfos);
			if($id_tmp!=$grpinfos){
				$inputs['id'] = $id_tmp;
			} else {
				//In this case, this implies there's no result being queried . But this partiuclar data is still assoicated with this row of data.
				//Hence, get sibling data results data id from _FV and append
				$SiblingID = $this->Datalogic->_get_sibling_datas_queryID($grpinfos, $inputs['tiers']);
				if($SiblingID!=false) $inputs['Sibling_id'] = $SiblingID;
			}
			
		} else {
			$inputs['name']='_FN['.$grpinfos.']['.$input_infos.']'; 
		}
		
		//_echo( $inputs['name']);

		$inputs['form_attri_id'] = bin2hex($inputs['name']);

		
		//Retrieve from FS
		//****************************************************
		
		
		/*Generic Setups*/
		$FS_ATTRIBUTES = array(
			'inlined_w',
			'type',
			'errplaceholder',
			'cvalue',
			'dvalue',
			'group',
			'group_gen',
			'disabled',
			'text',
			'alias',
			'bs_form_grp',
			'show_label',
			'input-group-addon',
			'input-group-btn',
			'cell_w',
			'cell_class',
			'col_class',
			'col_w',
			'clear',
			'mod',
			'datepicker',
			'position',
			'embed_hidden_field',
			'embed_hidden_field_data',
			'class',
			'notes',
			
			//AngularJS
			'ng-model',
			'ng-options',
		);
			
		foreach($FS_ATTRIBUTES as $attri){
			if(!empty($this->Datalogic->FS[$grpinfos_fs][$input_info_fs]['_'.$attri])) {				
				$inputs[$attri]=$this->Datalogic->FS[$grpinfos_fs][$input_info_fs]['_'.$attri];

			} 
		}
		//_print_r($inputs);
		//Process fs_eval
		//****************************************************	
		foreach(array_keys($inputs) as $a){
			$a_exceptions = array('_checks','_inlined_w','_mod','_ops','_clean'); //!IMPT: These attributes have their own handlers
			if(is_array($inputs[$a]) && !in_array('_'.$a, $a_exceptions) ){
				//echo $a.'<br>';
				//perform methods to process fs_eval condition
				$inputs[$a] = $this->_eval_fs_setting_method($inputs,$grpinfos_fs,$input_info_fs ,'_'.$a);
			}			
		}
		$inputs['show_label'] = isset( $inputs['show_label'] ) ? $inputs['show_label'] : $show_label;
		//_print_r($inputs);
		
		
		/*'Compulsory' setups...*/
		$inputs['compulsory']= isset( $this->Datalogic->FS[$grpinfos_fs][$input_info_fs]['_checks']['compulsory'] ) || isset( $this->Datalogic->FS[$grpinfos_fs][$input_info_fs]['_checks'][0]['compulsory'] ) ? true : false ;
		
		
		
		if(isset($misc['row']))$inputs['row'] = $misc['row'];
		/*Class Settings ..*/
		//_ERROR SETTINGS
		$_tlevel = $inputs['tier_level'] -1; 
		//_print_r($this->Datalogic->_ERROR[ $inputs['grpinfos'] ][$input_info_fs.'.#'.$_tlevel]);
		//_print_r($this->Datalogic->_ERROR);
		//echo $FV_GrpInfos,'-',$FV_NameTier,'--',$input_info_fs,'-',$input_infos;

		//if(isset($this->Datalogic->_ERROR[$FV_GrpInfos][$FV_NameTier]) || isset($this->Datalogic->_ERROR[ $inputs['grpinfos'] ][$input_info_fs.'.#'.$_tlevel])){
		if(isset($this->Datalogic->_ERROR[$FV_GrpInfos][$FV_NameTier]) || isset($this->Datalogic->_ERROR[ $inputs['grpinfos'] ][$input_infos])){

			//$inputs['class']=$this->Datalogic->FS[$grpinfos_fs][$input_info_fs]['_class'].' _ERROR';
			$inputs['class']=$inputs['class'].' _ERROR';
			$hasError = '_ERROR';
			
			//For form fields outside 'normal' FS setups like terms and conditions in a table format.
			//if ( isset($this->Datalogic->_ERROR[ $inputs['grpinfos'] ][$input_info_fs.'.#'.$_tlevel]) ){
			if ( isset($this->Datalogic->_ERROR[ $inputs['grpinfos'] ][$input_infos]) ){
				//$inputs['errplaceholder'] = $this->Datalogic->_ERROR[ $inputs['grpinfos'] ][$input_info_fs.'.#'.$_tlevel];
				$inputs['errplaceholder'] = $this->Datalogic->_ERROR[ $inputs['grpinfos'] ][$input_infos];
				$inputs['title']= $this->Datalogic->_ERROR[$FV_GrpInfos][$input_infos];
			} elseif(isset($this->Datalogic->_ERROR[$FV_GrpInfos][$input_infos])) {
				$inputs['title']= $this->Datalogic->_ERROR[$FV_GrpInfos][$input_infos];
			} elseif($this->Datalogic->_ERROR[$FV_GrpInfos][$FV_NameTier]){
				echo $inputs['title']= $this->Datalogic->_ERROR[$FV_GrpInfos][$FV_NameTier];
			}
			
		} else{
			//$inputs['class']=$this->Datalogic->FS[$grpinfos_fs][$input_info_fs]['_class'];
			$hasError = '';
		}
		
		if($IS_SPAMBLOCK) {
			$inputs['name'] = $inputs['alias'];
			$inputs['alias'] = '_SPAMBLOCK';
			$inputs['class'] = 'Form_o';
		}
		
		$type=$this->Datalogic->FS[$grpinfos_fs][$input_info_fs]['_type']; //echo '<br>FS[',$grpinfos_fs,'][',$input_info_fs,']';
		$inputs['type']=$type;
		
		
		
		
		//Set placeholder placeholder
		//****************************************************		
		if(isset($this->Datalogic->FS[$grpinfos_fs][$input_info_fs]['_placeholder'])) $inputs['placeholder']=$this->Datalogic->FS[$grpinfos_fs][$input_info_fs]['_placeholder'];
		//echo $this->Datalogic->_ERROR[$FV_GrpInfos][$input_infos];
		
		//Set _ERROR message in placeholder or title
		//****************************************************	
		//if(isset($this->Datalogic->_ERROR[$FV_GrpInfos][$input_infos])) $inputs['placeholder']= $this->Datalogic->_ERROR[$FV_GrpInfos][$input_infos];
		//if(isset($this->Datalogic->_ERROR[$FV_GrpInfos][$input_infos])) $inputs['title']= $this->Datalogic->_ERROR[$FV_GrpInfos][$input_infos];
		
		//_FV
		
		if($FV_GrpInfos!='' && $FV_NameTier!='' ) {
			$inputs['value']=$this->Datalogic->_FV[$FV_GrpInfos][$FV_NameTier]; //echo '<h1>',$FV_GrpInfos,'~~',$inputs['value'],'</h1>';
		} else {
			$inputs['value']=$this->Datalogic->_FV[$grpinfos][$input_infos];
		}
		//_echo ($inputs['value']);
		//dvalue processing
		//_print_r($inputs);
		$inputs = $this->_dvalue_process($inputs,$grpinfos_fs,$input_info_fs);
		//_echo ($inputs['value']);

		
		if($IS_SPAMBLOCK) $inputs['value'] = '';
		//echo($this->Datalogic->_FV[$grpinfos][$input_infos]);
		//echo '_FV[',$grpinfos,'][',$input_infos,']';
		
	} //non direct input

	
			//****************************************************
			/*Bootstrap*/
			//****************************************************
			//RETRIEVE 
			$inputs['col_class'] = isset($inputs['col_class'])? ' '.$inputs['col_class'] : '';
			
			
			if(isset($inputs['bs_form_grp'])){
				$inputs['bs_form_grp'] = $inputs['bs_form_grp']=='form-group' ? $inputs['bs_form_grp'] : 'input-group';
			}
			if( isset($inputs['input-group-btn']) || isset($inputs['input-group-addon']) ){
				$inputs['bs_form_grp'] = 'input-group'; 
			}
			if( $inputs['form_grp_type'] == 'form_filter' ) {
				//Form Filter
				$html_start = isset($inputs['col_w'] ) ?  '<div class="'.FORM_BS_WIDTH($inputs['col_w']).$inputs['col_class'].'">' : '<div class="col-md-2">';
				$html_end = '</div>';
			} elseif( isset($inputs['col_w']) ) {
				//Normal FS Form
				$html_start = isset($inputs['col_w'] ) ?  '<div class="'.FORM_BS_WIDTH($inputs['col_w']).$inputs['col_class'].'">' : '<div class="col-md-12">';
				$html_end = '</div>';				
			} else {
				$html_start = '';
				$html_end = '';
			}
			//****************************************************
		
		//Set_display_data_label
		$display_data_label_css = $this->_set_display_data_label ($inputs);
		if( trim($display_data_label_css)!='' ) $inputs['class'] = $inputs['class'].' '.$display_data_label_css;
		
		
		//This is to append _AJAX_UD for JS to identify form fields able to do ajax update
		//check if _ajax is set in fs_layout at fs.php
		$ISSET_AJAX = $this->ISSET_AJAX($grpinfos_fs); //if($ISSET_AJAX) echo 'y';
		$HAVE_INSERT = $this->Datalogic->_FOPS_have_insert( $grpinfos_fs );
		$HAVE_UPDATE = $this->Datalogic->_FOPS_have_update( $grpinfos_fs );
		$IS_NESTED_DATA = $this->Datalogic->_IS_NESTED_DATA($grpinfos_fs);
		
		$fsidID_arr = explode('.',$FV_GrpInfos);
		//For ajax set, insert classses in..
		if($ISSET_AJAX){
			if(!empty($fsidID_arr[2])) {
				//Contains data primary key id .eg... a.1a.
				//echo $fsidID_arr[2];
				if( $HAVE_UPDATE ) $inputs['class'] = $inputs['class'].' _AJAX_U'; //Trigger for ajax update
			} else {
				//Does not contains data primary key id .eg... a.1a
				if( $HAVE_INSERT ) {
					if($IS_NESTED_DATA){
						$inputs['class'] = $inputs['class'].' _AJAX_A_N'; //Trigger for ajax add & nested case 
					} else {
						$inputs['class'] = $inputs['class'].' _AJAX_A'; //Trigger for ajax add & non nested case 
					}
					
				}
			}		
		}


		//Width for _CELL
		if(isset($inputs['cell_w'])) $Width = FORM_BS_WIDTH( $inputs['cell_w'] ); //echo $inputs['cell_w'];
		//CSS for _CELL
		if(isset($inputs['cell_class'])) $cell_class = $inputs['cell_class']; //echo $inputs['cell_w'];
		
		//Content Clear for each input.
		if(isset($inputs['clear'])) {
			$Clear = trim($inputs['clear'])!='' ? '<div class="'.$inputs['clear'].'"/></div>' : '';
			
		}
		//insert .form-group
		$form_group='';
		if(!empty($inputs['inlined_w'])){
			if(is_array($inputs['inlined_w'])){
				$form_group = ' form-group';
			}
		}

		$inputs['value'] = stripslashes( html_entity_decode($inputs['value']) );
		
		//_print_r($inputs);
		//INPUT OPERATIONS EXECUTION
		//****************************************************
		$func='input_'.$type; 
				
		//Do input
		if(method_exists($this, $func) && ($input_info_fs!='' || $inputs_direct!='')){
			echo $html_start; //additional bootstrap wrappers
			echo '<div class="_CELL ',$Width,$hasError,$form_group,' ',$cell_class,'">'; 
			echo '<div class="mobile-label">';
			$this->show_label($inputs);
			echo '</div>';
			$this->$func($inputs);	
			if( !empty($inputs['notes'])) echo '<span class="_NOTES">'.$inputs['notes'].'</span>';
			if($hasError=='_ERROR' && empty($inputs['position'])) echo '<span class="_ERRORMSG">'.$inputs['title'].'</span>';
			echo '</div>'; 
			echo $html_end; //additional bootstrap wrappers
			echo $Clear;
		} elseif($input_info_fs!='') {
			//Warning messages
			if(!isset($this->Datalogic->FS[$grpinfos_fs][$input_info_fs])) {
				$input_info_fsARR = explode('.',$input_info_fs);
				
				$grpinfos_fsARR = explode('.',$grpinfos_fs);
				$input_info_fsARR = explode('.',$input_info_fs);

				if( strstr( $this->Datalogic->QS[$grpinfos_fsARR[1]]['_colnames'],  $input_info_fsARR[0] )===false ){
					//echo $this->RED_DIV; echo 'Invalid input for class.htmlform._INPUT() ( Undefined FS[', $grpinfos_fs,'][',$input_info_fs,'] )<br>$this->Datalogic->FS[$grpinfos_fs][$input_info_fs] is NOT VALID<br>grpinfos_fs='.$grpinfos_fs.'<br>$input_infos='.$input_infos.'</div>';
				}

				
			} else {
				echo $this->RED_DIV; echo 'Undefined class.htmlform.input_"method"().</div>';
			}
		}
	}
	
	private function _eval_fs_setting_method($inputs,$grpinfos_fs,$input_info_fs,$fs_eval){ 
		//_echo ($fs_eval);
		$fs_eval_wo_underscore = str_replace($fs_eval[0],'',$fs_eval);
		if(is_array($inputs[$fs_eval_wo_underscore])){
			foreach( array_keys($inputs[$fs_eval_wo_underscore]) as $ops_func ){
				//_echo($func);
				if(method_exists($this->Datalogic,$ops_func)){ //_E_TRACE($FV_NameTier,true);
					//_echo($ops_func);

					$ops_params['inputs'] = $inputs;
					$ops_params['fsid'] = $grpinfos_fs;
					$ops_params['curr_tier'] = $inputs['tiers'];
					$ops_params['input_info_fs'] = $input_info_fs;
					$ops_params['params'] = isset($this->Datalogic->FS[$grpinfos_fs][$input_info_fs][$fs_eval][$ops_func]) ? $this->Datalogic->FS[$grpinfos_fs][$input_info_fs][$fs_eval][$ops_func] : '' ;
					//_print_r($this->Datalogic->FS[$grpinfos_fs][$input_info_fs][$fs_eval]);
					//_print_r($ops_params['params']);
					if(is_array($ops_params['params'])){ 
							//print_r($ops_params['params']);
							//REtrieve id
							$_ID = !empty($inputs['Sibling_id']) ? $inputs['Sibling_id'] : !empty($inputs['id']) ? $inputs['id'] : '' ;
							
							foreach($ops_params['params'] as $params){ //echo $params;
								$tiers_local = !empty($inputs['tiers']) ?  '.'.$inputs['tiers'] : '' ;  //print_r($inputs);
								//echo $grpinfos_fs.$params.$tiers_local;
								//echo $this->Datalogic->_FV[$grpinfos_fs][$params.$tiers_local];
								//echo $grpinfos_fs.'.'.$inputs['Sibling_id'];
								
								
								if(!empty($this->Datalogic->_FV[$grpinfos_fs][$params.$tiers_local])){ 
									$ops_params['datas'][$params] = $this->Datalogic->_FV[$grpinfos_fs][$params.$tiers_local];
									
								}
								
								if(!empty($this->Datalogic->_FV[$grpinfos_fs.'.'.$_ID][$params.$tiers_local])){ 
									$this->Datalogic->_FV[$grpinfos_fs.'.'.$_ID][$params.$tiers_local];
									$ops_params['datas'][$params] = $this->Datalogic->_FV[$grpinfos_fs.'.'.$_ID][$params.$tiers_local];
									
								}
							}							
					}
					$result = $this->Datalogic->$ops_func( $ops_params );
					
				} else {
					echo '<strong>Warning:</strong> Method call to invalid '.$ops_func;
				}
				
			}
		}
		
		return $result;
	}
	
	private function _dvalue_process($inputs,$grpinfos_fs,$input_info_fs, $case=''){ 
		//$grpinfos_fs is $FISD
		//$input_info_fs is $colname
		if(isset($inputs['dvalue'])) { //print_r($this->Datalogic->_FV[$grpinfos_fs][ $input_info_fs.'.'.$inputs['tiers'] ]); 
			if(!is_array( $inputs['dvalue'] )){
				//direct value
				$_post_value = $this->Datalogic->_FV[$grpinfos_fs][ $input_info_fs.'.'.$inputs['tiers'] ];
				$inputs['value'] = $_post_value!='' ? $_post_value: $inputs['dvalue']; 
			} else {
				
				//it contains ops
				$value_tmp ='';		
				//print_r($this->Datalogic->_FV[$grpinfos_fs.'.'.$inputs['Sibling_id'] ]);
				foreach(array_keys($inputs['dvalue']) as $ops_func ){ //_E_TRACE($this->Datalogic->FS[$grpinfos_fs][$input_info_fs]['_dvalue'][$ops_func],true);
					
					if(method_exists($this->Datalogic,$ops_func)){ //_E_TRACE($FV_NameTier,true);
						//echo $ops_func;
						//prepare ops_params
						//1) params used
						switch ($case){
							case 'embed_hidden_field_data':
								$ops_params['params'] = isset($this->Datalogic->FS[$grpinfos_fs][$input_info_fs]['_embed_hidden_field_data']['_dvalue'][$ops_func]) ? $this->Datalogic->FS[$grpinfos_fs][$input_info_fs]['_embed_hidden_field_data']['_dvalue'][$ops_func] : '' ;
								
							break;
								
							default:
								$ops_params['params'] = isset($this->Datalogic->FS[$grpinfos_fs][$input_info_fs]['_dvalue'][$ops_func]) ? $this->Datalogic->FS[$grpinfos_fs][$input_info_fs]['_dvalue'][$ops_func] : '' ;
							
						}
						
						$ops_params['fsid'] = $grpinfos_fs;
						$ops_params['curr_tier'] = $inputs['tiers'];
						$ops_params['input_info_fs'] = $input_info_fs;
						//print_r($inputs);
						//print_r($ops_params['params']);
						//print_r($this->Datalogic->_FV);
						if(is_array($ops_params['params'])){ 
							//print_r($ops_params['params']);
							//REtrieve id
							$_ID = !empty($inputs['Sibling_id']) ? $inputs['Sibling_id'] : !empty($inputs['id']) ? $inputs['id'] : '' ;
							
							foreach($ops_params['params'] as $params){ //echo $params;
								$tiers_local = !empty($inputs['tiers']) ?  '.'.$inputs['tiers'] : '' ;  //print_r($inputs);
								//echo $grpinfos_fs.$params.$tiers_local;
								//echo $this->Datalogic->_FV[$grpinfos_fs][$params.$tiers_local];
								//echo $grpinfos_fs.'.'.$inputs['Sibling_id'];
								
								
								if(!empty($this->Datalogic->_FV[$grpinfos_fs][$params.$tiers_local])){ 
									$ops_params['datas'][$params] = $this->Datalogic->_FV[$grpinfos_fs][$params.$tiers_local];
									
								}
								
								if(!empty($this->Datalogic->_FV[$grpinfos_fs.'.'.$_ID][$params.$tiers_local])){ 
									$this->Datalogic->_FV[$grpinfos_fs.'.'.$_ID][$params.$tiers_local];
									$ops_params['datas'][$params] = $this->Datalogic->_FV[$grpinfos_fs.'.'.$_ID][$params.$tiers_local];
									
								}
							}							
						}
						//print_r($ops_params['datas']);
						
						$value_tmp = $this->Datalogic->$ops_func( $ops_params );
					}
				}
				$inputs['value'] = $value_tmp;
				
			}
			
		}
		return $inputs;		
	}
	
	public function _RENDER_FILTERFORM( $FSID ){
		
		//check FS_LAYOUT for _display_filter settings
		$show_filter_form = true;
		if(isset($this->Datalogic->FS_LAYOUT[$FSID])){
			$FS_LAYOUT_FSID = $this->Datalogic->FS_LAYOUT[$FSID];
			if(isset($FS_LAYOUT_FSID['_display_filter'])){
				$show_filter_form = $FS_LAYOUT_FSID['_display_filter']===false? false : true;
			}
		}
		
		if(isset( $this->Datalogic->SEARCH[ $FSID ] ) && $show_filter_form===true){

				//echo '<hr>render filterform<hr>';

					if( isset( $this->Datalogic->SEARCH[ $FSID ]['FS']  ) ){ 
						//print_r($_GET);
						
						//CSS processing
						if(isset($this->Datalogic->SEARCH[ $FSID ]['CSS'])) $css = $this->Datalogic->SEARCH[ $FSID ]['CSS'];
						
						//link processing
						$link = $this->Site->_FORM_URL_QUERY_STR('Submit=True');
						echo '<form method="get" action="'.$link.'" class="_FORM_FILTER_MAIN '.$css.'" data-fsid="'.$FSID.'">';
						echo '<div class="row m-t-sm">';
						//GENERATES HTML INPUT FIELDS
						$this->filterform_input( $FSID ,'top_row');
						//FORM ACTION TOOLBAR
						$this->_FORM_ACTION_TOOLBAR( $FSID );
						echo '</div>';
						
						echo '<div class="row">';
						//GENERATES HTML INPUT FIELDS
						//Future plan is to build html collapsible field for extras search field.
						$this->filterform_input( $FSID ,'bot_row');
						echo '</div>';
						
						//echo '<div class="row pull-right"><div class="col-md-12"><input type="submit" value="Apply" name="_SUBMIT_FILTER" /></div></div>';
						echo '</form>';
						
					}
			}
			

	}
	
	public function _FORM_ACTION_TOOLBAR( $FSID ){ 
	$showToolbar = false;
	if(isset($this->FS_TOOLBAR)){
		$FS_TOOLBAR = $this->FS_TOOLBAR;
		if(is_array($FS_TOOLBAR)){
			foreach(array_keys( $FS_TOOLBAR )as $_fsid){
				if($_fsid==$FSID){
					if(!empty($FS_TOOLBAR[ $_fsid ][ '_add' ][ '_modal_call' ])) $modal_call = str_replace('.','_',$FS_TOOLBAR[ $_fsid ][ '_add' ][ '_modal_call' ] );
				}					
			}
			$showToolbar = true;
		}
	}
		if($showToolbar){
	?>
	<div class="col-md-6">
        <div class="pull-right _TOOLBAR">

			<a class="btn btn-md btn-white _AJAX_MODAL_ADD" type="button" href="/admin/client/add/"> <i class="fa fa-plus" data-toggle="tooltip" title="Add new entry"></i> </a>
			<!--<button class="btn btn-md btn-white _AJAX_MODAL_ADD" type="button" data-toggle="modal" data-target="#Modal_<?php echo $modal_call; ?>"> <i class="fa fa-plus" data-toggle="tooltip" title="Add new entry"></i> </button>
			<button class="btn btn-md btn-white" type="button" data-toggle="tooltip" title="Copy file"> <i class="fa fa-files-o"></i> </button>-->
            <!--<button class="btn btn-md btn-white" type="button" data-toggle="tooltip" title="Print selected data as pdf"> <i class="fa fa-file-pdf-o"></i> </button>-->
			<!--<button class="btn btn-md btn-white" type="button" data-toggle="tooltip" title="Export selected data as .xls"> <i class="fa fa-file-excel-o"></i> </button>-->
            <button class="btn btn-md btn-white _AJAX_DEL" type="button" data-toggle="tooltip" title="Delete selected data"> <i class="fa fa-trash-o"></i> </button>
			<!--<button class="btn btn-md btn-white" type="button"data-toggle="tooltip" title="More filter actions"> <i class="fa fa-ellipsis-v"></i> </button>-->
        </div>
        <!--<strong>Found 61 issues.</strong>-->
    </div>
	<?php
		}
	}
	
	public function filterform_input( $FSID , $Location){
						
		foreach(array_keys($this->Datalogic->SEARCH[ $FSID ]['FS']) as $i){
							
			//echo $this->Datalogic->SEARCH[ $FSID ]['FS'][ $i ][ '_url_key' ],'<br>';	
			//echo $this->Datalogic->SEARCH[ $FSID ]['FS'][ $i ][ '_type' ];
			$location_retrieved = isset( $this->Datalogic->SEARCH[ $FSID ]['FS'][ $i ][ '_location' ] )? $this->Datalogic->SEARCH[ $FSID ]['FS'][ $i ][ '_location' ] : 'top_row';
			
			if($location_retrieved==$Location) {
				
				$grpinfos ='';
				$input_infos = '';
				$input_info_fs = '';
				//$show_label = false;
				$FV_GrpInfos = '';
				$FV_NameTier = '';
				$misc = '';
				//$this->_INPUT($grpinfos,$input_infos,$show_label,$input_info_fs,$FV_GrpInfos,$FV_NameTier , $misc ,$inputs);
				unset($inputs);
				$inputs['fs_target'] = $FSID; //unique to search filters
				$inputs['colname'] = $this->Datalogic->SEARCH[ $FSID ]['FS'][ $i ]['_key']; //unique to search filters
				
				$inputs['col_w'] = $this->Datalogic->SEARCH[ $FSID ]['FS'][ $i ][ '_col_w' ];
				
				$inputs['input-group-btn'] = $this->Datalogic->SEARCH[ $FSID ]['FS'][ $i ][ '_input-group-btn' ];
				$inputs['input-group-addon'] = $this->Datalogic->SEARCH[ $FSID ]['FS'][ $i ][ '_input-group-addon' ];	
				
				$inputs['name'] = $this->Datalogic->SEARCH[ $FSID ]['FS'][ $i ][ '_url_key' ];
				$inputs['alias'] = $this->Datalogic->SEARCH[ $FSID ]['FS'][ $i ][ '_alias' ];
				$inputs['class']='_FORM_FILTERS '.$this->Datalogic->SEARCH[ $FSID ]['FS'][ $i ][ '_class' ];
				$inputs['value']=$_GET[ $this->Datalogic->SEARCH[ $FSID ]['FS'][ $i ][ '_url_key' ] ];
				$inputs['type'] = $this->Datalogic->SEARCH[ $FSID ]['FS'][ $i ][ '_type' ];
				//$inputs['show_label'] = true;
				$inputs['nfs'] = true; // indicates outside fs settings...
				$inputs['form_grp_type'] = 'form_filter';
				if( isset($this->Datalogic->SEARCH[ $FSID ]['FS'][ $i ][ '_placeholder' ]) ) $inputs['placeholder'] = $this->Datalogic->SEARCH[ $FSID ]['FS'][ $i ][ '_placeholder' ];
				if( isset($this->Datalogic->SEARCH[ $FSID ]['FS'][ $i ][ '_group_gen' ]) ) $inputs['group_gen'] = $this->Datalogic->SEARCH[ $FSID ]['FS'][ $i ][ '_group_gen' ];
				if( isset($this->Datalogic->SEARCH[ $FSID ]['FS'][ $i ][ '_group' ]) ) $inputs['group'] = $this->Datalogic->SEARCH[ $FSID ]['FS'][ $i ][ '_group' ]; //print_r($inputs['group']);							
				
				
				
				//$this->input_text($inputs);
								
				$this->_INPUT($grpinfos,$input_infos,$show_label,$input_info_fs,$FV_GrpInfos,$FV_NameTier , $misc ,$inputs);				
			}
							
		} //foreach
	}
	public function _FORM_CONSTANT( $FSID ){
		//echo '<h1>_FORM_CONSTANT</h1>';
		echo '<input type="hidden" value="" name="_POST_DATA_HISTORY['.$FSID.']" data-fsid="'.$FSID.'">';
		echo '<input type="hidden" value="" name="_CHK_HISTORY['.$FSID.']" data-fsid="'.$FSID.'">';
	}
	public function _FORM_ACTION_URL ( $FSID ){
		$rt = '';
		$CURRURL = $this->Site->CURRURL; //_echo($CURRURL.'<Br>');
		//print_r($_SERVER['HTTP_HOST']);
		//print_r($_SERVER);
		//fs set next url
		$destination = !empty($this->Datalogic->FFlow[ $FSID ]['_url']) ? '/'.$this->Datalogic->FFlow[ $FSID ]['_url'] : '' ; //_echo($destination);
		
		if( $destination == $CURRURL ){
			//do nothing
			$rt = '';
		} else {
			$rt = $this->Site->_HTTP.$_SERVER['HTTP_HOST'].$destination;
		}
		return $rt;
	}
	public function _FORM_RENDERFORM( $FSID ){

		//Diagnostic messages
		if($this->Datalogic->FV_DIA) { echo '<hr>'; echo '<h2>Finalized _FV</h2>'; print_r($this->Datalogic->_FV); } 
		$this->Datalogic->_PRINT_DATALOGIC_DIA_MSG('_FORM_RENDERFORM().htmlform');
		
		//Print form related content1
		//Eg: this might be instructions etc..
		if( !empty($this->Datalogic->FS_LAYOUT[$FSID]['_fs_type']['_content1']) ) echo $this->Datalogic->FS_LAYOUT[$FSID]['_fs_type']['_content1'];
		
		//Form process success messages
		$this->DisplayNotice( $FSID );

		//RETRIEVE VALUES
		$FS_LAYOUT_ID = isset($this->FS_LAYOUT[$FSID]) ? $this->FS_LAYOUT[$FSID] : '';
		//print_r($FS_LAYOUT_ID['_submit_btn']['_value']);	
		$SubmitCSS = RETRIEVE_VALUE( $FS_LAYOUT_ID['_submit_btn']['_class'], '' );
		$SubmitShow =  !isset($FS_LAYOUT_ID['_submit_btn']['_show'])? true : $FS_LAYOUT_ID['_submit_btn']['_show'];
		$SubmitValue = RETRIEVE_VALUE( $FS_LAYOUT_ID['_submit_btn']['_value'], 'Submit' ); //_echo('SubmitValue-->'.$SubmitValue);
		$Action_URL = $this->_FORM_ACTION_URL( $FSID ); //_echo( $Action_URL ); KIV will come back to this..Basically this allows changing the url the form can be submitted to..
		
		$formCSS = RETRIEVE_VALUE( $FS_LAYOUT_ID['_class'], '' );
		
		$backbtnCSS = RETRIEVE_VALUE( $FS_LAYOUT_ID['_back_btn']['_class'], '' );
		$backbtnValue = RETRIEVE_VALUE( $FS_LAYOUT_ID['_back_btn']['_value'], 'Back' );
		$backbtnURL = RETRIEVE_VALUE( $FS_LAYOUT_ID['_back_btn']['_url'], '' );
		
		//print_r($this->Datalogic->FOPS[$FSID]);
		$_AJAX = $this->ISSET_AJAX( $FSID )===true ?   '_AJAX ' : '' ;
		$ISSET_AJAX = $this->ISSET_AJAX( $FSID ); //is _ajax set in FS_LAYOUT at fs.php
		$HAVE_INSERT = $this->Datalogic->_FOPS_have_insert($FSID);
		$HAVE_UPDATE = $this->Datalogic->_FOPS_have_update($FSID);
		$IS_NESTED_DATA = $this->Datalogic->_IS_NESTED_DATA($FSID);

		if(is_array($this->Datalogic->FFlow[$FSID])){
			$SHOW_FORM =  key($this->Datalogic->FFlow[$FSID])==''  ? false : true; 
		} else{
			$SHOW_FORM =  false;
		}
		
		if($HAVE_UPDATE) $_ops_have_update = 'update';
		$Data_Ops = 'data-ops="'.$_ops_have_update.'"';
		
		//FORM RENDER
		if($this->Datalogic->_FORM_DISPLAY) {
			//Check for pagination in form
			$got_pagination_css ='';
			if(isset($this->HtmlComponents->Pagination_MAX_DISPLAY)) {
				$got_pagination_css = '_PAGIN_MARKER';			
			}
			
			
			//Generate form name
			$FormID = $this->form_UniqueFormID( $FSID );			

			//SET TO FALSE TO PREVENT AJAX FROM GENERATING THIS DIV TO PREVENT MULTIPLE GENERATION.
			//THIS SHOULD ONLY BE SET DURING THE INITIAL PHP SCRIPT LOAD.
			if($this->Datalogic->Ajax===false){		
			
				if(!$this->Datalogic->FORM_ERROR) {
						//echo 'no error';
						if(!empty($this->Datalogic->FFlow[$FSID]['_action_url'])) {
							$action=$this->Datalogic->FFlow[$FSID]['_action_url']; //_print_r($this->Datalogic->FFlow[$FSID]);
						} else {
							$action = $this->Site->REQUEST_PARAMS_STRING_P."&Submit=True";
						}
				}								
				//echo $action;
				
				if( isset($this->Datalogic->FFlow[ '_submit' ]) ) {
					//form submitted					
					if($this->Datalogic->FFlow[ '_submit' ]===true) echo '<form method="post" data-FSID="'.$FSID.'" id="'.$FormID.'" action="',$action,'" >'; 
				} else {

					if(!isset( $_REQUEST["_first"])) $inject_first = '/'.$this->Site->_SET_DEFAULT.'/';
					
					if(!$this->Datalogic->FORM_ERROR) {
						//echo 'no error';
						if(!empty($this->Datalogic->FFlow[$FSID]['_action_url'])) {
							$action=$this->Datalogic->FFlow[$FSID]['_action_url']; //_print_r($this->Datalogic->FFlow[$FSID]);
						} else {
							$action = $inject_first.$this->Site->REQUEST_PARAMS_STRING_P."&Submit=True";
						}
				}	
					
					if( $SHOW_FORM ) echo '<form method="post" id="'.$FormID.'" '.$Data_Ops.' data-FSID="'.$FSID.'" action="',$action,'" class="',$formCSS,' ',$_AJAX,$got_pagination_css,'">'; 
				}
			}
			
			$AJAXID = $this->form_UniqueFormID( $FSID ,'AJAX_' );
			if( $this->Datalogic->Ajax===false ) {
				echo '<input type="hidden" name="FSID" value="'.$FSID.'">'; //NEDED FOR NORMAL FORM SUBMISSION TO WORK
				echo '<div id='.$AJAXID.'>';
			}
			//Display Content
			if($FSID!='') $this->DisplayStyledForm($FSID);
			//Display customized form content
			if( file_exists($this->DIR.'/form.php')) require_once($this->DIR.'/form.php');

			if( !empty($this->Datalogic->FS_LAYOUT[$FSID]['_fs_type']['_content2']) ) echo $this->Datalogic->FS_LAYOUT[$FSID]['_fs_type']['_content2'];
			
			//_post_data_filtered: Cache of all ajax data entries
			$_post_data_filtered = $this->Datalogic->Retrieve_Ajax_Post_Data(); //print_r($_post_data_filtered);
			if(!empty($_post_data_filtered)){
				foreach( array_keys($_post_data_filtered) as $k ){
					//echo '---------'.$k;
					//echo '<input type="hidden" name="Post_Data[]" value="'.$_post_data_filtered[$k].'" data-ajax-name="'.$k.'"/>';
				}
			}
			
			
			//Datalogic->Ajax===true implies current form is ran in ajax mode.
			if($this->Datalogic->Ajax===false){	
				//FORM HAD NOT RAN IN AJAX MODE. Do not generate the below to prevent re-appending of the following elements.
				/*******************************************************************************/		
				echo '</div>'; //<div id='.$AJAXID.'>
				if( $SHOW_FORM ) {
					echo '<div class="btn_areas clearfix clearboth space-25">';
					//Print non nested array ajax trigger
					if( $ISSET_AJAX && $HAVE_INSERT && $IS_NESTED_DATA===false) echo '<input type="button" class="_AJAX_ADD btn btn-primary" value="Add"/>';
					//Print nested array ajax trigger
					if( $ISSET_AJAX && $HAVE_INSERT && $IS_NESTED_DATA) echo '<input type="button" class="_AJAX_ADD_N btn btn-primary" value="Add"/>';
					if( $ISSET_AJAX===false && !empty($FS_LAYOUT_ID['_back_btn']) ) echo '<a href="'.$backbtnURL.'" class="btn '.$backbtnCSS.'"/>'.$backbtnValue.'</a>';
					if( $ISSET_AJAX===false && $SubmitShow===true) echo '<input type="submit" value="'.$SubmitValue.'" name="_SUBMIT" class="btn btn-primary '.$SubmitCSS.'"/>';
					if( $ISSET_AJAX===false ) $this->_FORM_RENDERFORM_custom_btns();			
					echo '</div>';					
				}

				
				if( $SHOW_FORM ) echo '</form>';
					
			} else {
				//ONLY GENERATE DURING AJAX MODE
				/*******************************************************************************/
				// PASS NEW $_GET FORMED BY AJAX BACK TO UPDATE FORM LOGICS SETTINGS. This helps to 'remember' page number and other form filter settings.			
					//_print_r(json_encode($_GET));
					$Ajaxed__GET = urlencode( json_encode($_GET) );
					echo '<input type="hidden" name="Ajaxed__GET" value="'.$Ajaxed__GET.'"/>';
			}

			
				
			
		}
	}
	//placeholder method
	public function _FORM_RENDERFORM_custom_btns(){
		
	}
	public function ISSET_AJAX( $FSID ){
		$bool= false;
		$FS_LAYOUT_ID = isset($this->FS_LAYOUT[$FSID]) ? $this->FS_LAYOUT[$FSID] : '';
		if(isset($FS_LAYOUT_ID['_ajax'])){
			if($FS_LAYOUT_ID['_ajax']===false){
				//echo 'no ajax';
				//$_AJAX = ''; 
				$bool = false;
			} else {
				//echo 'got ajax';
				//$_AJAX = '_AJAX '; 
				$bool = true;
			}			
		} else {
			//$_AJAX = '_AJAX ';
			$bool = true;
		}		
		
		return $bool;
	}
	
	private function FFLow_setting_eval ($array){
			
			if( is_array($array) ){
				foreach(array_keys($array) as $k){ 
					$func = trim(key($array[$k]));
					if(method_exists($this,$func)){
						
						if( !ARRAY_HAS_ARRAYKEY($array[$k][$func]) ){
							//No params in $func
							$this->$func();
						} else {
							//Retrieve $params
							foreach(array_keys($array[$k][$func]) as $key){
								$params[] = $array[$k][$func][$key];
							}
							//print_r($params);							
							$this->$func($params);
						}					
						
					}
				}
			}		
	}
	
	public function DisplayNotice( $FSID ){

		if( $this->Datalogic->FORM_ERROR ){
			$this->Print_Form_Error_Message($FSID);
			
		} else {
			
			if( $this->_FORM_SUCCESS == true ){
				$this->Print_Form_Success_Message($FSID);
				$this->Print_Form_Success_Content($FSID);
			}
								
			
					
		}

	}
	
	public function Print_Form_Error_Message($FSID){
			
		$errMsg = '<strong>There are form errors.</strong><br>'; 
			
		if(!empty($this->Datalogic->_ERROR['_CHKED']) ) {
			$msg = !empty($this->Datalogic->FS_LAYOUT[$FSID]['_fs_type']['_chked']['_checks']['_chk_CHKED_compulsory_at_least_one']) ? $this->Datalogic->FS_LAYOUT[$FSID]['_fs_type']['_chked']['_checks']['_chk_CHKED_compulsory_at_least_one'] : '';
			//if there is local message setting in FS_LAYOUT, else use method default message stored in _ERROR['_CHKED']
			$msg = $msg!='' ? $msg : $this->Datalogic->_ERROR['_CHKED'];
			//Set error
			$this->Datalogic->FS_LAYOUT[$FSID]['_fs_type']['_chked']['_error'] = true;
		} else {
			$this->Datalogic->FS_LAYOUT[$FSID]['_fs_type']['_chked']['_error'] = false;
		}
			
		//echo $errMsg.$msg;
		$this->NotificationBox( $FSID, $errMsg.$msg ,'alert-danger', ''); 	
		
	}
	public function Print_Form_Success_Message($FSID){
		if( isset($this->_SUCCESS_MESSAGE) ) {
			if($this->_SUCCESS_MESSAGE!=''){
				$this->NotificationBox( $FSID, $this->_SUCCESS_MESSAGE ,'alert-success', ''); 			
			}
		}
		
	}
	public function Print_Form_Success_Content($FSID){
		
		if(isset($this->Datalogic->FFlow[$FSID]['_form_success_content'])) {
			//print_r( $this->Datalogic->FFlow[$FSID]['_form_success_content']);
			$_form_success_content = $this->Datalogic->FFlow[$FSID]['_form_success_content'];
			if( is_array($_form_success_content) ){
				//Pull data from method stated in FFlow[$FSID]['_form_success_content']
				$this->FFLow_setting_eval ($_form_success_content);
				
			} elseif($_form_success_content!=''){
				//Directly print message from FFlow[$FSID]['_form_success_content']
				echo $this->Datalogic->FFlow[$FSID]['_form_success_content'];
				
			}
		}
		
	}
	public function NotificationBox($FSID, $Message, $Type='alert-info' ,$Link=''){
		echo '<div class="alert '.$Type.'">';
		echo $Message;
        if(trim($Link)!='') echo '<a href="'.$Link.'" class="alert-link">Link</a>';
        echo '</div>';
	}
	
	public function DisplayStyledForm($FSID){
		
		if($this->Datalogic->FORM_ERROR){
			//echo $this->RED_DIV,'Check form inputs again.</div>';
		}	
		$FS_LAYOUT = isset($this->FS_LAYOUT[ $FSID ]) ? $this->FS_LAYOUT[ $FSID ] : '';
		//RETRIEVE PARAMETERS
		if(isset($FS_LAYOUT['_fs_type'])){
			$DisplayFunc = isset($FS_LAYOUT['_fs_type']['_type']) ? $FS_LAYOUT['_fs_type']['_type'] : 'div';
			
			if( isset($FS_LAYOUT['_fs_type']['_table_code']) ) {
				$tableParams1[ $FS_LAYOUT['_fs_type']['_table_code'] ] = true;
			}
			
			if( isset($FS_LAYOUT['_fs_type']['_static_table']) ){
				$tableParams1['static_table'] = $FS_LAYOUT['_fs_type']['_static_table'];
			}
			
			$tableParams1['data_table'] =  str_replace('.','_', $FSID);
		}
		//print_r($tableParams1);
		//$tableParams1['static_table'] = false;
		//$tableParams1['dynamic_3A'] = true;
		//$tableParams1['data_table'] = 'a_1a';
		if(method_exists( $this, $DisplayFunc )){
			$this->$DisplayFunc($FSID,'#0',$tableParams1); //b.3a OR a.1a
		} else {
			echo( 'Warning: DisplayStyledForm('.$FSID.')._FORM_RENDERFORM($FISD).htmlform : undefined $FS_LAYOUT[_fs_type]' );
		}
		
	}
	
	//****************************************************
	//_DIV INPUT VIEW method
	//****************************************************
	public function div($datagrpinfos, $startTier ,$divParams){ //echo $datagrpinfos;


		//Perform checks
		$error=isset($this->Datalogic->FS[$datagrpinfos]) ? false : true ;
		if($error===false){
			$StaticData=isset($divParams['static_data']) ? $divParams['static_data'] : false ;
			//$inputinfos_fs_array=array('Title','Company'); //Eg. : Title, Name.2
			$inputinfos_fs_array=$this->get_inputinfos_fs_array($datagrpinfos);  //print_r($inputinfos_fs_array);
			//setup temp FV
			//print_r( $this->Datalogic->_FV);
			if(is_array($this->Datalogic->_FV)){
				foreach( array_keys($this->Datalogic->_FV) as $fvKey ){ 
					$arr_t=explode('.',$fvKey);
					if($arr_t[0].'.'.$arr_t[1]==$datagrpinfos){
						//echo '<h1>',$fvKey,'</h1>';
						$tempFV[][ $fvKey ] = $this->Datalogic->_FV[ $fvKey ];
						//echo '<h1>tempfv---></h1>'; print_r($tempFV);
					}
				}				
			}
		
		
		
			
		if(isset($divParams['data_table']) ){
			if( $this->ISSET_AJAX( $datagrpinfos ) ){
				$divID = trim($divParams['data_table'])!='' ? 'AJAX_'.$divParams['data_table'] : '';
			} else {
				$divID = $divParams['data_table'];
			}
			
		} else {
			echo( 'Warning: method div('.$FSID.').htmlform : undefined $FS_LAYOUT[_static_table] definition' );
		}

		
		$this->print_internal_div($tempFV,$inputinfos_fs_array,$startTier,$StaticData); 

		}
	}
	
	private function print_internal_div($tempFV, $inputinfos_fs_array, $startTier,$StaticData){
		//echo '<h1>tempfv---></h1>'; print_r($tempFV);
		
			
		if(is_array($tempFV)){
			foreach(array_keys($tempFV) as $rowNum){ //echo $rowNum;
				foreach(array_keys($tempFV[$rowNum]) as $fs_datagrp){ //echo $fs_datagrp;
					foreach(array_keys($tempFV[$rowNum][$fs_datagrp]) as $input){ 
						
						//echo $input;
						$inputArr=explode('.',$input);
						$FV_NameTier = $inputArr[0];
						$misc['row']=0;
						
						$this->_INPUT($fs_datagrp,$input,true, $FV_NameTier,$fs_datagrp,$input ,$misc);
						
						
					}
				}
			}	

		}

	}
	
	
	private function pagination_call( $datagrpinfos ){

		if(isset($this->HtmlComponents->Pagination_MAX_DISPLAY)) {
			//print_r($this->HtmlComponents->HTML_COMPOS);
			$this->HtmlComponents->_PAGINATION( $datagrpinfos ); //b.3a OR a.1a

		} 		

	}
	public function pagination_main( $datagrpinfos ,$position='bot', $show_results=false ){ 

		if(!empty($this->HtmlComponents->HTML_COMPOS[$datagrpinfos]['pagination']) && !empty($this->HtmlComponents->HTML_COMPOS[$datagrpinfos]) ){
			$HTML_COMPOS = $this->HtmlComponents->HTML_COMPOS[$datagrpinfos]['pagination'];			
		} else {
			$show_results = false;
		}
		$hide_results='';
		if(isset($this->HtmlComponents->HTML_COMPOS[$datagrpinfos]['pagination']['display_total_num'])){ 
			if($this->HtmlComponents->HTML_COMPOS[$datagrpinfos]['pagination']['display_total_num']===false) $hide_results = 'hide';
		}
		//Top
		if($position=='top') if( $HTML_COMPOS['position']=='both' || $HTML_COMPOS['position'] =='top' ) $this->pagination_call( $datagrpinfos );		
		//Bottom
		if($position=='bot') if( $HTML_COMPOS['position']=='both' || $HTML_COMPOS['position'] =='bot' ) $this->pagination_call( $datagrpinfos );
		
		//Show total results
		if($show_results){
			$TotalResults = $this->HtmlComponents->Pagination_TOTAL;
			echo '<div class="row nav nav-tabs">';
			echo '<span class="_PAGINATION_TOTAL pull-right small text-muted '.$hide_results.'" data-pagination-total-result="'.$TotalResults.'">'.$TotalResults.' result(s)</span>';
			echo '</div>';				
		}
	
	}
	
	public function row_sort_call ( $datagrpinfos, $key , $_alias ){ 
		if(isset($this->Datalogic->FSORT)){ 
			//echo $datagrpinfos;
			//if( $this->Datalogic->FSORT['SETTINGS']['FS_TARGET']['FSID']== $datagrpinfos ){
			//print_r($this->Datalogic->FSORT);
			if( !empty($this->Datalogic->FSORT[$datagrpinfos]['FS']) ){ //echo $datagrpinfos;
				return $this->HtmlComponents->_ROW_SORT( $key ,$_alias ,$datagrpinfos ); 
			}
		} else {
			return false;
		}
	}
	
	public function MinRowsToShow($params){
		$params['row_result'];
		$row_trigger = $params[0];
		$css = $params[1];
		
		$result =$params['row_result'] > $row_trigger ? $css : 'hdefault';
		
		return $result;
		
	}
	public function form_UniqueFormID( $FSID, $Header='' ){
		return $ID=$Header.str_replace('.','_',$FSID);
	}
	
	//****************************************************
	//_TABLE VIEW method
	//****************************************************
	public function table($datagrpinfos, $startTier ,$tableParams){ //echo $datagrpinfos;
		//_print_r($this->Datalogic->_FV);
		//echo $this->HtmlComponents->Pagination_TOTAL_PG;
		$_show_empty_row = true;
		if(!empty($this->Datalogic->FS_LAYOUT[$datagrpinfos]['_fs_type']['_show_empty_row'])){
			if($this->Datalogic->FS_LAYOUT[$datagrpinfos]['_fs_type']['_show_empty_row']){
				//echo '-->empty row';
				$_show_empty_row = false;
			}
		}
		//Perform checks
		$error=isset($this->Datalogic->FS[$datagrpinfos]) ? false : true ;
		
	
		if($error===false){

			//$inputinfos_fs_array=array('Title','Company'); //Eg. : Title, Name.2
			$inputinfos_fs_array=$this->get_inputinfos_fs_array($datagrpinfos); 
			//determines max. no. of cells for tier 1
			end($inputinfos_fs_array);
			$last_key=key($inputinfos_fs_array); 
			$cell_max=sizeof($inputinfos_fs_array[1]); 
			$row_max=$this->get_tr_row_num($inputinfos_fs_array[1],$datagrpinfos); //echo '<Br>ROW TO DISPLAY: ';print_r($inputinfos_fs_array[1]); //gets finalized number of rows to display
			
			//setup temp FV
			if($this->Datalogic->SHOW_TABLE_FV){
				_echo('<h1>table call _FV</h1>');
				_print_r($this->Datalogic->_FV);			
			}
				
			foreach( array_keys($this->Datalogic->_FV) as $fvKey ){ 
				$arr_t=explode('.',$fvKey);
				if($arr_t[0].'.'.$arr_t[1]==$datagrpinfos){
					//echo '<h1>',$fvKey,'</h1>';
					$tempFV[][ $fvKey ] = $this->Datalogic->_FV[ $fvKey ];
					//echo '<h1>tempfv---></h1>'; print_r($tempFV);
				}
			}
			
			//if( $row_max!=0 && $_show_empty_row===true){
			if( $row_max!=0 ){
				
				if($tableParams['dynamic_2'] === true ){ ?><style>table ._ADD_TR{ display:none;} table tr:last-child td:last-child ._ADD_TR:last-child{ display:inline;}</style><?php } 
				
				$dynamics_css='';
				if(!empty($tableParams['dynamic_2'])) $dynamics_css = 'dynamic_2';
				if(!empty($tableParams['dynamic_3'])) $dynamics_css = 'dynamic_3';
				if(!empty($tableParams['dynamic_3A'])) $dynamics_css = 'dynamic_3A';
				if(!empty($tableParams['dynamic_4'])) $dynamics_css = 'dynamic_4';
				if(!empty($tableParams['dynamic_5'])) $dynamics_css = 'dynamic_5';
				
				
					//PAGINATIONS
					$this->pagination_main ($datagrpinfos,'', true);
					//SET SCROLL HEIGHT 
					
					
					if(isset($this->FS_LAYOUT[ $datagrpinfos ]['_height'])){
						if(is_array($this->FS_LAYOUT[ $datagrpinfos ]['_height'])){
							$func = trim(key($this->FS_LAYOUT[ $datagrpinfos ]['_height']));
							//echo $func;
							$params = $this->FS_LAYOUT[ $datagrpinfos ]['_height'][$func];
							$params['row_result'] = $row_max;
							if(method_exists($this,$func)){
								$ScrollHeight = $this->$func($params);
							}
						} else {
							$ScrollHeight = !empty($this->FS_LAYOUT[ $datagrpinfos ]['_height']) ? $this->FS_LAYOUT[ $datagrpinfos ]['_height'] : '';
						}
						
					}
					
					if($ScrollHeight!='') echo '<div class="'.$ScrollHeight.'">';
					//HEIGHT SCROLL
					if($ScrollHeight!='') echo '<div class="full_height_scroll">';
					//TABLE RESPONSIVE
					echo '<div class="table-responsive _BOX_CONTENT">';
					
					$table_css = !empty($this->FS_LAYOUT[ $datagrpinfos ]['_fs_type']['_class']) ? $this->FS_LAYOUT[ $datagrpinfos ]['_fs_type']['_class'] : 'table-striped table-hover';
					$table_css = trim($dynamics_css.' '.$table_css);
					
					
				?>	
				<table data-table='<?php echo $tableParams['data_table']; ?>' class="table <?php echo $table_css; ?>">
				<?php $this->table_tr($row_max,$cell_max ,$datagrpinfos,$inputinfos_fs_array,$startTier,$tempFV); ?>
				</table>
				<?php
					$this->table_positioned_fields($datagrpinfos, $startTier ,$inputinfos_fs_array , $tempFV, $tableParams , 'form_footer');
					//TABLE RESPONSIVE
					echo '</div>';
					//HEIGHT SCROLL
					if($ScrollHeight!='') echo '</div>';
					//SET SCROLL HEIGHT 
					if($ScrollHeight!='') echo '</div>';
					//PAGINATIONS
					$this->pagination_main ($datagrpinfos,'bot', false);
					
			} else{
					echo '<div class="_NULL_RESULTS">There are no results.</div>';
			}// not zero result. $row_max!=0
		
		
		} //no error
	
		if($error) { 
			echo $this->RED_DIV;
			echo 'Undefined FS['.$datagrpinfos.'] at class.htmlfom.table() </div>';
		}
	

	}
	private function table_positioned_fields($FSID, $startTier ,$inputinfos_fs_array, $tempFV , $tableParams ,$_location=''){
		//print_r($FSID);
		//print_r($startTier);
		$startTierP = $startTier!='' ? '.'.$startTier : '';
		//print_r($tableParams);
		
		$FS = !empty($this->Datalogic->FS) ? $this->Datalogic->FS : '';
		foreach(array_keys($FS[$FSID]) as $k){
			$_position = !empty($FS[$FSID][$k]['_position'])? $FS[$FSID][$k]['_position'] : '' ; 
			if($_position==$_location){
				//echo $k;
				$input_infos = $k.$startTierP;
				$this->_INPUT($FSID,$input_infos,false, $inputinfos_fs_ar[1][$k],$FV_dataINFOS,$FV_NameTier ,$misc);
			}
		}
	}
	public function _D_have_data($FSID){ 
		//_print_r($this->Datalogic->_D);
		//_echo( $FSID );
		$have_data = false;
		if(!empty($this->Datalogic->_D)){
			$_d = $this->Datalogic->_D;
			
			$needle = $FSID;
			if(is_array($_d)){
				foreach(array_keys($_d) as $i_haystack){
					//_echo( $i_haystack);
					if( strpos($i_haystack,$needle)!==false ){
						$have_data = true;
						//echo 'have data';
						break;
					}
				}				
			}

		}		
		return $have_data;
	}
	public function _show_data_row ($FSID){
		$show_row = true;
		//Check if _D of $FSID exist.
		$have_data = $this->_D_have_data($FSID);
		
		//Check if dynamic_1, dynamic_2 => the only cases with add feature. 
		//The above 2 cases will show empty data row when _D have no data.
		$exclude_arr = array('dynamic_1','dynamic_2','dynamic_4');
			//_print_r($this->Datalogic->FS_LAYOUT[$FSID]['_fs_type']['_static_table']);
			//_print_r($this->Datalogic->FS_LAYOUT[$FSID]['_fs_type']['_table_code']);
		$_table_code = !empty($this->Datalogic->FS_LAYOUT[$FSID]['_fs_type']['_table_code']) ? $this->Datalogic->FS_LAYOUT[$FSID]['_fs_type']['_table_code'] : '';
		
		
		
		if( !in_array($_table_code, $exclude_arr) && $have_data===false){
			$show_row = false; 
		} 
		
		
		return $show_row;
	}
	//print <TR>
	private function table_tr($row_max,$cell_max, $datagrpinfos,$inputinfos_fs_array,$startTier,$tempFV){
		
		//print_r($this->Datalogic->FS_LAYOUT[$datagrpinfos]['_fs_type']['_table_code']);
		//RETRIEVE data
		$_table_code = !empty($this->Datalogic->FS_LAYOUT[$datagrpinfos]['_fs_type']['_table_code']) ? $this->Datalogic->FS_LAYOUT[$datagrpinfos]['_fs_type']['_table_code'] : '';
		$_rights = !empty($this->Datalogic->FS_LAYOUT[$datagrpinfos]['_fs_type']['_rights']) ? true : false;
		
		//prints TH
		echo '<thead>';
		echo '<tr>';
		$this->table_td_th($cell_max,'th',$datagrpinfos,$inputinfos_fs_array[1]);
		if($_rights) echo '<th>&nbsp;</th>';
		if($_table_code!='') {
			//Check for FS_LAYOUT [fsid][_fs_type][_chekd][_alias]
			$_alias = !empty($this->Datalogic->FS_LAYOUT[$datagrpinfos]['_fs_type']['_chked']['_alias']) ? $this->Datalogic->FS_LAYOUT[$datagrpinfos]['_fs_type']['_chked']['_alias'] : '&nbsp;';
			//retrieve from FS_LAYOUT
			$FS_LAYOUTCSS = isset($this->Datalogic->FS_LAYOUT[$datagrpinfos]['_fs_type']['_chked']['_td_w']) ? $this->Datalogic->FS_LAYOUT[$datagrpinfos]['_fs_type']['_chked']['_td_w'] : '';
			$TotalCSS = " class='".$FS_LAYOUTCSS."'";
			if($TotalCSS!='') $FinalCSS = " class='".$FS_LAYOUTCSS."'";
			
			echo '<th'.$TotalCSS.'>'.$_alias.'</th>';
		}
		echo '</tr>';
		echo '</thead>';
        echo '<tbody>';
		
		$show_row = $this->_show_data_row($datagrpinfos);
		//echo $datagrpinfos;
		
		
		//_echo('<h1>row_max= '.$row_max.'</h1>');
		if($show_row){
			//prints TR
			for($r=0;$r<$row_max;$r++){ 
				//echo $datagrpinfos; 
				//print_r($inputinfos_fs_array);
				//_print_r($tempFV);
				if(isset($tempFV[$r])){
					foreach(array_keys($tempFV[$r]) as $del_k1){
						$arr_del = explode('.',$del_k1);
						$dele_key = $arr_del[1].'.'.$arr_del[2];
					}
				}
				
				
				//Set row counter
				$tr_row_counter = $StaticTable===false ? 'data-counter="'.$r.'"' : '' ;
				
			?>
			<tr <?php echo $tr_row_counter; ?>>
				<?php 
					//data td
					$this->table_td_th($cell_max,'td',$datagrpinfos,$inputinfos_fs_array,$r,$startTier,$tempFV); 
					
					//General data actions td
					//Eg: view, edit..etc..
					if($_rights){
						$this->table_td_th(1,'td_rights',$datagrpinfos,$inputinfos_fs_array,$r,$startTier,$tempFV);
					}
					
					//dynamic action td
					if($_table_code == 'dynamic_1'){
						 //every <td> has round button"delete", "add"
						$this->table_td_th(1,'td_delete',$datagrpinfos,$inputinfos_fs_array,$r,$startTier,$tempFV);
						 
					} elseif($_table_code == 'dynamic_2'){
						//every <td> has round button "delete", only last row has "add" 
						$this->table_td_th(1,'td_delete',$datagrpinfos,$inputinfos_fs_array,$r,$startTier,$tempFV); 
					
					} elseif($_table_code =='dynamic_3' ){
						//every <td> has round button "delete"
						$this->table_td_th(1,'td_delete_only',$datagrpinfos,$inputinfos_fs_array,$r,$startTier,$tempFV); 
					
					} elseif($_table_code == 'dynamic_3A' ){
						//every <td> has "delete" checkbox.
						$this->table_td_th(1,'td_checkbox',$datagrpinfos,$inputinfos_fs_array,$r,$startTier,$tempFV); 				
					
					} elseif($_table_code == 'dynamic_4' ){
						//every <td> has round button "add", "delete" that detach row immediately upon clicking.
						$this->table_td_th(1,'tr_delete_detach',$datagrpinfos,$inputinfos_fs_array,$r,$startTier,$tempFV); 
						
					} elseif($_table_code == 'dynamic_5' ){
						//every <td> has round button "delete" that detach row immediately upon clicking with warning dialog box.
						$this->table_td_th(1,'tr_delete_detach_warn',$datagrpinfos,$inputinfos_fs_array,$r,$startTier,$tempFV); 
						
					} else {
						//echo '<td></td>';
					}
					
				?>
			</tr>
			<?php	
			}
		} else {
			//echo $cell_max;
			$colspan=$cell_max+1;
			$empty_data_text = !empty($this->Datalogic->FS_LAYOUT[$datagrpinfos]['_fs_type']['_empty_data_text']) ? $this->Datalogic->FS_LAYOUT[$datagrpinfos]['_fs_type']['_empty_data_text'] : 'There are no data avaliable.';
			echo '<tr><td colspan="'.$colspan.'"><span class="empty_data_text">'.$empty_data_text.'</span></td></tr>';
		}// show_row
		echo '</tbody>';
	}
	//print <TD> or <TH>
	private function table_td_th($cell_max,$cellType,$datagrpinfos,$inputinfos_fs_ar,$row='',$startTier='',$tempFV=''){
		
		
		//$cell array is derived from $inputinfos_fs_arr
		if($this->table_tdth_DIA){
			echo $this->DIA_LINE;
			echo '<h3>',$cellType,'</h3>';
			echo '<br>row: ',$row;
			echo '<br>cell max: ',$cell_max;
			echo '<br>$inputinfos_fs_ar: <br>';
			print_r($inputinfos_fs_ar);
		}

		//TH GENERATION
		if($cellType=='th'){ 
			for($c=0;$c<$cell_max;$c++){
				current($inputinfos_fs_ar);
				$key=key($inputinfos_fs_ar);
				
				
				//Retrieve th width
				//print_r( $this->Datalogic->FS[$datagrpinfos][$key]['_td_w']);
				$td_with = !empty($this->Datalogic->FS[$datagrpinfos][$key]['_td_w']) ? $this->Datalogic->FS[$datagrpinfos][$key]['_td_w'] : '' ;
				//Retrieve th class
				$td_class = !empty($this->Datalogic->FS[$datagrpinfos][$key]['_td_class']) ? $this->Datalogic->FS[$datagrpinfos][$key]['_td_class'] : '' ;
				$th_hidden = $this->Datalogic->FS[$datagrpinfos][$key]['_type']=='hidden' ? 'th_hidden_field' : '';
				
				//Tooltip
				$_tooltip = !empty($this->Datalogic->FS[$datagrpinfos][$key]['_tooltip']) ? $this->Datalogic->FS[$datagrpinfos][$key]['_tooltip'] : '' ;
				$_tooltip_pos = isset($_tooltip['_position']) ? $_tooltip['_position'] : 'top';
				$_tooltip_title = isset($_tooltip['_title']) ? $_tooltip['_title'] : '';
				$_tooltip_css = isset($_tooltip['_title']) ? 'tooltip-call' : '';

				//Finalized class
				$class = 'class="'.trim($td_with.' '.$td_class.' '.$th_hidden.' '.$_tooltip_css).'"';
				
				
				if($this->table_td_th_DIA) echo '<br>$key:',$key;
				echo '<th '.$class.'>';
				//echo $key,'-',$datagrpinfos;
				$_alias = $this->Datalogic->get_FS($datagrpinfos, $key, '_alias');
				
				
				//Retrieve sort html link
				$SortHMTL = $this->row_sort_call ( $datagrpinfos, $key ,$_alias );
				if(isset($_tooltip['_title'])) echo '<span data-toggle="tooltip" data-placement="'.$_tooltip_pos.'" title="'.$_tooltip_title.'">';
				if( $SortHMTL!==false ){ 
					echo $SortHMTL;
				} else {
					echo $_alias;
				}
				
				if(isset($_tooltip['_title']))  echo '</span>';
				echo '</th>';
				next($inputinfos_fs_ar);
			}
		}
		
		$td_types = array('td','td_delete','td_delete_only','td_checkbox','td_rights','tr_delete_detach','tr_delete_detach_warn');
		//TD GENERATION
		//if($cellType=='td' || $cellType=='td_delete' || $cellType=='td_delete_only' || $cellType=='td_checkbox' || $cellType=='tr_delete_detach' || $cellType=='tr_delete_detach_warn'){
		
		if(in_array($cellType,$td_types)){
			//_echo ('<h1>cellType='.$cellType.'</h1>'); _echo ('<h3>inputinfos_fs_ar</h3>'); print_r($inputinfos_fs_ar);
			for($c=0;$c<$cell_max;$c++){ 
				current($inputinfos_fs_ar[1]); //$inputinfos_fs_ar[1] represents data in tr td ,$inputinfos_fs_ar[0] represents data in tr th 
				$key=key($inputinfos_fs_ar[1]); //_echo ('<h3>key='.$key.'  cell_max='.$cell_max.'  c='.$c.'</h3>');
				$td_with = !empty($this->Datalogic->FS[$datagrpinfos][$key]['_td_w']) ? $this->Datalogic->FS[$datagrpinfos][$key]['_td_w'] : '' ;
				
				//echo $tableParams['dynamic_2'];
				if(isset($inputinfos_fs_ar[1][$key])) { //_echo ('key-'.$key.'<br>');

				
					//Need to retrieve index value from _FV
					//determine _fv_datagrpinfos
					//print_r($tempFV);
					
					//echo 'datagrpinfos=',$datagrpinfos,'--key=',$key,'--row=',$row;
					//_print_r($this->Datalogic->_FV);
					foreach(array_keys($this->Datalogic->_FV) as $b ){ //_echo($b);
						$b_arr=explode('.',$b);
						
						//DATA VERSION
						//print_r($this->Datalogic->_D);						
						//if(empty($this->Datalogic->_D) || count($this->Datalogic->_D)==0) echo 'empty';
						if(!empty($this->Datalogic->_D) || count($this->Datalogic->_D)>0) {
						//if(isset($this->Datalogic->QS)){
							//_echo ($b_arr[0].'.'.$b_arr[1]);
							if($b_arr[0].'.'.$b_arr[1]==$datagrpinfos){
							//_echo('<h3>'.$b.'</h3>'); _print_r($this->Datalogic->_FV[$b]); _echo('<hr>');
								if(is_array($this->Datalogic->_FV[$b])){
								//echo $b,'<br>';
									foreach( array_keys( $this->Datalogic->_FV[$b] ) as $b_key ){ //_echo($b.'-'.$b_key.'<br>');
										$b_key_form='';
										$b_key_form=$key.'.#'.$row;
										
										if($b_key_form==$b_key){ //_echo( $b_key.'--'.$b_key_form.'<br>' );
											$FV_dataINFOS=$b; //_echo('FV_dataINFOS='.$FV_dataINFOS);
											$FV_NameTier=$b_key;
										} 
									}
								}
							
							} 
						
						} else { 
							
							//NON DATA VERSION						
							if($b==$datagrpinfos){
								//_echo ('b->'.$b.'--datagrpinfos='.$datagrpinfos.'<br>');
								$b_key_form=$key.'.#'.$row;
								
								if(isset($this->Datalogic->_FV[$b][$b_key_form] )){
									$FV_dataINFOS = $b; 
									//_echo('<br>FV_dataINFOS='.$FV_dataINFOS);
									//_echo('b_key_form='.$b_key_form.'<br>');
									$FV_NameTier = $b_key_form; //_echo('---FV_NameTier='.$FV_NameTier.'<br>');
								} else {
									$FV_NameTier = $key.'.#'.$row;
								}
							}
							
						}
						
						
						
					}
					$misc['row']=$row;
					//echo '<h1>',$FV_dataINFOS,'-',$FV_NameTier,'</h1>';
					//_echo('FV_NameTier='.$FV_NameTier.'<br>');
										
					$CSS = $td_with;
					//PRINT CELL
					//_echo('FV_dataINFOS='.$FV_dataINFOS);
					$tmp_Del = explode('.',$FV_dataINFOS);
					//$FV_dataINFOS_Del = $tmp_Del[1].'.'.$tmp_Del[2];
					//_echo ('cellType='.$cellType.'<br>');
					$cellType = trim( $cellType );
					switch($cellType){
						case 'td':
							//Normal data <td>
							$show_input = false;
							//_echo('<br>key='.$key); 
							//_echo( '<br>FV_NameTier='.$FV_NameTier );
							//_echo ('<br>FV_dataINFOS='.$FV_dataINFOS);
							//_print_r($inputinfos_fs_ar[1][$key]);
							
							
							//extract colname from FV_dataINFOS to check against $key
							$FV_NameTier_Arr = explode('.',$FV_NameTier);
							if(isset($FV_NameTier_Arr[0])){ //_echo ($FV_NameTier_Arr[0]);
								if($FV_NameTier_Arr[0]==$key) {
									//_echo('<h4>show '.$key.'</h4>');
									$show_input = true;
								} else {
									$FV_NameTier = str_replace($FV_NameTier_Arr[0],$key,$FV_NameTier);
								}
							}
							$_type =  isset( $this->Datalogic->FS[$datagrpinfos][$key]['_type'] ) ? $this->Datalogic->FS[$datagrpinfos][$key]['_type'] : '' ;
							
							$hidden_field = $_type == 'hidden' ? 'hidden_field' : '';
							$CSS = $CSS.' '.$hidden_field;
							
							
							//echo ('<br>FV_NameTier New ='.$FV_NameTier);
							//_echo('<hr>');
							$print_css = $CSS=='' ? '' : " class=\"".trim($CSS)."\" ";
							echo "<td $print_css>"; 
							
							$this->_INPUT($datagrpinfos,$key.'.#'.$row,false, $inputinfos_fs_ar[1][$key],$FV_dataINFOS,$FV_NameTier ,$misc);
							echo '</td>';
						break;
						
						case 'td_rights':

							echo '<td class="'.$CSS_atn.'">';
							echo '<div class="btn-group text-r">';
							//_echo($key); _echo( '<br>'.$FV_NameTier );
							$FSID_ID = !empty($tmp_Del[2])? $tmp_Del[2] : '' ; 
							//print view/edit actions
							$this->input_edit_actions($FV_dataINFOS, $cellType, $FSID_ID , $Tier);
							echo '</div>';
							echo '</td>';
						break;
						
						default:
							//the dynamic actions
							echo '<td class="_DYN_ACTION '.$CSS_atn.'">';
							echo '<div class="btn-group text-r pull-right tooltip-call">';
							//echo $row;
							//_echo('#'.$row);
							$Tier= '#'.$row;
							$FSID_ID = !empty($tmp_Del[2])? $tmp_Del[2] : '' ; 
							//print checkbox, add, delete actions
							$this->input_dyn_actions($FV_dataINFOS, $cellType, $FSID_ID, $Tier);
							echo '</div>';						
						
						break;
					}
				
				} //if(isset($inputinfos_fs_ar[1][$key])) 
					
				//$this->_INPUT($datagrpinfos,$key.'.#'.$row,false, $inputinfos_fs_ar[1][$key],$FV_dataINFOS,$FV_NameTier);
				
				
				
				
						
				//diagnostics
				if($this->table_td_DIA) {
					echo $this->DIA_LINE;
					echo '<br>$row:',$row;
					echo '<br>$key:',$key;
					echo '<br>datagrpinfos:',$datagrpinfos;
					echo '<br>startTier: ',$startTier;
					echo '<br>tempFV array:<br>';print_r($tempFV);
					echo '<br>fv value: ',$fv_value;
					echo '<br>FS input info: ',$inputinfos_fs_ar[1][$key];
					
				}
				
				next($inputinfos_fs_ar[1]);
			}
		}
		
	}

	//get_inputinfos_fs_array
	private function get_inputinfos_fs_array($datagrpinfos){
		$inputinfos_fs_array='';
		$FS=$this->Datalogic->FS;
		//echo $datagrpinfos;
		$skip_array = array('form_footer');
		
		foreach(array_keys($FS[$datagrpinfos]) as $x){
			$skip_this = false;
			//Check for '_position'
			if(!empty($FS[$datagrpinfos][$x]['_position']) ){
				$_position = $FS[$datagrpinfos][$x]['_position'];
				$skip_this = in_array($_position,$skip_array)  ? true : false ;
			}
			
			if($skip_this===false){
				$arr=explode('.',$x);
				$arr_size=sizeof($arr);
				
				//get last arr key
				end($arr);
				$last_key=key($arr);
				
				//set to 1 for non nested
				$last_key=$last_key==0 ? 1 : $last_key;
				
				$inputinfos_fs_array[$last_key][ $arr[0] ]=$x;				
			}

			

			//Diagnostics
			if($this->get_inputinfos_fs_array_DIA){
				echo $this->DIA_LINE;
				echo '<br>',$arr_size;
				foreach(array_keys($arr) as $c){
					echo '<br>arr['.$c.']:',$arr[$c];
				}
				echo '<br>';
			}

			
		}
		//echo '<h1>inputinfos_fs_array</h1>'; print_r($inputinfos_fs_array);
		if($this->get_inputinfos_fs_array_DIA) print_r($inputinfos_fs_array);
		return $inputinfos_fs_array;
	}
	
	//determines the number of <tr> to display
	private function get_tr_row_num($inputinfos_fs_arr, $datagrpinfos ){
		//_echo('<h1>inputinfos_fs_arr</h1>');
		//_print_r($inputinfos_fs_arr);
		//echo $datagrpinfos;
		//_print_r($this->Datalogic->_FV);
		if(!empty($this->Datalogic->_D[$datagrpinfos])){
			//$Data = $this->Datalogic->_D[$datagrpinfos]; //print_r($this->Datalogic->_D);
		} else {
			$DataCount = 0;
		}
		$key=key($inputinfos_fs_arr); //GET THE FIRST KEY OF inputinfos_fs_arr FOR COUNTING TR.
		//echo '$inputinfos_fs_arr[ $key ]='.$inputinfos_fs_arr[ $key ];
		$arr=explode('.',$inputinfos_fs_arr[ $key ]);
		//echo '<h1>arr</h1>'; print_r($arr);
		$row_max=isset($arr[1]) ? $arr[1] : 1 ; //_echo('<h2>row_max='.$row_max.'</h2>');
		
		if(isset($_POST['_FN'])){
			if(isset($this->Datalogic->QS)){
				foreach(array_keys($_POST['_FN']) as $k){
					$arr_k=explode('.',$k);
					if(is_array($_POST['_FN'][$k])){
						foreach(array_keys($_POST['_FN'][$k]) as $k2){
							$k2_arr=explode('.',$k2);
							$kval=str_replace('#','',$k2_arr[1]);
							$chk[ $arr_k[0].'.'.$arr_k[1]][$k2_arr[0] ]=$kval;
						}
					}	
				}
			} else{
				//echo $datagrpinfos;
				$counter=0;
				foreach(array_keys($this->Datalogic->_FV[$datagrpinfos]) as $fv_key){ //echo $fv_key;
					$fv_key_arr = explode('.',$fv_key); 
					//echo $fv_key_arr[0];
					if($fv_key_arr[0]==$key){
						$counter++;
						//echo $fv_key;
					}
				}
			}
			
			//echo '<h1>',$counter,'</h1>';
		}
		
		//echo '<h1>chk arr</h1>';print_r($chk);
		
		//echo '<h1>',$datagrpinfos,'</h1>';
		$consolidated_value = '';
		$fv_counter=0; 
		$largest_num =1;
		//_echo('<hr><h1>_FV</h1>'); _print_r($this->Datalogic->_FV); _echo ('<hr>');
		foreach(array_keys($this->Datalogic->_FV) as $fv_key){ //_echo ('fv_key='.$fv_key.'<br>');
			$fv_key_arr = explode('.',$fv_key); 
			if($fv_key_arr[0].'.'.$fv_key_arr[1]==$datagrpinfos){ //_echo ($datagrpinfos.'<br>');
				//echo'<hr><h1>_FV</h1>'; print_r($this->Datalogic->_FV[$fv_key]); echo '<hr>';
				foreach(array_keys($this->Datalogic->_FV[$fv_key]) as $t){ 
					//_echo ('<h1>$t-->'.$t.'</h1>');
					$t_arr=explode('.',$t);
					//_print_r($t_arr);
					
					$tier = $t_arr[1]; //eg: #10#2#1 need to isolate out '#10'
					$tier_arr  = explode('#',$tier); //_print_r($tier_arr);
					
					$largest_num = $tier_arr[1]+1 > $largest_num ? $tier_arr[1]+1 : $largest_num ;
					
					/* OSELETED..NOT ACCURATE
					if( $t_arr[0]==$arr[0] ) {
						$fv_counter++; 
						//_echo ('arr[0]-->'.$arr[0].'<br>');
						$consolidated_value = $consolidated_value.$this->Datalogic->_FV[$fv_key][$t];
					};*/
					
					
				}
				
				//if(trim($consolidated_value=='')) $fv_counter=0; //commented off as it cause wrong output with null entries
			}
			
		}
		$fv_counter = $largest_num;
		//_echo ('<h1>largest_num='.$largest_num.'</h1>');
		//_echo ('<h1>fv_counter='.$fv_counter.'</h1>');
		
		$_POST_size=$chk[$datagrpinfos][$arr[0]]+1; //_echo ('<h1>_POST_size='.$_POST_size.'</h1>');
		$row_max_orig = $row_max; //_echo ('<h1>row_max_orig='.$row_max_orig.'</h1>');
		
		if($_POST_size > $row_max_orig) {
			//_echo('$_POST_size > $row_max_orig');
			$row_max= $_POST_size;
		}
		if( isset($counter) ){
			//_echo('isset counter');
			$row_max= $counter;
		}
		
		if($fv_counter>$row_max_orig){
			//_echo('$fv_counter larger than $row_max_orig');
			$row_max = $fv_counter;
		}
		
		if(isset($this->HtmlComponents->Pagination_MAX_DISPLAY)) {
			//_echo('isset $Pagination_MAX_DISPLAY');
			//print_r($this->HtmlComponents->HTML_COMPOS);
			//PERFORMS CHECKS TO ENSURE THE CORRECT datagrpinfos IS TARGETED FOR DISPLAY
			if( isset( $this->HtmlComponents->HTML_COMPOS[$datagrpinfos]['pagination'] )){
				if($fv_counter == 0){
					$row_max = $fv_counter;
				}

			}
		} 
		
		/*
		if( $Type=='pagination' ){
			if($fv_counter == 0){
				$row_max = $fv_counter;
			}
		}
		
		if( $fv_counter-$row_max >= 2){
			$row_max = $fv_counter -1 ;
		}*/
		
		//_echo ('<h1>row_max finalized-->'.$row_max.' fv_counter-->'.$fv_counter.'</h1>');
		
		return $row_max;
	}
	
	public function data_print($inputs){
		if(isset($inputs['row'])) $r['DataPos'] = 'data-pos="'.$inputs['row'].'"';
		if(isset($inputs['tier_generic'])) $r['DataFormat'] = 'data-f="'.$inputs['tier_generic'].'"';//.$inputs['row'].']"';
		if(isset($r)){
			foreach(array_keys($r) as $key){
				echo ' '.$r[$key].' ';
			}
		}
	}
	//Driver for FS[]['mod'] operations. Usually used for formatting data display.
	public function mod_inputs($inputs){
		//print_r($inputs['mod']);
		if(!empty($inputs['mod'])) {
			$mod_func = key($inputs['mod']);
			if(method_exists($this->Datalogic, $mod_func)){ 
				$inputs = $this->Datalogic->$mod_func($inputs);
			} elseif(method_exists($this, $mod_func)){ 
				$inputs = $this->$mod_func($inputs);
			}		
		}
		//print_r($inputs);
		return $inputs;
	}
/*
****************************************************
Methods to 'mod' display information. Used only for input_display or input_select_display
****************************************************
*/	
public function display_mod_number_format_money($inputs){

	if(!empty($inputs['value'])){
		if(is_numeric($inputs['value'])){
			$inputs['value'] = number_format($inputs['value'],2);
		}
	}
	
	return $inputs;
}
/*
****************************************************
Methods to print HTML form elements
****************************************************
*/
	//****************************************************
	//embed_hidden_field input
	//****************************************************	
	private function embed_hidden_field($inputs){ //_print_r($inputs);
		if($inputs['embed_hidden_field']===true) {
			$inputs['force_no_disable']=true;
			$this->input_hidden($inputs);
		}		
	}
	//****************************************************
	//display piety
	//****************************************************
	public function input_piety($inputs){
	?>
	<span class="pie"><?php echo $inputs['value'];?>/100</span>
	<?php echo $inputs['value'];?>%
	<?php
	}
	//****************************************************
	//display data label
	//****************************************************
	public function input_display_data_label($inputs){	
	$class=$inputs['class'];

	//mods...
	$inputs = $this->mod_inputs($inputs);
	
	//set alert type 
	$status_type=array('Rejected','Unpaid');
	//set _ALERT if value matches values in alert array
	if(in_array($inputs['value'],$status_type)) $class.=' _ALERT';
	
	?>
	<?php if($inputs['show_label']) $this->show_label($inputs); ?><span class='<?php echo $class; ?>'><?php echo $inputs['value'];?></span>
	<?php
	}
	public function _set_display_data_label ($inputs){
		$FSID = $inputs['grpinfos'];
		$tier_name = $inputs['tier_name'];
		$value = $inputs['value'];
		$class ='';
		
		//retrieve settings
		if( !empty( $this->Datalogic->FS[ $FSID ][ $tier_name ][ '_display_data_label' ]) ){
			//_print_r($inputs);
			$display_data_label_group = $this->Datalogic->FS[ $FSID ][ $tier_name ][ '_display_data_label' ];
			global $_DATA_LABEL_GRPS;
			$setting = $_DATA_LABEL_GRPS [ $display_data_label_group ]; //_print_r($setting);
			//_echo ($value);
			//Retrieve display label class
			if(isset( $setting [ $value ] )){
				$class = $setting [ $value ] ; //_echo ($class);
			}			
			
		}
		return $class;
	}
	
	//****************************************************
	//display text
	//****************************************************
	public function input_display($inputs){	
	$class=$inputs['class'];
	$status_type=array('Rejected','Unpaid');
	if(in_array($inputs['value'],$status_type)) $class.=' _ALERT';

	//Driver for FS[]['mod'] operations
	$inputs = $this->mod_inputs($inputs);
		
	if($inputs['show_label']) $this->show_label($inputs); ?><span <?php $this->attribute_gen($inputs); ?>><?php echo $inputs['value'];?></span>
	
	<?php
	
	$this->embed_hidden_field($inputs);
	}

	//****************************************************
	//text pw
	//****************************************************
	public function input_password($inputs){	
	?>
	<?php if($inputs['show_label']) $this->show_label($inputs); ?><input type="password"  <?php $this->attribute_gen($inputs); ?>/>
	<?php
	}	
	
	//****************************************************
	//hidden
	//****************************************************
	public function input_hidden($inputs){	//_print_r($inputs);
	$inputs['type'] = 'hidden';
	
	//Process embed_hidden_field_data
	if(!empty($inputs['embed_hidden_field_data']['_dvalue'])) {
		$inputs['dvalue'] = $inputs['embed_hidden_field_data']['_dvalue'];
		$inputs =  $this->_dvalue_process($inputs,$inputs['grpinfos'],$inputs['tier_name'] ,'embed_hidden_field_data');
	}
	if(!empty($inputs['embed_hidden_field_data']['_colname'])){
		$inputs['input_info_fs'] = $inputs['embed_hidden_field_data']['_colname'];
		
		$inputs['tier_generic'] = str_replace($inputs['tier_name'], $inputs['embed_hidden_field_data']['_colname'], $inputs['tier_generic']);
		$inputs['name'] = str_replace($inputs['name'], $inputs['embed_hidden_field_data']['_colname'], $inputs['name']);
		
		$inputs['tier_name'] = $inputs['embed_hidden_field_data']['_colname'];
		$inputs['name'] = $inputs['embed_hidden_field_data']['_colname'];
	}
	


	//_print_r($inputs);
	
	?>
	<input type="hidden"  <?php $this->attribute_gen($inputs); ?>/>
	<?php
	}
	//****************************************************
	//input-group-btn input
	//****************************************************
	public function input_group_btn($inputs){
		if(isset($inputs['input-group-btn'])){
			$alias = isset($inputs['input-group-btn']['_alias']) ? $inputs['input-group-btn']['_alias'] : 'Submit';
			$class = isset($inputs['input-group-btn']['_class']) ? $inputs['input-group-btn']['_class'] : '';
			$icon = isset($inputs['input-group-btn']['_icon']) ? ' <i class="'.$inputs['input-group-btn']['_icon'].'"></i> ' : '' ;
			echo '<span class="input-group-btn"><button class="btn '.$class.'" type="button">'.$icon.$alias.'</button></span>';			
		}
		$this->embed_hidden_field($inputs);

	}
	//****************************************************
	//input-group-addon-front input
	//****************************************************
	public function input_group_addon_front($inputs){
		
		if(isset($inputs['input-group-addon'][0])){
			$alias = isset($inputs['input-group-addon'][0]['_alias']) ? $inputs['input-group-addon'][0]['_alias'] : 'Submit';
			$class = isset($inputs['input-group-addon'][0]['_class']) ? $inputs['input-group-addon'][0]['_class'] : '';
			$icon = isset($inputs['input-group-addon'][0]['_icon']) ? ' <i class="'.$inputs['input-group-addon'][0]['_icon'].'"></i> ' : '' ;
			echo '<span class="input-group-addon '.$class.'">'.$icon.$alias.'</span>';
		}
		$this->embed_hidden_field($inputs);
	}
	public function input_group_addon_back($inputs){
		
		if(isset($inputs['input-group-addon'][1])){
			$alias = isset($inputs['input-group-addon'][1]['_alias']) ? $inputs['input-group-addon'][1]['_alias'] : 'Submit';
			$class = isset($inputs['input-group-addon'][1]['_class']) ? $inputs['input-group-addon'][1]['_class'] : '';
			$icon = isset($inputs['input-group-addon'][1]['_icon']) ? ' <i class="'.$inputs['input-group-addon'][1]['_icon'].'"></i> ' : '' ;
			echo '<span class="input-group-addon '.$class.'">'.$icon.$alias.'</span>';			
		}
		$this->embed_hidden_field($inputs);

	}	
	public function input_bs_form_grp($inputs, $content=''){
		
		ob_start();
			//input-group-addon-front
			$this->input_group_addon_front($inputs);
			echo $content;
			//input-group-addon-back
			$this->input_group_addon_back($inputs);
			//input-group-btn
			$this->input_group_btn($inputs);
		$content=ob_get_contents();
		ob_end_clean();		
		
		if(!empty($inputs['bs_form_grp'])) {
			if($inputs['bs_form_grp']!='') echo '<div class="'.$inputs['bs_form_grp'].'">'.$content.'</div>';
		}
		$this->embed_hidden_field($inputs);
	}
	//****************************************************
	//text input
	//****************************************************
	public function input_text($inputs){	//_print_r($inputs);
		//label
		if( $inputs['show_label'] ) $this->show_label($inputs); 
		

		ob_start(); ?>		
		<input type="text"  <?php $this->attribute_gen($inputs); ?>/><?php
		$content=ob_get_contents();
		ob_end_clean();
		
		if(empty($inputs['bs_form_grp'])) {
			print_r($content);
		} else {
			$this->input_bs_form_grp($inputs, $content);
		}
		
		$this->embed_hidden_field($inputs);

	}

	//****************************************************
	//text input
	//****************************************************
	public function input_textarea($inputs){	//_print_r($inputs);
		//label
		if( $inputs['show_label'] ) $this->show_label($inputs); 
		

		ob_start(); ?>
		<textarea type="text"  <?php $this->attribute_gen($inputs); ?>/></textarea><?php
		$content=ob_get_contents();
		ob_end_clean();
		
		if(empty($inputs['bs_form_grp'])) {
			print_r($content);
		} else {
			$this->input_bs_form_grp($inputs, $content);
		}
		
		$this->embed_hidden_field($inputs);

	}	
	
	//****************************************************
	//checkbox input
	//****************************************************
	public function input_checkbox($inputs){ //echo '->inputs[value]'.$inputs['value'];
		//echo 'cvalue: ',$inputs['cvalue'],' value:',$inputs['value'];
		$errormessage= $this->show_checked($inputs['value'],$inputs['cvalue']) ===false && !empty($inputs['position'])? '<span class="_ERROR">'.$inputs['errplaceholder'].'</span>' : '' ; 
	?>
    <input type="checkbox" <?php $this->attribute_gen($inputs); ?>/>
    <?php
		if($inputs['text']=='') {
			if($inputs['show_label']) $this->show_label($inputs,$inputs['name']);
		} else {
			echo '<div class="_CHECKBOXTEXT">',$errormessage,$this->show_compulsory($inputs['compulsory']),$inputs['text'],'</div>';
		}
		$this->embed_hidden_field($inputs);
	}
	//****************************************************
	//select_display input
	//****************************************************
	public function input_select_display($inputs){ 	
		if($inputs['show_label']) $this->show_label($inputs); 
		
		$tmpArr = explode('.', $inputs['grpinfos'] );
		//print_r($tmpArr);
		$inputs['grpinfos'] =$tmpArr[0].'.'.$tmpArr[1]; //Filters to remove the last .1 from a.1a.1
		
		$this->input_option($inputs);

	}
	//****************************************************
	//select input
	//****************************************************
	public function input_select($inputs){ 	
	?>
    <?php if($inputs['show_label']) $this->show_label($inputs); ?>
	<?php 
		
		$tmpArr = explode('.', $inputs['grpinfos'] );
		//print_r($tmpArr);
		$inputs['grpinfos'] =$tmpArr[0].'.'.$tmpArr[1]; //Filters to remove the last .1 from a.1a.1
		
		/* Diagnostics */
		/*
		echo '-',$inputs['grpinfos'],'-',$inputs['input_info_fs'],'-',$inputs['group_gen'],'-',$inputs['group'],'<br>';
		
		//print_r($this->Datalogic->MISC_DATA);
		echo '<br>';
		//print_r($this->Datalogic->MISC_DATA[ $inputs['grpinfos'] ][ $inputs['input_info_fs'] ]['_group_gen']); 
		echo '<br>';
		echo $displayname = $this->Datalogic->QS[ $inputs['group_gen'] ]['_group_gen_displayname'];
		echo $id = $this->Datalogic->QS[ $inputs['group_gen'] ]['_group_gen_id'];
		*/
		//print_r($inputs);
		//print_r($this->Datalogic->MISC_DATA);
		//$row = $this->Datalogic->MISC_DATA[ $inputs['fs_target'] ][ $inputs['colname'] ]['_group_gen']; 
		//$row = $this->Datalogic->MISC_DATA[ $inputs['fs_target'] ][ $inputs['colname'] ]['_group'];
		//print_r($inputs);
		//print_r($row);
	?>
    <select <?php $this->attribute_gen($inputs); ?>>
    <?php if(empty($inputs['ng-options'])) $this->input_option($inputs); ?>
    </select>
    <?php
	$this->embed_hidden_field($inputs);
	}
	private function input_option_misc_data_attr( $row, $row_counter, $data_attr_id ){
		$attributes='';
		//$row[$row_counter][$id];
		if(is_array($data_attr_id)){
			foreach(array_keys($data_attr_id) as $id){
				$attributes = $attributes.' '.$data_attr_id[$id].'='.$row[$row_counter][$id];
			}			
		}

		return $attributes;
	}
	//part of input_select()
	private function input_option($inputs){
		
		$group = $inputs['group'];
		$value = $inputs['value'];
		
		if(isset($inputs['group_gen'])) {
			//generate <option> from db
			//****************************************************

			//Retrieve information from MISC_DATA
			//sample format of MISC_DATA[datainfo][colinfo]['_group_gen']=row data ("displayname"=>"value", ... )
			//echo '--->',$inputs['grpinfos'] ,$inputs['input_info_fs'];
			
			
			//$inputs['grpinfos'] = $tmpArr[1].'.'.$temArr[2];
			
			if(!isset($inputs['nfs'])){
				//FS settings
				$row = $this->Datalogic->MISC_DATA[ $inputs['grpinfos'] ][ $inputs['input_info_fs'] ]['_group_gen']; //print_r($this->Datalogic->MISC_DATA);
				
			} else {				
				//NFS settings
				$row = $this->Datalogic->MISC_DATA[ $inputs['fs_target'] ][ $inputs['colname'] ]['_group_gen']; //print_r($this->Datalogic->MISC_DATA);

			}
			/*
			echo '<option>';
			print_r($row);
			echo '</option>';
			*/
			if(isset($this->Datalogic->QS[ $inputs['group_gen'] ]['_group_gen_displayname'])) $displayname = $this->Datalogic->QS[ $inputs['group_gen'] ]['_group_gen_displayname'];
			if(isset($this->Datalogic->QS[ $inputs['group_gen'] ]['_group_gen_id'])) $id = $this->Datalogic->QS[ $inputs['group_gen'] ]['_group_gen_id'];
			$tmp='';
			if(isset($this->Datalogic->QS[ $inputs['group_gen'] ]['_misc_data_attr'])) {
				$_misc_data_attr = $this->Datalogic->QS[ $inputs['group_gen'] ]['_misc_data_attr'];
				foreach(array_keys($_misc_data_attr) as $index){ 
					$tmp[ $index ] = $_misc_data_attr[ $index ];
				}
			}
			
			//Display default option
			if(isset($inputs['placeholder'])){
				if($inputs['placeholder']!='' && $inputs['type']!='select_display'){
					?>
					<option value=""><?php echo $inputs['placeholder'];?></option>
					<?php
				}
			}
			
			foreach(array_keys($row) as $x){
				if($inputs['type']!='select_display'){
				?>
				<option value="<?php echo $row[$x][$id]; ?>" <?php echo $selected = $value==$row[$x][$id] ? 'selected' : '';?> <?php echo $this->input_option_misc_data_attr($row, $x , $tmp); ?>><?php echo $row[$x][$displayname]; ?></option>
				<?php } else { ?>
				<?php echo $display_value = $value==$row[$x][$id] ? $row[$x][$displayname] : '';?>
				<?php
				}
			}
			
		} else {
			//print_r($inputs['group']);
			
			//Display default option
			//****************************************************
			if(isset($inputs['placeholder'])){
				if($inputs['placeholder']!='' && $inputs['type']!='select_display'){
					?>
					<option value=""><?php echo $inputs['placeholder'];?></option>
					<?php
				}
			}
			
			//generate <option> from FS
			//****************************************************
			foreach(array_keys($group) as $x){
				?>
				<option value="<?php echo $group[$x]['_gvalue']; ?>" <?php echo $selected = $value==$group[$x]['_gvalue'] ? 'selected' : '';?>><?php echo $group[$x]['_display']; ?></option>
				<?php
			}			
		}
		

	}
	//****************************************************
	//attributes generator
	//****************************************************
	private function attribute_gen($inputs){
		//_print_r($inputs);
		//generic attributes
		if($inputs['alias']!='_SPAMBLOCK') $this->data_print($inputs); //needed for system jquery dynamic operations
		
		//manual attributes input
		if($inputs['alias']!='_SPAMBLOCK' && !empty($inputs['datepicker'])) $this->data_print_datepicker($inputs);
		
		//get $inputs['inlined_w']
		if(!empty($inputs['inlined_w'][1])) {	
			$_iw = $inputs['inlined_w'][1];
			$inlined_w = 'col-sm-'.$_iw.' col-md-'.$_iw.' col-lg-'.$_iw;		
		}
		
		if(isset($inputs['nfs'])) {
			echo 'class="form-control ',$inputs['class'],' ',$inlined_w,'" ';
		} else {
			echo 'class="_DATA form-control ',$inputs['class'],' ',$inlined_w,'" ';
		}
		
		if(isset($inputs['input_info_fs'])){
			echo 'data-name="',$inputs['input_info_fs'],'" ';
		}
		
		echo 'name="',$inputs['name'],'" ';
		echo 'id="',$inputs['form_attri_id'],'" ';
		
		//Set Disabled
		if( empty($inputs['force_no_disable']) ){
			if(isset($inputs['disabled'])) {	
				if($inputs['disabled']===true) echo ' disabled ';
			}
		}
		//print_r($inputs);
		
		
		//set FSID
		$FSID = $inputs['grpinfos'];
		//echo ' data-FSID="'.$FSID.'" ';		
		
		
		//type specific attributes
		switch ($inputs['type']){
			case "text":				 
				echo 'value="',$inputs['value'],'" ';				
				echo 'placeholder="',$inputs['placeholder'],'" ';	
				if(trim($inputs['title'])!='') echo 'title="',$inputs['title'],'" ';	
			break;
			
			case "password":				 
				echo 'value="',$inputs['value'],'" ';				
				echo 'placeholder="',$inputs['placeholder'],'" ';	
				if(trim($inputs['title'])!='') echo 'title="',$inputs['title'],'" ';					
			break;
			
			case "hidden":				 
				echo 'value="',$inputs['value'],'" ';							
			break;
			
			case "select":
				
			break;
			
			case "checkbox":
				echo 'value="',$inputs['cvalue'],'" ';
				echo $this->show_checked($inputs['value'],$inputs['cvalue']);
			break;
		}
		
		//AngularJS
		if(isset($inputs['ng-model'])) echo ' ng-model ="'.$inputs['ng-model'].'"';
		if(isset($inputs['ng-options'])) echo ' ng-options ="'.$inputs['ng-options'].'"';
		
	}
	public function data_print_datepicker ($inputs){
		//_print_r( $inputs['datepicker']['date-min'] );
		if(isset($inputs['datepicker']['date-min'])) {
		
			if(is_array($inputs['datepicker']['date-min'])){	
				foreach(array_keys($inputs['datepicker']['date-min']) as $k){ //echo $r['test']='test="'.$k.'"';
					if(method_exists($this->Datalogic,$k)){ 
						$this->Datalogic->$k($inputs);
					}
				}
			} else {
				$r['date-min'] = 'datepicker-date-min="'.$inputs['datepicker']['date-min'].'"';
			}
		}
		
		
		if(isset($inputs['datepicker']['date-max'])) {
			if(is_array($inputs['datepicker']['date-max'])){
				foreach(array_keys($inputs['datepicker']['date-max']) as $k){ //echo $r['test']='test="'.$k.'"';
					if(method_exists($this->Datalogic,$k)){ 
						$this->Datalogic->$k($inputs);
					}
				}
				
			} else {
				$r['date-max'] = 'datepicker-date-max="'.$inputs['datepicker']['date-max'].'"';
			}
			
		}
		
		if(isset($r)){
			foreach(array_keys($r) as $key){
				echo ' '.$r[$key].' ';
			}
		}		
	}
	private function action_edit($FSIDID,$type='', $FSID_ID ,$rights){ 
		if(!empty($rights['_link'])) $link = $rights['_link']; //meant for manual override
		if(!empty($rights['_linkcid'])) $linkcid = $rights['_linkcid']; //link to destination category id
		
		if(!isset($link) && $linkcid!=''){
			$link = $this->Site->_GET_URL('','',$linkcid);
		}
		
		//echo '<a class="btn btn-link btn-sm" href="'.$link.'?id='.$FSID_ID.'"><i class="fa fa-pencil"></i> Edit</a>';
		//echo $FSID_ID;
		echo '<a class="btn btn-link btn-sm" href="'.$link.'?id='.base64url_encode($FSID_ID).'"><i class="fa fa-pencil"></i> Edit</a>';

	}
	
	private function action_view($FSIDID,$type='', $FSID_ID ,$rights){ 
		if(!empty($rights['_link'])) $link = $rights['_link']; //meant for manual override
		if(!empty($rights['_linkcid'])) $linkcid = $rights['_linkcid']; //link to destination category id
		if(!empty($rights['_param_name'])) {
			$param_name = $rights['_param_name']; //link to destination category id
		} else {
			$param_name = 'id';
		}
		//Check if there's a need to base64url_encode FSID
		if(isset($rights['_base64'])){
			if($rights['_base64']) $FSID_ID = base64url_encode($FSID_ID);
		}
		if(!empty($rights['_target'])) {
			$target = $rights['_target']; //meant for manual override
		} else {
			$target ='';
		}
		
		//if internal id, linkcid, is specificed, use system to get url .. 
		if(!isset($link) && $linkcid!=''){
			$link = $this->Site->_GET_URL('','',$linkcid); 
		}

		
		echo '<a class="btn btn-link btn-sm" href="'.$link.'?'.$param_name.'='.$FSID_ID.'" target="'.$target.'"><i class="fa fa-eye"></i> View</a>';
	}
	
	private function input_edit_actions($FSIDID,$type='', $FSID_ID, $Tier){
		//echo $FSIDID;
		//echo $FSID_ID;
		$FSID_ar = explode('.',$FSIDID);
		$FSID = $FSID_ar[0].'.'.$FSID_ar[1];
		//retrieve rights
		if(!empty($this->FS_LAYOUT[ $FSID ]['_fs_type']['_rights'])){
			$rights = $this->FS_LAYOUT[ $FSID ]['_fs_type']['_rights']; //_print_r($rights);
			if(array_key_exists('_edit',$rights)) {
				$_rights = $rights['_edit'];
				$this->action_edit($FSIDID,'', $FSID_ID, $_rights);
			}	
			
			if(array_key_exists('_view',$rights)) {
				$_rights = $rights['_view'];
				$this->action_view($FSIDID,'', $FSID_ID, $_rights);
			}
		}

	}
	//****************************************************
	//Dynamic delete and add buttons/checkbox
	//****************************************************
	private function input_dyn_actions($FV_dataINFOS,$type='', $FSID_ID, $Tier){
		
		$FSID = str_replace( '.'.$FSID_ID, '', $FV_dataINFOS);
		
		$arr = json_decode($_POST['Chked_Hist']);
		//_print_r($arr);
		if(!empty($arr)){
			foreach($arr as $v ){
				//_echo($v.'->');
				//_echo($FV_dataINFOS_Del.'<br>');
				if($FV_dataINFOS_Del==$v) $checked = 'checked';
			}			
		}

		if(!empty($this->Datalogic->FS_LAYOUT[$FSID]['_fs_type']['_chked']['_data']) && empty($_POST['_SUBMIT']) ){
			$_chked_arr_data = json_decode($this->Datalogic->FS_LAYOUT[$FSID]['_fs_type']['_chked']['_data']) ; //print_r($_chked_arr_data);
			if(is_array($_chked_arr_data)){
				if(in_array( $FSID_ID, $_chked_arr_data)) $checked = 'checked';	
			}
					
		}
		
		$attri_exceptions = array('_checks','_data');
		if(!empty($this->Datalogic->FS_LAYOUT[$FSID]['_fs_type']['_chked']) ){
			if(is_array($this->Datalogic->FS_LAYOUT[$FSID]['_fs_type']['_chked'])){
				
				foreach( array_keys($this->Datalogic->FS_LAYOUT[$FSID]['_fs_type']['_chked']) as $attri ){
					
					
					if(!in_array($attri,$attri_exceptions)){
						
						if(is_array($this->Datalogic->FS_LAYOUT[$FSID]['_fs_type']['_chked'][$attri])){
							//_echo ($attri);
							foreach( array_keys($this->Datalogic->FS_LAYOUT[$FSID]['_fs_type']['_chked'][$attri]) as $ops_func) {
								//_echo ($ops_func);
								if(method_exists($this->Datalogic,$ops_func)){ //_E_TRACE($FV_NameTier,true);
									//_echo ($ops_func);
									$ops_params['fsid'] = $FSID;
									$ops_params['id'] = $FSID_ID;
									$ops_params['curr_tier'] = $Tier;
									$ops_params['params'] = isset($this->Datalogic->FS_LAYOUT[$FSID]['_fs_type']['_chked'][$attri][$ops_func] ) ? $this->Datalogic->FS_LAYOUT[$FSID]['_fs_type']['_chked'][$attri][$ops_func] : '';
									
									$_FS_LAYOUT_inputs[$attri] = $this->Datalogic->$ops_func( $ops_params );
								}
							}
							
						}
					}
				}
			}
		}

		//REtrieve #3
		if(!empty($_POST['_CHKED'][$FV_dataINFOS])){
			if($_POST['_CHKED'][$FV_dataINFOS]=='y') $checked = 'checked';	
		}
		
		
		if(!empty($this->Datalogic->FS_LAYOUT[$FSID]['_fs_type']['_chked']['_error'])){
			$error = $this->Datalogic->FS_LAYOUT[$FSID]['_fs_type']['_chked']['_error']===true ? '_ERROR _ERROR_DYN_CHKBOX' : '';
		}
		if(!empty($this->Datalogic->FS_LAYOUT[$FSID]['_fs_type']['_chked']['_disabled'])){ 
			$disabled = $_FS_LAYOUT_inputs['_disabled']===true? ' disabled ' : '';
		}
		
		$CSS_frm_ops = isset($_FS_LAYOUT_inputs['_class']) ?  $_FS_LAYOUT_inputs['_class'] : '' ;
		
		$CSS_input = $error.$CSS_frm_ops;
		$CSS_label = $error.$CSS_frm_ops;
		
		switch($type){
			case 'td_delete_only':
				?>
				<label class="_DYN_CHKBOX_LABEL <?php echo $CSS_label; ?>">
				<input type="checkbox" value="y" class='_DYN_DELETE <?php echo $CSS_input; ?>' name="_CHKED[<?php echo $FV_dataINFOS; ?>] <?php echo $disabled; ?>"/>
				<i class="_DYN_DELETE fa fa-minus-circle fa-6" aria-hidden="true" id="_CHKED[<?php echo $FV_dataINFOS; ?>]"></i>
				</label>
				<?php
			break;
			
			case 'td_checkbox': //echo $FSID_ID;
				//echo $this->Site->CURRCID;
				//echo $FV_dataINFOS;
				
				//[KIV]For handling return back from another form cases, but need to pull this info from db and manual insertion in fs.php
				//$checked = isset( $_POST['_CHKED'][$FV_dataINFOS]) && empty($_POST['Chked_Hist']) ? 'checked' : '' ;
				?>				
				<label class="_DYN_CHKBOX_LABEL <?php echo $CSS_label; ?>"><input type="checkbox" value="y" class='_DYN_DELETE _SYS_CHECKBOX <?php echo $CSS_input; ?>' name="_CHKED[<?php echo $FV_dataINFOS; ?>]" <?php echo $checked; ?> <?php echo $disabled; ?>/></label>
				<?php
			break;
			
			case 'tr_delete_detach': 
				?>
				<label class="_DYN_CHKBOX_LABEL <?php echo $CSS_label; ?>">
				<input type="checkbox" value="y" name="_CHKED[<?php echo $FV_dataINFOS; ?>]" class="_DYN_DELETE _DELETE_DETACH <?php echo $CSS_input; ?>" />
				<i class="_DYN_DELETE _DELETE_DETACH fa fa-minus-circle fa-6" aria-hidden="true" id="_CHKED[<?php echo $FV_dataINFOS; ?>]" ></i>
				</label>
				<i class="_ADD_TR fa fa-plus-circle fa-6" aria-hidden="true" data-toggle="tooltip" data-placement="top" title="Add entry"></i><?php
			break;
			
			case 'tr_delete_detach_warn':
				?><label class="_DYN_CHKBOX_LABEL <?php echo $CSS_label; ?>"><input type="checkbox" value="y" name="_CHKED[<?php echo $FV_dataINFOS; ?>]" class="_DYN_DELETE _DELETE_TR_WARN <?php echo $CSS_input; ?>" <?php echo $disabled; ?>/></label><?php
			break;
			
			default:
				?>
				<label class="_DYN_CHKBOX_LABEL <?php echo $CSS_label; ?>">
				<input type="checkbox" value="y" class='_DYN_DELETE <?php echo $CSS_input; ?>' name="_CHKED[<?php echo $FV_dataINFOS; ?>]" <?php echo $disabled; ?>/>
				<i class="_DYN_DELETE fa fa-minus-circle fa-6" aria-hidden="true" id="_CHKED[<?php echo $FV_dataINFOS; ?>]"></i>
				</label>
				<i class="_ADD_TR fa fa-plus-circle fa-6" aria-hidden="true" ></i><?php				
		}
		

	}
	
/*
****************************************************
Misc methods
****************************************************
*/
	
	/*
	****************************************************
	Testing Sake...
	****************************************************
	*/
	public function Test_print_FV(){
	
		//This will generate all fields using Datalogic->_FV array
		//****************************************************
		$go=false;
		if(isset($this->Datalogic->_FV)) $go=true;
		
		if($go===false) echo 'HTMLFORM.Test_print_FV(): _FV undefined.';
		
		if($go){
			foreach(array_keys($this->Datalogic->_FV) as $datagrpinfos){
				foreach(array_keys($this->Datalogic->_FV[$datagrpinfos]) as $input_infos){
					//echo '<h3>',$datagrpinfos,'-',$input_infos,'</h3>';
					$this->_INPUT($datagrpinfos,$input_infos);
				}
			}
		}
		
		
	}

	
	//****************************************************
	//Show * for compulsory fields
	//****************************************************
	private function show_compulsory($compulsory){
		if($compulsory) {
			//echo '<span>*</span>';
			echo '*';
		}
	}
	
	//****************************************************
	//Formats <label>
	//****************************************************
	private function show_label($inputs,$element_id=''){
		if(isset($inputs['alias'])){
			//print_r($inputs['inlined_w']);
			if(!empty($inputs['inlined_w'][0])) {	
				$_iw = $inputs['inlined_w'][0];
				$inlined_w = 'col-sm-'.$_iw.' col-md-'.$_iw.' col-lg-'.$_iw;		
			}
			
			if($inputs['alias']!='' && $inputs['alias']!='_SPAMBLOCK'){
			//determines if there's a need to for=''
			if($element_id!=''){
				$filter=array('checkbox','checkboxes','radio','radios');
				$for=in_array($inputs['type'],$filter) ? ' for="'.$element_id.'" ' : '';
			}
			
			//determines should error css just be applied to label
			//echo 'value:',$inputs['value'],' cvalue:',$inputs['cvalue'];
			if($for!='' && isset($inputs['text']) && $inputs['value']=='' && $inputs['compulsory']===true && isset($_POST['_SUBMIT'])){
				$errorCSS='_ERROR_LABEL';
			}
			
			$labelCSS = 'class="'.$errorCSS.' '.$inlined_w.'"';
	?>
    <label <?php echo $labelCSS; ?><?php echo $for; ?>><?php echo $inputs['alias'];echo $this->show_compulsory($inputs['compulsory']);  ?></label>
    <?php
			}
		}

	} //show_label
	
	//****************************************************
	//Determines whether to display checked in checkbox
	//****************************************************
	private function show_checked($value, $dvalue){
		$r=false;
		if($dvalue==$value && $value!='') { 
			//echo ' checked';
			$r='checked';
		}
		return $r;
	}

	
	

}//HTMLFORM
?>
