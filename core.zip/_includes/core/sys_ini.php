<?php
if(use_script()) {

	//DATALOGIC
	$Datalogic= new Datalogic_custom();
	$Datalogic->ShowData=false;
	if(isset($Database)) $Datalogic->Database=$Database;
	if(isset($Login)) $Datalogic->Login=$Login;
	if(isset($Settings)) $Datalogic->Settings=$Settings;
	if(isset($Site)) $Datalogic->Site=$Site;
	
	//FORM CHECKS
	$Formchecks= new FormChecks_Custom();
	if(isset($Database)) $Formchecks->Database=$Database;
	if(isset($Datalogic)) $Formchecks->Datalogic=$Datalogic;
	if(isset($Login)) $Formchecks->Login=$Login;
	
	//CREEATE HTMLCOMPONENTS OBJECT
	$HtmlComponents = new HtmlComponents();
	if(isset($Datalogic)) $HtmlComponents->Datalogic=$Datalogic;	
	if(isset($Database)) $HtmlComponents->Database=$Database;
	if(isset($Database)) $HtmlComponents->Site=$Site;

	//CREEATE WIDGET OBJECT
	$Widget = new Widget();
	if(isset($Widget)) $Widget->Datalogic=$Datalogic;	
	if(isset($Widget)) $Widget->Database=$Database;
	if(isset($Widget)) $Widget->Site=$Site;
	
	if( class_exists('Page') && class_exists('PageForm') ){
		
		//CREATE HTMLFORM OBJECT
		//if(isset($Datalogic->$FS)) 
		$Form=new PageForm(); 
		$Form->Site=$Site;
		if(isset($Datalogic)) $Form->Datalogic=$Datalogic;	
		if(isset($Formchecks)) $Form->Formchecks=$Formchecks;
		if(isset($HtmlComponents)) $Form->HtmlComponents=$HtmlComponents;	
		
		//CREATE LAYOUT OBJECT
		$Layout=new Page($Site);	
		//if(isset($Site)) $Layout->Site=$Site;
		//settings
		$Layout->PageTitle=$PageTitle;
		
		//if(isset($Datalogic->$FS)) 
		$Layout->HTMLFORM=$Form;
		$Layout->HtmlComponents=$HtmlComponents;
		$Layout->Widget=$Widget;
		$Layout->Settings=$Settings;
		if(isset($Database)) $Layout->Database=$Database;
		if(isset($Datalogic)) $Layout->Datalogic=$Datalogic;
		
		$Form->Layout= $Layout;
		
	
	} else {

		throw new Exception("Page and PageForm class do not exist.");
		
	}
	

	//var_dump($Form);
	//var_dump(get_object_vars($Form));
	
	//$reflector = new ReflectionClass($Form);
    //var_dump($reflector->getMethods());
	//var_dump($reflector->getMethods());
	//var_dump($reflector->getDocComment());
	
	//$reflectionMethod = new ReflectionMethod(new PageForm(), '_INPUT');
	//echo $reflectionMethod;
	//var_dump($reflectionMethod->getParameters()); 
	//print_r($reflectionMethod->getParameters());
	
	//TO FIND OUT CLASSES DEFINED THUS FAR...
	//GET_STANDARD_CLASSES( $PHP_PREDEF_CLASSES_LAST_KEY );

}
?>