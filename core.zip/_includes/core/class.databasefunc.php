<?php
class Databasefunc extends Database{

}
?>
