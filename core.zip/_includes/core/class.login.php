<?php
class Login{

public $Database;

	//****************************************
	//$_SESSION['Type'] : determines which type of login to direct to
	//password_verify($_SERVER['HTTP_USER_AGENT'].$_SESSION["LoginAccountID"]) : Checks that $_SERVER['HTTP_USER_AGENT'].$_SESSION["LoginAccountID"] 
	//is the same during login and other script usage else it implies user agent has been changed
	//****************************************
	public function _IS_LOGIN($Type){
		//print_r($_SESSION);
		$bool = false;
		//conditions for login
		if($_SESSION['Login']!='' && $_SESSION['Type']== $Type && $this->_VERIFY_UID() === true && $_SESSION['OSID']==session_id()){
			$bool = true;
			
		} else {
			_E_TRACE('login._IS_LOGIN('.$Type.'):: not logined in');
			$bool = false;
		}
		return $bool;
	}
	//****************************************
	//HASH USERID FOR LOGIN
	//****************************************
	public function _SET_UID( $param=array() ){
		$String = '';
		if(is_array($param)){
			foreach( $param as $k ){
				$String = $String.$k;
			}		
		} else {
			$String = $param;
		}
		
		$hash = password_hash($_SERVER['HTTP_USER_AGENT'].$_SERVER['REMOTE_ADDR'].$_SESSION['LoginAccountID'].$String, PASSWORD_DEFAULT);	

		
		return $hash;
	}
	//****************************************
	//VERIFY USERID FOR LOGIN
	//****************************************
	public function _VERIFY_UID( $param=array() ){
		$String = '';
		if(is_array($param)){
			foreach( $param as $k ){
				$String = $String.$k;
			}		
		} else {
			$String = $param;
		}

		return password_verify($_SERVER['HTTP_USER_AGENT'].$_SERVER['REMOTE_ADDR'].$_SESSION['LoginAccountID'].$String, $_SESSION['UserID'] );
	}


public function _CHECK_ADMIN_PW($Password){ 

	$error = false;
	$params = array(md5($Password) ,$_POST['_FN']['a.1a']['Username.#0']); 
	$Password = $this->Database->core_query_select('account', $params, 'COUNT(Password)', 'Password=? AND Username=?');
	$PasswordCount = $Password[0]['COUNT(Password)'];
	if($PasswordCount!=1 && $Password!=''){
		//wrong pw....
		_E_TRACE('INVALID PW');
		$error_msg = "Invalid password";
		$_SESSION["Msg"]="Invalid password";

		$params=array(
			'Username'=>$_POST['_FN']['a.1a']['Username.#0'],
			'Message'=>$error_msg,
			'IPAddress'=>$_SERVER[REMOTE_ADDR],
			'LoginTime'=>'NOW()'
		);
		//print_r($params);
		//$this->Database->core_query_insert('login_log', $params ,'Username,Message,IPAddress,LoginTime', ':Username, :Message,: IPAddress, :LoginTime');
		//$this->Datalogic->_FV['a.1a']['Password.#0'] = ''; 
		$error = true;
	}
	//if(!$error) _E_TRACE('pw OK',true);
	return $error;
}

public function _CHECK_ADMIN_USERNAME($UsernameINPUT){ 

	$error = false;
	$params = array($UsernameINPUT);
	
	$Username = $this->Database->core_query_select('account', $params, 'COUNT(Username)', 'Username=?');
	$UsernameCount = $Username[0]['COUNT(Username)'];
	if($UsernameCount!=1 && $Username!=''){
		//wrong username....
		_E_TRACE('INVALID username');
		$error_msg = "Invalid username";
		$_SESSION["Msg"]="Invalid username";
		
		$params=array(
			'Username'=>$UsernameINPUT,
			'Message'=>$error_msg,
			'IPAddress'=>$_SERVER[REMOTE_ADDR],
			'LoginTime'=>'NOW()'
		);
		//print_r($params);		
		//$this->Database->core_query_insert('login_log', $params ,'Username,Message,IPAddress,LoginTime', ':Username, :Message,: IPAddress, :LoginTime');
		$error = true;
	}
	//if(!$error) _E_TRACE('username OK',true);
	return $error;
}

public function _DO_ADMIN_LOGIN($Username,$Password){
	
	if($Username!='' && $Password!=''){
		_E_TRACE('GET ACCOUNT TYPE');
		//GET ACCOUNT TYPE
		$params = array(md5($Password),$Username);
		//$row = $this->Database->core_query_select('account', $params, 'Salutation,FirstName,LastName,Email,ClientID', 'Password=? AND Email=?');
		$row = $this->Database->core_query_select('account', $params, 'Name, AccountID', 'Password=? AND Username=?');
		//print_r($row);
		$_SESSION["Login"]='Admin';
		//$_SESSION["Name"]=$row[0]["Salutation"].' '.$row[0]["FirstName"].' '.$row[0]["LastName"];
		$_SESSION["Name"]=$row[0]["Username"];
		$_SESSION["LoginAccountID"]=$row[0]["AccountID"];
		//$_SESSION["Username"]=$row[0]["Email"];
		$_SESSION["Type"]= "_BIS_ADMIN";
		$_SESSION['UserID'] = $this->_SET_UID();
		session_regenerate_id();//force session id change
		$_SESSION['OSID'] = session_id();
		//$_SESSION['ROW'] = $row;
		//print_r($_SESSION);

		
		//insert into login_log
		$params=array(
			'Username'=>$row[0]["AccountID"],
			'Message'=>'Login OK',
			'IPAddress'=>$_SERVER[REMOTE_ADDR],
			'LoginTime'=>'NOW()'
		);

		//print_r($params);		
		//$this->Database->core_query_insert('login_log', $params ,'Username,Message,IPAddress,LoginTime', ':Username, :Message,: IPAddress, :LoginTime');
	} //if($Username!='' && $Password!=''){
		
}




}

?>