<?php
if(use_script()) {

	switch($placeholderID){
		case 'line_graph':
		?>
			<div class="ibox">
                            <div class="ibox-content">
                                <h5>Visits in last 24h</h5>
                                <h2>198 009</h2>
                                <div id="sparkline1"></div>
                            </div>
             </div>
		<?php
		break;
		
		case 'news_alert':
		?>
		<div class="ibox">
    <div class="ibox-content">
        <h5>Last notification</h5>
        <table class="table table-stripped small m-t-md">
            <tbody>
            <tr>
                <td class="no-borders">
                    <i class="fa fa-circle text-danger"></i>
                </td>
                <td  class="no-borders">
                    Example element 1
                </td>
            </tr>
            <tr>
                <td>
                    <i class="fa fa-circle text-danger"></i>
                </td>
                <td>
                    Example element 2
                </td>
            </tr>
            <tr>
                <td>
                    <i class="fa fa-circle text-danger"></i>
                </td>
                <td>
                    Example element 3
                </td>
            </tr>
            </tbody>
        </table>
    </div>
</div>
		<?php
		break;
		case '1':
		?>
		<h2>Welcome Amelia</h2>
		<small>You have 42 messages and 6 notifications.</small>
		<ul class="list-group clear-list m-t">
		<li class="list-group-item fist-item">
		<span class="pull-right">
		09:00 pm
		</span>
		<span class="label label-success">1</span> Please contact me
		</li>
		<li class="list-group-item">
		<span class="pull-right">
		10:16 am
		</span>
		<span class="label label-info">2</span> Sign a contract
		</li>
		<li class="list-group-item">
		<span class="pull-right">
		08:22 pm
		</span>
		<span class="label label-primary">3</span> Open new shop
		</li>
		<li class="list-group-item">
		<span class="pull-right">
		11:06 pm
		</span>
		<span class="label label-default">4</span> Call back to Sylvia
		</li>
		<li class="list-group-item">
		<span class="pull-right">
		12:00 am
		</span>
		<span class="label label-primary">5</span> Write a letter to Sandra
		</li>
		</ul>
		<?php
		break;

		case '2':
		?>
		<div class="flot-chart dashboard-chart">
			<div class="flot-chart-content" id="flot-dashboard-chart"></div>
		</div>
		<div class="row text-left">
			<div class="col-xs-4">
				<div class=" m-l-md">
				<span class="h4 font-bold m-t block">$ 406,100</span>
				<small class="text-muted m-b block">Sales marketing report</small>
				</div>
			</div>
			<div class="col-xs-4">
				<span class="h4 font-bold m-t block">$ 150,401</span>
				<small class="text-muted m-b block">Annual sales revenue</small>
			</div>
			<div class="col-xs-4">
				<span class="h4 font-bold m-t block">$ 16,822</span>
				<small class="text-muted m-b block">Half-year revenue margin</small>
			</div>

		</div>
		<?php
		break;
		
		case '3':
		?>
		<div class="ibox float-e-margins">
		<div class="ibox-title">
			<h5>New data for the report</h5> <span class="label label-primary">IN+</span>
			<div class="ibox-tools">
				<a class="collapse-link">
					<i class="fa fa-chevron-up"></i>
				</a>
				<a class="dropdown-toggle" data-toggle="dropdown" href="#">
					<i class="fa fa-wrench"></i>
				</a>
				<ul class="dropdown-menu dropdown-user">
					<li><a href="#">Config option 1</a>
					</li>
					<li><a href="#">Config option 2</a>
					</li>
				</ul>
				<a class="close-link">
					<i class="fa fa-times"></i>
				</a>
			</div>
		</div>
		<div class="ibox-content">
			<div>

				<div class="pull-right text-right">

					<span class="bar_dashboard">5,3,9,6,5,9,7,3,5,2,4,7,3,2,7,9,6,4,5,7,3,2,1,0,9,5,6,8,3,2,1</span>
					<br/>
					<small class="font-bold">$ 20 054.43</small>
				</div>
				<h4>NYS report new data!
					<br/>
					<small class="m-r"><a href="graph_flot.html"> Check the stock price! </a> </small>
				</h4>
				</div>
			</div>
		</div>
		
		<?php
		break;
		
		case '4':
		?>
		<div class="ibox float-e-margins">
		<div class="ibox-title">
			<h5>Messages</h5>
			<div class="ibox-tools">
				<a class="collapse-link">
					<i class="fa fa-chevron-up"></i>
				</a>
				<a class="close-link">
					<i class="fa fa-times"></i>
				</a>
			</div>
		</div>
		<div class="ibox-content ibox-heading">
			<h3><i class="fa fa-envelope-o"></i> New messages</h3>
			<small><i class="fa fa-tim"></i> You have 22 new messages and 16 waiting in draft folder.</small>
		</div>
		<div class="ibox-content">
			<div class="feed-activity-list">

				<div class="feed-element">
					<div>
						<small class="pull-right text-navy">1m ago</small>
						<strong>Monica Smith</strong>
						<div>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum</div>
						<small class="text-muted">Today 5:60 pm - 12.06.2014</small>
					</div>
				</div>

				<div class="feed-element">
					<div>
						<small class="pull-right">2m ago</small>
						<strong>Jogn Angel</strong>
						<div>There are many variations of passages of Lorem Ipsum available</div>
						<small class="text-muted">Today 2:23 pm - 11.06.2014</small>
					</div>
				</div>

				<div class="feed-element">
					<div>
						<small class="pull-right">5m ago</small>
						<strong>Jesica Ocean</strong>
						<div>Contrary to popular belief, Lorem Ipsum</div>
						<small class="text-muted">Today 1:00 pm - 08.06.2014</small>
					</div>
				</div>

				<div class="feed-element">
					<div>
						<small class="pull-right">5m ago</small>
						<strong>Monica Jackson</strong>
						<div>The generated Lorem Ipsum is therefore </div>
						<small class="text-muted">Yesterday 8:48 pm - 10.06.2014</small>
					</div>
				</div>


				<div class="feed-element">
					<div>
						<small class="pull-right">5m ago</small>
						<strong>Anna Legend</strong>
						<div>All the Lorem Ipsum generators on the Internet tend to repeat </div>
						<small class="text-muted">Yesterday 8:48 pm - 10.06.2014</small>
					</div>
				</div>
				<div class="feed-element">
					<div>
						<small class="pull-right">5m ago</small>
						<strong>Damian Nowak</strong>
						<div>The standard chunk of Lorem Ipsum used </div>
						<small class="text-muted">Yesterday 8:48 pm - 10.06.2014</small>
					</div>
				</div>
				<div class="feed-element">
					<div>
						<small class="pull-right">5m ago</small>
						<strong>Gary Smith</strong>
						<div>200 Latin words, combined with a handful</div>
						<small class="text-muted">Yesterday 8:48 pm - 10.06.2014</small>
					</div>
				</div>

			</div>
		</div>
		</div>	
		<?php
		break;
	}
} ?>