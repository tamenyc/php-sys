<?php

class DB {     

	private $db;    

	

	public function __construct($server, $database, $user, $password) {

		

		try {

			$conn= new PDO(

				'mysql:dbname=' . $database .';host=' . $server, 

				$user, 

				$password, 

				array(

					PDO::ATTR_EMULATE_PREPARES => false, //true->parameter replacement occurs occurs in the PDO library, false-> occurs in MySQL server

					PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION 

					//ERRMODE_SILENT->will not show any PDO related message

					//ERRMODE_EXCEPTION->tonnes of error message..will interrupt application & roll back transactions

					//ERRMODE_WARNING->throws PHP Warnings w/o interrupting flow of application

					)

				);

			$conn->exec("SET NAMES 'utf8' COLLATE 'utf8_general_ci'");

		} catch (PDOException $e) {

			echo 'Connection failed: ' . $e->getMessage();

		}

		$this->db=$conn;

	}

	

	public function query($query) {	
		
		return $this->db->query($query);

	}

	

	public function prepare($query) {	
		//_ETXT($query);
		return $this->db->prepare($query);

	}

	

	public function rowCount() {	

		return $this->db->rowCount();

	}

	

	

	public function lastInsertId() {	

		return $this->db->lastInsertId();

	}

	

	public function close() {	

		return $this->db=null;

	}

}//DB



?>