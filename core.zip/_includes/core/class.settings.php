<?php
class Settings{
	public $_REST=false;
	public $_HOST;
	public $_HOST_DIR;
	public $_GLOBAL_SSL=false;
	public $_MAIL_TEST=array();
	public $_MAIL_ADMIN=array();
	public $_MAIL=array();
	
/*	public function __construct($setArr) {
		$this->REST=isset($setArr["REST"]) ? $setArr["REST"] : false;
		$this->_HOST=isset($setArr["_HOST"]) ?  $setArr["_HOST"] : $_SERVER['HTTP_HOST'];
		$this->_HOST_DIR=isset($setArr["_HOST"]) ?  "//".$setArr["_HOST"]."/" : "//".$_SERVER['HTTP_HOST']."/";
	}*/	
}
?>