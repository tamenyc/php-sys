<?php
class Widget{
	
	//Widget Driver
	//check for method call and call relevant method
	public function Widget_Driver ( $WID_ID ){

		if(!is_array( $WID_ID )) {
			$this->Widget_Call( $WID_ID );
				
		} else {
			foreach( $WID_ID as $ID ){
				$this->Widget_Call( $ID );				
			}
		}
		
	}
	//Excutes widget method calls
	private function Widget_Call ( $WID_ID ){
		
		$func = $this->Datalogic->WID[ $WID_ID ]['_type'];
		if( method_exists($this,$func) ){ 
			//_echo($func);
			$this->$func( $WID_ID );
		} else {
			echo '<b>Warning:</b> Method '.$func.' does not exist.';
		}		
		
	}

	//Stats Display Styled Widget
	private function Stats_Display( $WID_ID ){
		//echo $WID_ID;
		$wid_data = $this->Datalogic->WID_DATA[ $WID_ID ][0];
		//_print_r($this->Datalogic->WID_DATA);
		$wid_fs = $this->Datalogic->WID[ $WID_ID ];
		//print_r($wid_fs);
		$link_main = $this->Site->_HTTP.$_SERVER['HTTP_HOST'].'/';
		//echo $this->Site->_HTTP;
		//RETRIEVE CELL Data
		$_title = $wid_fs['_title'];
		if(isset( $wid_fs['_link'] )) $_title_link = $link_main.$wid_fs['_link'];
		$_text = $wid_fs['_text'];
		
		$result = $wid_fs['_result'];
		$_num_of_stat_cell = sizeof( $result ); //get no. of stat lines to display		
		$_title_emp = trim($wid_fs['_title_emp']);
		if( isset( $wid_data[ $_title_emp ] ) ) $_title_emp_data = $wid_data[ $_title_emp ];

		//RETRIEVE BS CSS INFO
		//xs (phones), sm (tablets), md (desktops), and lg (larger desktops)
		$bs_w = $this->BootStrapGridMapper( $_num_of_stat_cell );
		$stat_cell_mrkup = 'col-lg-'.$bs_w.' col-md-'.$bs_w.' col-sm-'.$bs_w.' col-xs-6';

		
		if( isset($_title_link) ) {

			//$_title_emp_data = '<a href='.$_title_link.'>'.$_title_emp_data.'</a>';
			//$_title = '<a href='.$_title_link.'>'.$_title.'</a>';
			//$_text = '<a href='.$_title_link.'>'.$_text.'</a>';

			$cell_h_tag = '<a href='.$_title_link.'>';
			$cell_h_tag_c = '<i class="fa fa-chevron-circle-right"></i></a>';

		}
		echo '<div class="_WIG ibox">';
		echo '<div class="ibox-content border-top">';
		//echo '<h2>'.$cell_h_tag.'<span class="emp">',$_title_emp_data,'</span><span><span class="emp">',$_title,'</span>',$_text,'</span>'.$cell_h_tag_c.'</h2>';	
		if(is_numeric($_title_emp_data)){
			//$_title_emp_data = 0;
			if($_title_emp_data>0){
				$displayH2 = '<h2>'.$cell_h_tag.'<span class="emp">'.$_title_emp_data.'</span><span><span class="emp">'.$_title.'</span>'.$_text.'</span>'.$cell_h_tag_c.'</h2>';
			} else {
				//$displayH2 = '<h2>'.$cell_h_tag.'<span class="emp emp_empty">&nbsp;</span><span><span class="emp">No '.$_title.'</span>'.$_text.'</span>'.$cell_h_tag_c.'</h2>';
				$displayH2 = '<h2>'.$cell_h_tag.'<span class="emp">'.$_title_emp_data.'</span><span><span class="emp">'.$_title.'</span>'.$_text.'</span>'.$cell_h_tag_c.'</h2>';
			}
		} else {
			$displayH2 = '<h2>'.$cell_h_tag.'<span class="emp">'.$_title_emp_data.'</span><span><span class="emp">'.$_title.'</span>'.$_text.'</span>'.$cell_h_tag_c.'</h2>';
		}
		//echo '<h2>'.$cell_h_tag.'<span class="emp">',$_title_emp_data,'</span><span><span class="emp">',$_title,'</span>',$_text,'</span>'.$cell_h_tag_c.'</h2>';	
		echo $displayH2;
		echo '<div class="row ibox-content border-none">';
		
		if(is_array($result)){
			foreach( array_keys($result) as $k ){			

				//echo $wid_data $k ];			
				$data =  isset( $wid_data[ $k ] ) ? $wid_data[ $k ] : '';
				$css = isset( $result[ $k ]['_class'] ) ? $result[ $k ]['_class'] : '' ;
				$link = isset( $result[ $k ]['_link'] ) ? $link_main.$result[ $k ]['_link'] : '' ;
				$info = isset( $result[ $k ]['_alias'] ) ? $result[ $k ]['_alias'] : $k ;		

				//print_r( $this->Site->_HTTP.$_SERVER['HTTP_HOST']);			

				$cell_a_tag = '';

				$cell_a_tag_c = '';

				if( $data>0 ) {

					$cell_a_tag = '<a href="'.$link.'">';

					$cell_a_tag_c = '<i class="fa fa-chevron-circle-right"></i></a>';

				} 			

				echo '<div class="_WIG_STAT_CELL ',$css,' ',$stat_cell_mrkup,'">',$cell_a_tag,'<span class="emp">',$data,'</span>',$info,$cell_a_tag_c,'</div>';

			}			
		}
		
		echo '</div>';
		echo '</div>';	
		echo '</div>';		
	}

	//Use this for demo placement content setup..	
	public function WidgetPlaceholder( $WID_ID ){
		
		//ID to identify which placeholder content to display
		$placeholderID = $this->Datalogic->WID[ $WID_ID ]['_placeholderID'];
		require('widget.placeholdercontent.php');


	}	
	private function BootStrapGridMapper( $num_of_col=''){		

		if($num_of_col!=''){

			$number = ceil( 12 / $num_of_col );
		} else {

			$number = false;
		}		
		return $number;

	}
/*****************************************************************************/
//OLD
/*****************************************************************************/
	public function Draw_Widget_Block_TOBEDELETED( $BlockNo ){

		//print_r($this->Datalogic->WID_DATA);
		$wid_data = $this->Datalogic->WID_DATA;
		$wid_block = $this->Datalogic->WID[ $BlockNo ];
		//print_r($this->Datalogic->WID[ $BlockNo ]);		

		//RETRIEVE BLOCK INFO
		if( isset( $wid_block['_wid_grp_type'] )) $_WIG_ATTENTION = $wid_block['_wid_grp_type']=='attention' ? '_WIG_ATTENTION' : '';
		if( isset( $wid_block['_num_of_col'] )) $_num_of_col = $wid_block['_num_of_col'];
		if( isset( $wid_block['_cell'] )) $_num_of_cell = sizeof($wid_block['_cell']);
		if( isset( $wid_block['_title'] )) $block_title = $wid_block['_title'];		
		

		if( isset($block_title) ) {
			if( trim($block_title)!='' ) echo '<h2>',$block_title,'</h2>';
		}
		echo '<div class="_WIG_GRP ',$_WIG_ATTENTION,' row">';
		for( $i=0; $i<$_num_of_cell; $i++ ){
			$this->Draw_Widget_Cell( $wid_block['_cell'][$i], $wid_data[$i][0],$_num_of_col  );
		}		
		echo '</div>';
	}

	public function Get_Widget_Content_TOBEDELETED( $BlockNo, $CellNo ){

		//print_r($this->Datalogic->WID_DATA);
		$wid_data = $this->Datalogic->WID_DATA;
		$wid_block = $this->Datalogic->WID[ $BlockNo ];
		//print_r($this->Datalogic->WID[ $BlockNo ]);
		

		//RETRIEVE BLOCK INFO
		if( isset( $wid_block['_wid_grp_type'] )) $_WIG_ATTENTION = $wid_block['_wid_grp_type']=='attention' ? '_WIG_ATTENTION' : '';
		if( isset( $wid_block['_num_of_col'] )) $_num_of_col = $wid_block['_num_of_col'];
		if( isset( $wid_block['_cell'] )) $_num_of_cell = sizeof($wid_block['_cell']);
		if( isset( $wid_block['_title'] )) $block_title = $wid_block['_title'];				

		$this->Draw_Widget_Cell( $wid_block['_cell'][$CellNo], $wid_data[$CellNo][0],$_num_of_col  );
	}
	
	public function Draw_Widget_Cell_TOBEDELETED( $cell_data, $wid_data ,$num_of_col='' ){		

		//print_r($wid_data);
		//print_r($cell_data);
		//DETERMINES WHICH CELL TO DRAW

		$func= 'WID_Type_'.$cell_data['_type'];
		if(method_exists($this, $func)){

			$this->$func( $cell_data, $wid_data ,$num_of_col);

		}

	}

	


	

	private function WID_Type_count_stats_TOBEDELETED( $cell_data, $wid_data ,$num_of_col=''){		

		$link_main = $this->Site->_HTTP.$_SERVER['HTTP_HOST'].'/';

		//RETRIEVE CELL Data
		$_title = $cell_data['_title'];
		if(isset( $cell_data['_link'] )) $_title_link = $link_main.$cell_data['_link'];
		$_text = $cell_data['_text'];
		

		$_num_of_stat_cell = sizeof( $cell_data['_result'] );
		$result = $cell_data['_result'];
		$_title_emp = trim($cell_data['_title_emp']);
		if( isset( $wid_data[ $_title_emp ] ) ) $_title_emp_data = $wid_data[ $_title_emp ];

		//RETRIEVE BS CSS INFO
		//xs (phones), sm (tablets), md (desktops), and lg (larger desktops)
		$col_num = $this->BootStrapGridMapper( $num_of_col );
		//$col_mrkup = $col_num !== false ? 'col-md-'.$col_num : '';
		$stat_cell_mrkup = 'col-md-'.$this->BootStrapGridMapper( $_num_of_stat_cell );
		
		if( isset($_title_link) ) {

			//$_title_emp_data = '<a href='.$_title_link.'>'.$_title_emp_data.'</a>';
			//$_title = '<a href='.$_title_link.'>'.$_title.'</a>';
			//$_text = '<a href='.$_title_link.'>'.$_text.'</a>';

			$cell_h_tag = '<a href='.$_title_link.'>';
			$cell_h_tag_c = '<i class="fa fa-chevron-circle-right"></i></a>';

		}
		

		echo '<div class="_WIG '.$col_mrkup.'">';
		echo '<h2>'.$cell_h_tag.'<span class="emp">',$_title_emp_data,'</span><span><span class="emp">',$_title,'</span>',$_text,'</span>'.$cell_h_tag_c.'</h2>';
		
		foreach( array_keys($result) as $k ){			

			//echo $wid_data[ $k ];			
			$data =  isset( $wid_data[ $k ] ) ? $wid_data[ $k ] : '';
			$css = isset( $result[ $k ]['_class'] ) ? $result[ $k ]['_class'] : '' ;
			$link = isset( $result[ $k ]['_link'] ) ? $link_main.$result[ $k ]['_link'] : '' ;
			$info = isset( $result[ $k ]['_alias'] ) ? $result[ $k ]['_alias'] : $k ;		

			//print_r( $this->Site->_HTTP.$_SERVER['HTTP_HOST']);			

			$cell_a_tag = '';

			$cell_a_tag_c = '';

			if( $data>0 ) {

				$cell_a_tag = '<a href="'.$link.'">';

				$cell_a_tag_c = '<i class="fa fa-chevron-circle-right"></i></a>';

			} 			

			echo '<div class="_WIG_STAT_CELL ',$css,' ',$stat_cell_mrkup,'">',$cell_a_tag,'<span class="emp">',$data,'</span>',$info,$cell_a_tag_c,'</div>';

		}		

		echo '</div>';

		

	}
	


}



?>