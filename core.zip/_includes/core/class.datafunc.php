<?php
class DataFunc{
	/*public function _sum($sum_arr){
		
		$total = 0;
		foreach($sum_arr as $x){
			$total = $total + $x;
		}
		
		return $total;
	}*/
}
?>