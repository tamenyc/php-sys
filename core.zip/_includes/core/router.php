<?php
/*********************************/
//WELCOME TO THE ROUTER!!!!!
/*********************************/
_E_TRACE( 'router start:: GET REQUEST: '.$_SERVER['REDIRECT_URL'],true );
//_E_TRACE_AJAX( 'router start:: GET REQUEST: '.$_SERVER['REDIRECT_URL'] );
//Throw error if not enabled as this is needed by BCRYPT
check_CRYPT_BLOWFISH();



/************************************************************************************************************************************/
//THIS ENSURES THE FOLLOWING CODES ARE EXECUTED FOR PHP SCRIPTS AND NOT css,js,img loading by router
/************************************************************************************************************************************/
$_RESTRICTED = array('/resources/');
if( LOAD_AUTOLOAD( $_RESTRICTED ) ) { 
	include_once("autoload.php");

/*********************************/
//Set and block access to restricted folders
/*********************************/
$_RESTRICTED = array('error','_includes','/front/','debug.txt','.htaccess','config.php');
$Site->SET_BLOCK_FOLDERS( $_RESTRICTED );	

//Eg. tamesoft.sg/admin/edit/id=55
//The id is reserved for finding entry to edit. 
//if page is "edit" and no valid "id", go to error page. Note: id displayed on the url has been dechex(id).
//There 2 levels of check. 
//1) Router (below) 
//2) GETID at fs_ini.php
//If for some unforseen reason checking fails at "1" , "2" should be able to stop script execution.
if(strstr($_SERVER['REQUEST_URI'],"edit") && GET_id()=='error'){
	header("Location: error"); 	
}
	
//go to template test page
if(strstr($_SERVER['REQUEST_URI'],"template")){
	include_once($_SERVER['DOCUMENT_ROOT'].$_DIR_MAPP."template/index.php");
	$db->close();
	die();
}


//echo $_SERVER['REQUEST_URI'];
//echo $_SERVER['QUERY_STRING'];
//print_r($_SERVER);
//print_r($_REQUEST);
//print_r($Site->REQUEST_3_ARRAY);
//echo $_REQUEST["_first"];//$Site->REQUEST_1;
//echo $_SERVER['REQUEST_URI'];

//echo '<br>$Site->REQUEST_1 : ',$Site->REQUEST_1;
//echo '<br>$Site->REQUEST_2 : ',$Site->REQUEST_2;
//echo '<br>$Site->REQUEST_3 : ',$Site->REQUEST_3;
//echo $Site->CURRCID;

//print_r($Site->CATEGORY_DEF);
//echo $Folder = $_BIS['Folder'];
//echo $_SERVER['DOCUMENT_ROOT'].$Folder."/_ajax/ajax.php";
//echo $_SERVER['DOCUMENT_ROOT'];

//echo $_SERVER['DOCUMENT_ROOT'].$Site->CATEGORY_DEF[ $Site->CURRCID ]['Src'];

//******************************************************//
// set defaults if any
//******************************************************//
if(isset($_SET_DEFAULT)){
	if( $_SET_DEFAULT!='' && $Site->REQUEST_1=='' ) $Site->REQUEST_1 = $_SET_DEFAULT;
}
//******************************************************//
// Do routing
//******************************************************//

if( $Site->REQUEST_1 == $_ROUTER_NAME['_BIS'] ){	
	//Goes to class.site.php to get the ajax script link
	_E_TRACE( '$Site->REQUEST_1, _BIS is set to '.$_ROUTER_NAME['_BIS'],true );
	_E_TRACE( '$Site->REQUEST_1, _BIS (2) is '.$Site->_GET_ROUTE( $_BIS ),true );
	if(isset( $_BIS )) require_once($Site->_GET_ROUTE( $_BIS )); 
	//EG '/home/tamesoft/public_html/lhn/front/modules/home/invoices/index.php';

} elseif($Site->REQUEST_1==$_ROUTER_NAME['_BIS_ADMIN']){
	//BIS ADMIN
	_E_TRACE( '$Site->REQUEST_1, _BIS_ADMIN is '.$_ROUTER_NAME['_BIS_ADMIN'] );
	if(isset( $_BIS_ADMIN )) require_once($Site->_GET_ROUTE( $_BIS_ADMIN ));	

} elseif($Site->REQUEST_1==$_ROUTER_NAME['_CMS_ADMIN']){
	//CMS ADMIN
	_E_TRACE( '$Site->REQUEST_1,_CMS_ADMIN  is '.$_ROUTER_NAME['_CMS_ADMIN'] );
	if(isset( $_CMS_ADMIN )) require_once($Site->_GET_ROUTE( $_CMS_ADMIN ));	
	
} elseif($_CMS_CAT_MANUAL_DEFINE) {
	//CMS


	$Site->_SET_CATEGORY_PARAMS('_CMS');

	if(isset($Site->CATEGORY_DEF[ $Site->CURRCID ]['Src']) && strstr($_SERVER['REQUEST_URI'],"_ajax")===false ){ 
		//AUTO LOAD SRC FILES
		_E_TRACE( 'include '.$_SERVER['DOCUMENT_ROOT'].$Site->CATEGORY_DEF[ $Site->CURRCID ]['Src'] );
		if(!@include_once( $_SERVER['DOCUMENT_ROOT'].$Site->CATEGORY_DEF[ $Site->CURRCID ]['Src'] )) header("Location: error"); 
			
	} elseif(strstr($_SERVER['REQUEST_URI'],"_ajax")){  
		//ajax definition goes here. Ajax link are not defined in category, hence it would come here.
		if(!@include_once($_SERVER['DOCUMENT_ROOT']."/cms/_ajax/ajax.php")) header("Location: error"); 
					
	}
	
} 

//close db

/*Memory*/
//if(!strstr($_SERVER['REQUEST_URI'],"_ajax")) $Site->MemoryData();
$db->close();
} // if( LOAD_AUTOLOAD( $_RESTRICTED ) ) 
?>
