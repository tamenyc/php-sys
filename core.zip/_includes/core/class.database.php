<?php
//PDO BASED
class Database{
	public $db;
	public $Settings;
	public $test_query; //use this for printing out query statement
	public $DB_QUERY_DIA=false;
	public $DB_QUERY_COUNT_DIA= false;
	public $DB_INSERT_DIA=false;
	public $DB_UPDATE_DIA=false;
	public $DB_DELETE_DIA=false;
	
	public $DB_DELETE_SIM=false;
	public $DB_INSERT_SIM=false;
	public $DB_UPDATE_SIM=false; 
	
	/*public function __construct(DB $db, Settings $Settings){
		$this->db=$db;
		$this->Settings=$Settings;
	}*/
	
	public function core_count( $table, $strFilter, $parameters ){
		
		$count = false;
		
		//FORM QUERY
		$strFilterP = trim($strFilter)!="" ? " WHERE ".$strFilter : '' ; 
		$query ="SELECT COUNT(*) AS TOTAL FROM ".$table.$strFilterP;
		
		if(!$this->Settings->_REST){			
			//USE LOCAL DB
			$result=$this->db->prepare( $query  ); //$query = "SELECT lastname,name FROM MyGuests WHERE id=?";
			if($this->DB_QUERY_COUNT_DIA){
				_echo ('<h1>core_count</h1>'.$query);
				_print_r($parameters);
				_echo('<br>');
			}
			CHECK_POST($parameters);
			//echo $query;
			if($parameters==''){ 
				//echo 'parameters.core_count()=blank';
				$result->execute(); //used for cases like SELECT * FROM table;
			}else{
				//echo 'parameters.core_count()= !blank';
				$result->execute($parameters); //param = array(1); -->'1' is value of id
			}
			
			$resultArr=$result->fetchAll(PDO::FETCH_ASSOC);
			
			
		} else {
			
			//USE REST
			echo "USE REST CONNECTION";
			$resultArr="";
		}
		
		//_print_r( $resultArr );
		if(isset( $resultArr )) $count = $resultArr[0]['TOTAL'];
		if($this->DB_QUERY_COUNT_DIA) _echo('$count='.$count.'<br><br>');
		return $count;
	}
	private function is_empty_param( $parameters ){
		$valString ='';
		if(isset($parameters) && is_array($parameters)){
			foreach( $parameters as $value ){ $value = (string)$value;
				$valString = $valString.trim($value);
			}
		}
		$parameters = $valString=='' ? '' : $parameters;
		
		return $parameters;
	}
	public function core_query($query,$parameters='',$queryParam=""){
		//echo $query;
		//USE LOCAL DB
		
		if(!$this->Settings->_REST){
			$result=$this->db->prepare($query); //$query = "SELECT lastname,name FROM MyGuests WHERE id=?";
			if($this->DB_QUERY_DIA){
				_echo ('<h3>'.$query.'</h3>');
				_print_r($parameters);
			}
			
			//$parameters =array('%31%27%20%4F%52%20%27%31%27%3D%27%31','%31%27%20%4F%52%20%27%31%27%3D%27%31');
			//_ETXT($parameters);
			CHECK_POST($parameters);		
			
			if($parameters==''){
				$result->execute(); //used for cases like SELECT * FROM table;

			}else{
				$result->execute($parameters); //param = array(1); -->'1' is value of id

			}
			
			$resultArr=$result->fetchAll(PDO::FETCH_ASSOC);

		} else {
		//USE REST
			echo "USE REST CONNECTION";
			$resultArr="";
		}
		
		//print_r($resultArr);
		return $resultArr;
		
	}
	
	public function  core_query_insert($table, $params ,$colnames, $colvalues) {
		//USE LOCAL DB

		$lastID=false;
		
		if(!$this->Settings->_REST){
			$query='INSERT INTO '.$table.' ('.$colnames.') VALUES ('.$colvalues.')';
			//EG:
			/*INSERT INTO vehicle 
				(VehicleTypeID, VehicleNum, IUNum, CashCardNum, AddedBy, AddedByID, AddedDate, Status, StatusDate, AddedByType) 
				VALUES 
				(:VehicleTypeID, :VehicleNum, :IUNum, :CashCardNum, :AddedBy, :AddedByID, NOW(), :Status, NOW(), :AddedByType)
				
				In params array, no need to define time.
			*/
			if($this->DB_INSERT_DIA) echo $query;
			if($this->DB_INSERT_SIM===false){
				$result=$this->db->prepare($query);
				$result->execute($params);
				$lastID=$this->db->lastInsertId();
			}
		
		} else {
		//USE REST
			echo "USE REST CONNECTION";
			$count=0;
		}
		
		return $lastID;
		/*
		$statement = $link->prepare("INSERT INTO testtable(name, lastname, age)
			VALUES(:fname, :sname, :age)");
		$statement->execute(array(
			"fname" => "Bob",
			"sname" => "Desaunois",
			"age" => "18"
		));

		Prepared statements are used to sanitize your input, and to do that you can use :foo without any single quotes within the SQL to bind variables, and then in the execute() function you pass in an array of the variables you defined in the SQL statement.

		You may also use ? instead of :foo and then pass in an array of just the values to input like so;

		$statement = $link->prepare("INSERT INTO testtable(name, lastname, age)
			VALUES(?, ?, ?)");

		$statement->execute(array("Bob", "Desaunois", "18"));

		Both ways have their advantages and disadvantages.
		
		*/
	}
	
	public function core_delete($query,$parameters,$queryParam=""){
		CHECK_POST($parameters);
		//USE LOCAL DB
		if(!$this->Settings->_REST){
			$result=$this->db->prepare($query);
			$result->execute($parameters);
			$count=$result->rowCount();
		} else {
		//USE REST
			echo "USE REST CONNECTION";
			$count=0;
		}
		
		//return no. of rows affected
		return $count;
		
	}


	public function core_update($query){
		//USE LOCAL DB
		if(!$this->Settings->_REST){
			$result=$this->db->prepare($query); //$query = "UPDATE MyGuests SET lastname='Doe' WHERE id=2";
			$result->execute();
			$count=$result->rowCount();
			if($count>0) {
				//echo "<h1>DONE</h1>";
			} else {
				//echo "<h1>Not modified</h1>";
			}
		} else {
		//USE REST
			echo "USE REST CONNECTION";
			$count="";
		}
		
		//print_r($resultArr);
		return $count;
	}
	
	public function core_query_update($table,$column_values,$keyID,$input_id){
		
		$count = false;		
		$query = 'UPDATE '.$table.' SET '.$column_values.' WHERE '.$keyID.'="'.$input_id.'"';	//_E_TRACE($query,true);	
		if($this->DB_UPDATE_DIA) echo '<hr>',$query,'<hr>';
		if($this->DB_UPDATE_SIM===false) $count = $this->core_update($query);
		return $count;
	}
	
	public function  core_query_select($table, $params, $colnames="*", $strFilter="", $strGroup="", $strOrder="", $strULimit="", $strLLimit="") {
		
		if(trim($strFilter)!="") {
			$strFilter="WHERE ".$strFilter;
		}

		if($strGroup!="") $strGroup="GROUP BY ".$strGroup;
		if($strOrder!="") $strOrder="ORDER BY ".$strOrder;
		if($strULimit!="" && strLLimit!="") $strLimit="LIMIT ".$strLLimit.", ".$strULimit;
		
		$query="SELECT ".$colnames." FROM ".$table." ".$strFilter." ".$strGroup." ".$strOrder." ".$strLimit; //_echo ($query.'---<br>');
		//$this->test_query=$query;
		//print_r($params);
		$params = $this->is_empty_param($params); //check empty entries
		$row=$this->core_query($query,$params);
		//print_r($row);
		$row  = $this->_removeslashes($row);
		return $row;
	}
	
	public function  core_query_delete($table, $params,  $strFilter="") {
		
		if($strFilter!="") {
			$strFilter="WHERE ".$strFilter;
		}
		
		$query="DELETE FROM ".$table." ".$strFilter;
		if($this->DB_DELETE_DIA) _echo ('<h3>'.$query.'</h3>');
		//$this->test_query=$query;
		
		if($this->DB_DELETE_SIM===false) { 
			$count=$this->core_delete($query,$params);
		} else {
			PRINT_WARNING_MSG_TEMPLATE('DB_DELETE_SIM is set to true. DELETE query will not execute.');
		}
		//return no. of rows affected
		return $count;
	}
	
	//Returns array of stated columns from query results $row
	public function core_query_get_result( $needle, $row ){
		//_E_TRACE('database.core_query_get_result'.$needle, true);
		//_E_TRACE($row, true);
		$result = false;
		
		foreach(array_keys($row) as $index ){
			if(isset($row[$index][$needle])){
				$result[] = $row[$index][$needle];
			}
		}	
		
		//_E_TRACE('result='.$result,true);
		return $result; 		
	}
	public function core_query_get_result_unit_test(){
		
		$test_inputs[0][0] = 'allocated';
		$test_inputs[0][1] = array(
			0=>array(
				'allocated'=>'5',
			),
			1=>array(
				'allocated'=>'900',
			)
		);
		
		foreach(array_keys($test_inputs) as $index ){
			$result = $this->core_query_get_result( $test_inputs[$index][0], $test_inputs[$index][1] );
			print_r($result);
		}
	}
	private function _removeslashes($row){
		if(is_array($row)){
			foreach(array_keys($row) as $i){
				if(is_array($row[$i])){
					foreach(array_keys($row[$i]) as $c){
						$row[$i][$c] = stripslashes($row[$i][$c]);
						$row[$i][$c] = str_replace("\\","",$row[$i][$c]);					
					}
				}

			}
			
		}

		return $row;
	}
}
/*$query="SELECT ProductID, Status FROM product WHERE ProductID>? AND Status=? LIMIT 0,5";
$parameters = array(1222,"Active");
$products_arr=$Database->db_query($query,$parameters);
print_r($products_arr);*/
?>
