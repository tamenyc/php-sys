<?php

require('password_compat.php');
//Security func calls
CHECK_POST($_POST);
CHECK_GET();
//$_POST = clean_POST_GET($_POST); //print_r($_POST); //Obseleted
$_DATA_LABEL_GRPS['general'] = DATA_LABEL_GRPS_GENERAL();

function CHECK_POST($arr){
	if(!empty($arr)){
		foreach(array_keys($arr) as $key){
			//echo $key;
			if(is_array($arr[$key])){
				CHECK_POST($arr[$key]);
			} else {
				//echo $arr[$key],'<br>';
				_STRING_CHECK_STD ( $arr[$key], $key );
			}
		}		
	}

}

//CHECK ALL GET
function CHECK_GET(){
	//print_r($this->Site->REQUEST_PARAMS_P);
	foreach( array_keys($_GET) as $k ){
		//echo $k;
		if($_GET[$k]==''){
			unset($_GET[$k]); //echo $k;
		} else {
			
			if(is_array($_GET[$k])) {
				foreach(array_keys($_GET[$k]) as $key){
					_STRING_CHECK_STD( $_GET[$key] , $key );
				}
			} else{
				_STRING_CHECK_STD( $_GET[$k] , $k );
			}
		}
		
	}

}
//CHECK
//regex ref: http://regexlib.com/CheatSheet.aspx?AspxAutoDetectCookieSupport=1
//https://regex101.com/
//https://www.functions-online.com/preg_match.html
function _STRING_CHECK_STD( $string , $key=''  ){

	//if ( preg_match('/(!|>|<|\'|&#|;)+/', $string ,$matches )){
	if ( preg_match('/(!|>|<|&#|;)+/', $string ,$matches )){
		//_ETXT($string.'-->illegal');
		//check for illegal chars
		//print_r($_SERVER);
		$matches = json_encode($matches);
		$Msg = '_STRING_CHECK_STD [ string: '.$key.'='.$string.' ] [ Illegal String Matches : '.$matches.' ] [ Request URI : '.$_SERVER['REQUEST_URI'].' ] [ Remote Addr: '.$_SERVER['REMOTE_ADDR'].' ] [ User: '.$_SESSION['Name'].' ] [ Http user agent : '.$_SERVER['HTTP_USER_AGENT'].' ] [ Server port : '.$_SERVER['SERVER_PORT'].' ]';
		error_log( $Msg,0 );
		//_ETXT('check');
		//$arr[$key]='';

		//header('Location: error');
		/*
		if(empty($_POST['AJAXID'])){
			die( 'Error : Illegal string....' );
		} else {
			$_POST['AJAX_ERROR']= 'Error : Illegal string....';
			
		}*/
		//die( 'Error : Illegal string....' );	

	} 
}

function clean_POST_GET($array){
	//Clean all POST/GET
	//1) extract, makesafe then put back..
	  foreach(array_keys($array) as $values){
		  if(is_array($array[$values])){
			  $array[$values] = clean_POST_GET($array[$values]);
		  } else {
		  	$array[$values]=makesafe_string($array[$values]);
		  }
	  };
	  return $array;	
}
function makesafe_uri($unsafe){

	$arr=explode("?",$unsafe);
	$unsafe=$arr[1];
	
	//String the string into value and key string
	parse_str($unsafe,$arr_unsafe);
	$arr_keys=array_keys($arr_unsafe);
	
	//Make every parameter safe individually
	$i=0;
	$strString="";
	$strSep="";
	while(isset($arr_unsafe[$arr_keys[$i]])){
		$arr_unsafe[$arr_keys[$i]]=makesafe_string($arr_unsafe[$arr_keys[$i]]);
		$strString.=$strSep.$arr_keys[$i]."=".urlencode($arr_unsafe[$arr_keys[$i]]);
		$strSep="&";
		$i++;
	}//while
	
	implode("&",$arr_unsafe);

	//Return first matching number
	return $arr[0]."?".$strString;
}//makesafe_uri

function makesafe_number($unsafe){
	preg_match_all('!\d+!', $unsafe, $matches);

	//Return first matching number
	return trim(strip_tags($matches[0][0]));
}//makesafe_number

function makesafe_string($unsafe){
	//Strip tags
	$unsafe=str_replace("{","",$unsafe);
	$unsafe=str_replace("}","",$unsafe);
	$unsafe=str_replace("<","",$unsafe);
	$unsafe=str_replace(">","",$unsafe);

	
	if(get_magic_quotes_gpc()){
		$safe = stripslashes( htmlspecialchars(htmlentities(strip_tags(trim($unsafe)))) );
	} else {
		$safe = addslashes( htmlspecialchars(htmlentities(strip_tags(trim($unsafe)))) );
	}
	
	return $safe;
}//makesafe_string

function cleanInputs($data){
	  $clean_input = array();
	  if(is_array($data)){
		  foreach($data as $k => $v){
			  $clean_input[$k] = $this->cleanInputs($v);
		  }
	  }else{
		  if(get_magic_quotes_gpc()){
			  $data = trim(stripslashes($data));
		  }
		  $data = strip_tags($data);
		  $clean_input = trim($data);
	  }
	  return $clean_input;
  }


function human_date($date){
	/* Convert mysql date to user friendly date */
	if($date!="" && $date!=0){
		sscanf($date,"%d-%d-%d %d:%d:%d",$year,$month,$day,$hour,$minutes,$seconds);
		
		return date("d M Y", mktime($hour, $minutes, $seconds, $month, $day, $year));
	}
	else{
		return "";
	}	
}
function human_time($date){
	/* Convert mysql date to user friendly date */
	if($date!="" && $date!=0){
		sscanf($date,"%d-%d-%d %d:%d:%d",$year,$month,$day,$hour,$minutes,$seconds);
		
		return date("H:i a", mktime($hour, $minutes, $seconds, $month, $day, $year));
	}
	else{
		return "";
	}	
}
function unfriendly_datetime_to_timestamp($datetime){
	/* Convert mysql date/time to user friendly date/time */ 
	sscanf($datetime,"%d-%d-%d %d:%d:%d",$year,$month,$day,$hour,$minutes,$seconds);
	if(checkdate($month,$day,$year)){
		return mktime($hour,$minutes,$seconds,$month,$day,$year);
	}
	else{
		return "";
	}
}
function get_orientation($PhotoFile){
	//Get image information
	$info=getimagesize(realpath($PhotoFile));
	
	//Calculate the size of the image
	if($info[0]<$info[1]){
		return "Portrait";
	}
	elseif($info[0]>$info[1]){
		return "Landscape";
	}
	elseif($info[0]==$info[1]){
		return "Square";
	}
}

function str_html($value) {
	//$value=str_replace(array("\r\n", "\r", "\n"), htmlentities("<br>"), htmlentities($value, ENT_COMPAT, 'UTF-8'));	
	$value=str_replace(array("\r\n", "\r", "\n"), htmlentities(" "), htmlentities($value, ENT_COMPAT, 'UTF-8'));
	$value=str_replace(array("&ndash;", "&rdquo;"), "-" , $value);
	
    return str_replace(array("&rsquo;", "&rdquo;", "&ldquo;", "&lsquo;"), "'" , $value);	
}

//Add slashes to all elements in array as well
function addslashesextended(&$arr_r)
{
    if(is_array($arr_r))
    {
        foreach ($arr_r as $val)
            is_array($val) ? addslashesextended($val):$val=addslashes($val);
        unset($val);
    }
    else
        $arr_r=addslashes($arr_r);
}

//Add slashes to all GET, POST if nesscary
function do_gpc_slash(){
	if(!get_magic_quotes_gpc()){
		//if GPC magic quotes is off addslashes for post and get
		
		$keys=array_keys($_POST);
		foreach($keys as $key){
			addslashesextended($_POST[$key]);
		}
		
		$keys=array_keys($_GET);
		foreach($keys as $key){
			addslashesextended($_GET[$key]);
		}		
	}
}//do_gpc_slash

function shorten_text($text,$min){
	
	/*$arr[]=".";
	$arr[]=",";
	$arr[]=" ";
	$arr[]="&nbsp;";	
	$i=0;
	
	//print("$min>=".strlen($text));
	
	if($min>=strlen($text)){
		$text=$text;
	}
	else{
		while(true){
			if(($pos=strpos($text,$arr[$i],$min))){
				if(($pos-$min)<($min/10)){
					break;
				}			
			}
			if($pos==0){
				break;
			}		
			$i++;
		}
		
		if($pos!=0){		
			$text1=substr($text,0,$pos);
		}
	}*/
	
	if(strlen($text)>$min){
		//$text=substr(str_replace("&nbsp;","",strip_tags($text)),0,$min)." ...";
		$text= mb_strcut(str_replace("&nbsp;","",strip_tags($text)), 0, $min, 'UTF-8')." ...";
	}
	
	return $text;
}//shorten text


function CSV2Array($content, $delim = ';', $encl = '"', $optional = 1) {
   if ($content[strlen($content)-1]!="r" && $content[strlen($content)-1]!="n")
       $content .= "rn";

   $reg = '/(('.$encl.')'.($optional?'?(?(2)':'(').
           '[^'.$encl.']*'.$encl.'|[^'.$delim.'rn]*))('.$delim.
           '|rn)/smi';

   preg_match_all($reg, $content, $treffer);
   $linecount = 0;

   for ($i = 0; $i<=count($treffer[3]);$i++) {
       $liste[$linecount][] = str_replace("$encl","",$treffer[1][$i]);
       if ($treffer[3][$i] != $delim)
           $linecount++;
   }
   unset($linecount);
   unset($i);
   unset($reg);
   unset($content);
   unset($delim);
   unset($encl);
   unset($optional);
   unset($treffer);

   return $liste;
}

function csv_to_array($csv){
	return CSV2Array($csv,",","'",2);
}

function array_to_csv($arr){
	if(is_array($arr)){
		return "'" . implode("','", $arr) . "'";
	}
	else{
		return "";
	}
}

//Return the number of seconds between two dates
function unfriendly_date_diff($date1,$date2,$interval){
	if($date2!="" && $date2!=0 && $date2!="" && $date2!=0){
		sscanf($date1,"%d-%d-%d",$year,$month,$day);
		$ts1=mktime(0,0,0,$month,$day,$year);
		
		sscanf($date2,"%d-%d-%d",$year,$month,$day);
		$ts2=mktime(0,0,0,$month,$day,$year);
		
		$sec=$ts1-$ts2;
		$sec=abs($sec);
	
		switch($interval){
			case "d":
				$result=(int)($sec/86400);
				break;
			case "m":
				$result=(int)($sec/2592000);
				break;			
			case "y":
				$result=(int)($sec/31104000);
				break;			
			default:
				$result=$sec;
				break;
		}
		return $result;
	}
	return "";
}
function friendly_date($date){
	/* Convert mysql date to user friendly date */
	if($date!="" && $date!=0){
		sscanf($date,"%d-%d-%d",$year,$month,$day);
		return "$day/$month/$year";
	}
}
function unfriendly_date($date){
	/* Convert user friendly date to mysql date*/
	if($date!="" && $date!=0){	
		sscanf($date,"%d/%d/%d",$day,$month,$year);
		return "$year-$month-$day";
	}
}
function friendly_datetime($datetime){
	/* Convert mysql date/time to user friendly date/time */ 
	sscanf($datetime,"%d-%d-%d %d:%d:%d",$year,$month,$day,$hour,$minutes,$seconds);
	if(checkdate($month,$day,$year)){
		return sprintf("%d/%d/%d %02d:%02d:%02d",$day,$month,$year,$hour,$minutes,$seconds);
	}
	else{
		return "";
	}
}
function unfriendly_datetime($datetime){
	/* Convert user friendly date/time to mysql date/time */
	sscanf($datetime,"%d/%d/%d %d:%d:%d",$day,$month,$year,$hour,$minutes,$seconds);
	if(checkdate($month,$day,$year)){
		return sprintf("%d-%d-%d %d:%d:%d",$year,$month,$day,$hour,$minutes,$seconds);
	}
	else{
		return "";
	}
}
function unfriendly_time($datetime){
	/* Convert user friendly date/time to mysql date/time */
	sscanf($datetime,"%d/%d/%d %d:%d:%d",$day,$month,$year,$hour,$minutes,$seconds);
	if(checkdate($month,$day,$year)){
		return sprintf("%d:%d",$hour,$minutes);
	}
	else{
		return "";
	}
}
//Convert a UNIX timestamp into mysql datetime format
function mysqli_datetime_format($timestamp){
	$datetime=getdate($timestamp);
	return "$datetime[year]-$datetime[mon]-$datetime[mday] $datetime[hours]:$datetime[minutes]:$datetime[seconds]";
}

///////////////////////////////////////////////////////////
// mysqli_to_unix_time: converts a 14-digit MySQL //////////
// timestamp to a UNIX timestamp //////////////////////////
///////////////////////////////////////////////////////////
/*
 $datetime should be a number in the format yyyymmddhhmmss
 Returns the date's UNIX timestamp
*/
function mysqli_to_unix_time($datetime){
	// Convert to string so we can reliably parse it
	settype($datetime, 'string');
	
	// Break the number up into its components (yyyymmddhhmmss)
	// storing results in the array matches
	//eregi('(....)(..)(..)(..)(..)(..)',$datetime,$matches);
	preg_match('(....)(..)(..)(..)(..)(..)/i',$datetime,$matches);

	// Pop the first element off the matches array.  The first
	// element is not a match, but the original string, which
	// we don't want.
	array_shift ($matches);
	
	// Transfer the values in $matches into labeled variables
	foreach(array('year','month','day','hour','minute','second') as $var) {
		$$var = array_shift($matches);
	}
	
	return mktime($hour,$minute,$second,$month,$day,$year);
}

/* Taken from: http://www.phpbuddy.com/article.php?id=25 */
function random_password(){
	//set the random id length 
	$random_id_length = 10; 
	//generate a random id encrypt it and store it in $rnd_id 
	$rnd_id = crypt(uniqid(rand(),1)); 
	//to remove any slashes that might have come 
	$rnd_id = strip_tags(stripslashes($rnd_id)); 
	//Removing any . or / and reversing the string 
	$rnd_id = str_replace(".","",$rnd_id); 
	$rnd_id = strrev(str_replace("/","",$rnd_id)); 
	//finally I take the first 10 characters from the $rnd_id 
	$rnd_id = substr($rnd_id,0,$random_id_length); 
	
	return $rnd_id; 
}

function receive_file($File,$Dir)
{
	if(is_uploaded_file($_FILES[$File]["tmp_name"])){	
		
		//Figure out source file name
		$Filename=$_FILES[$File]["name"];
		$Filename_t=$Filename;
		while(file_exists($Dir."/".$Filename_t)){
			$Filename_t=rand(0,999).$Filename;
		}//while
		$Filename=stripslashes($Filename_t);
		
		copy($_FILES[$File]["tmp_name"],$Dir.$Filename);
		chmod($Dir.$Filename,0666);
		
		return $Filename;
	}
	else{
		return "Error";		
	}
}//receive file

//Taken from:
// http://sg.php.net/manual/en/function.file-exists.php
// Fabrizio (staff at bibivu dot com)
// 22-Dec-2005 10:11 
function url_exists($url) {
   $a_url = parse_url($url);
   if (!isset($a_url['port'])) $a_url['port'] = 80;
   $errno = 0;
   $errstr = '';
   $timeout = 30;
   if(isset($a_url['host']) && $a_url['host']!=gethostbyname($a_url['host'])){
	   $fid = fsockopen($a_url['host'], $a_url['port'], $errno, $errstr, $timeout);
	   if (!$fid) return false;
	   $page = isset($a_url['path'])  ?$a_url['path']:'';
	   $page .= isset($a_url['query'])?'?'.$a_url['query']:'';
	   fputs($fid, 'HEAD '.$page.' HTTP/1.0'."\r\n".'Host: '.$a_url['host']."\r\n\r\n");
	   $head = fread($fid, 4096);
	   fclose($fid);
	   return preg_match('#^HTTP/.*\s+[200|302]+\s#i', $head);
   } else {
	   return false;
   }
}

function print_picture_width($PhotoFile,$MaxWidth=450){
	//if(url_exists($PhotoFile)){
		//Get the size of the image
		$info=getimagesize($PhotoFile);
				
		//Calculate the size of the image
		if($info[0]>$MaxWidth){
			$width=$MaxWidth;
		}
		else{
			$width=$info[0];
		}
		print("<img border=\"0\"src=\"".htmlentities($PhotoFile)."\" width=\"$width\" class=\"PicFrame\">");
	//}
	//else{
	//	print("$PhotoFile does not exists");
	//}
} //print_picture

function print_picture($PhotoFile,$destlongerside=220){
	if(file_exists($PhotoFile)){
		//Get the size of the image
		$info=getimagesize(rawurldecode($PhotoFile));
		
		//Find out which side of the source image is longer
		$longerside=($info[0]>$info[1]?$info[0]:$info[1]);							
		
		//Calculate the size of the image
		if($longerside!=0 && $longerside!=""){
			//Find the conversion ratio
			$ratio=$destlongerside/$longerside;
			//Find the width and height of dest
			$img_width=$ratio*$info[0];
			$img_height=$ratio*$info[1];
			//Display image
			print("<img border=\"0\"src=\"/$PhotoFile\" width=\"$img_width\" height=\"$img_height\">");
		}
		else{
			print("No Photo $PhotoFile");
		}
	}
} //print_picture

function is_image($file){
	$i=strpos($file,".",0);	
	if(strtoupper(substr($file,$i+1,4))=="JPG" || strtoupper(substr($file,$i+1,4))=="GIF"){
		return true;
	}
	else{
		return false;
	}
} //is_image



function print_hidden_fields_from_gfilter($strGFilter,$arrExclude){	
	parse_str($strGFilter,$get_arr);
	foreach($get_arr as $arr_key => $arr_value){
		if(!in_array($arr_key,$arrExclude)){
			if(is_array($arr_value)){
				$i=0;
				while(isset($arr_value[$i])){
					print("<input name=\"".$arr_key."[]\" type=\"hidden\" id=\"".$arr_key."[]\" value=\"".$arr_value[$i]."\">");
					$i++;
				}//while
			}
			else{
				print("<input name=\"".$arr_key."\" type=\"hidden\" id=\"".$arr_key."\" value=\"".$arr_value."\">");		
			}
		}
	} //For
}//hidden_fields_from_gfilter

function convert($size)
{
    $unit=array('b','kb','mb','gb','tb','pb');
    return @round($size/pow(1024,($i=floor(log($size,1024)))),2).' '.$unit[$i];
}

function odd_even_check($num){
	if($num&1) {
		//echo 'The number is odd.';
		$r= 'odd';
	} else {
		//echo 'The number is even.';
		$r= 'even';
	}
	
	return $r;
}

function EPS_e($u, $encode=true){
	
	if($encode===true) { 
		$esp=mt_rand(1,4);
		$offset=mt_rand(1,15);
		$offset2=mt_rand(1,9);
		
		$random[1]='hjt3JKgtTD34fdKS68WQxZS1Goiz09hY1xzMawx1cASA20';
		$random[2]='u7TGdf3JKgtTD34ZSSaqzMLS1Goiz09hY1xR1rxxc7SA20';
		$random[3]='8qzMLS1Goiv1t7TGdf3JKgtTD34fdLs3vQcOicsCjLA84S';
		$random[4]='S1Goiz09hYTGv1t7TGdfS1Goizv3JKgtTD3468WQxZSc7S';
		
		//echo $u[0];
		$len= strlen($u);
		
		$encoded='';
		for($i=0;$i<$len;$i++){
			$encoded=$encoded.$u[$i].$random[$esp][$i+$offset];
		}
		$fake='.'.$random[$esp][$offset2+$esp].$random[$esp][$len+$offset+$esp].$random[$esp][$len+$offset];
		//echo $encoded.$fake.'.'.$esp;
	
		$num=$encoded.$fake.'.'.$esp;
	} else {
		$num=$u;
	}
	//echo $num;
	return $num;
}

function EPS_d($d){

	$random[1]='hjt3JKgtTD34fdKS68WQxZS1Goiz09hY1xzMawx1cASA20';
	$random[2]='u7TGdf3JKgtTD34ZSSaqzMLS1Goiz09hY1xR1rxxc7SA20';
	$random[3]='8qzMLS1Goiv1t7TGdf3JKgtTD34fdLs3vQcOicsCjLA84S';
	$random[4]='S1Goiz09hYTGv1t7TGdfS1Goizv3JKgtTD3468WQxZSc7S';
	
	$len = strlen($d);
	$last_pos = $len -1 ;
	$random[ $d[ $last_pos ] ];
	
	$de='';
	for($i=0;$i<$len;$i++){
		//echo '<br>';
		if( odd_even_check($i)=='even' ) $de=$de.$d[ $i ];
	}
	
	$len2 = strlen($de);
	$len2 = $len2-3;
	$de2='';
	for($i=0;$i<$len2;$i++){
		$de2=$de2.$de[$i];
	}
	return $de2;
}
function EPe2($u){
	
	$arr=explode('.',$u);
	
	//REPLACE arr[2] with hexadecimal version
	$sep='';
	$v='';
	foreach(array_keys($arr) as $k){
		
		if($k==2){
			$v=$v.$sep.dechex($arr[2]);
		} else {
			$v=$v.$sep.$arr[$k];
		}
		
		$sep='.';
	}
	//echo $v;

	$r='*abcdefghijklmnopqrstuv.1234567890';
	$r_len=strlen($r);
	$rt='';
	for($i=1; $i<$r_len ; $i++){ 
		$rt[ $r[$i] ]=$i;
	}
	//print_r($rt);
	
	//CONVERT TO ENCODING
	$len=strlen($v);
	$c=0;
	for($i=1 ; $i<$len ; $i++){
		$c = $c + $rt[ $v[$i] ];
	}
	$c=dechex($c);
	
	//Total sum
	//echo $c;
	
	$con='';
	$strSep='';
	for($i=1 ; $i<=$len ; $i++){
		$con=$con.$strSep.$rt[ $v[$i] ];
		$strSep='.';
	}
	
	
	return $con.$c;
}

//TO FIND OUT CLASSES DEFINED THUS FAR...
function GET_STANDARD_CLASSES( $PHP_PREDEF_CLASSES_LAST_KEY){
	//print_r(get_declared_classes());
	$all_classes = get_declared_classes();
	for($i=0;$i<=$PHP_PREDEF_CLASSES_LAST_KEY; $i++){
		unset( $all_classes[$i] );
	}
	print_r( $all_classes );
}

//CORECLASSLOADER
function CoreClassLoader( $class ){
    //Converts to lower case
	$class=strtolower($class);
	global $_DIR_MAPP;
	//REMEMBER TO UPDATE THIS PORTION ACCORDINGLY TO THE NEW CLASS
	$coreClass=array('settings','site','database','databasefunc','htmlform','htmlcomponents','datalogic','formchecks','widget','login','sys_ajax');
	$templateClass=array('emptytemplate','coremaintemplate','corelogintemplate');
	

	//CORE
	if(in_array($class,$coreClass)) {
		//echo $_SERVER['DOCUMENT_ROOT'].$_DIR_MAPP.'_includes/core/class.'.$class.'.php';
		require $_SERVER['DOCUMENT_ROOT'].$_DIR_MAPP.'_includes/core/class.'.$class.'.php'; 
	}
	
	//Load core template class
	if(in_array($class,$templateClass)){
		require $_SERVER['DOCUMENT_ROOT'].$_DIR_MAPP.'templates/class.'.$class. '.php';
	}	
	
}
//Custom session handler
function session_start_ini(){
	session_start(); //print_r($_SESSION);	
	//session_regenerate_id();//force session id change
	define( "_ACODE",session_id() ); //script access code
}
//CONTROL SCRIPT
function use_script(){
	if( constant("_ACODE")==session_id() ){
		return true;
	} else {
		echo 'Access denied.';
		return false;
	}
}
//Check if CRYPT_BLOWFISH is installed
function check_CRYPT_BLOWFISH(){
	if (defined("CRYPT_BLOWFISH") && CRYPT_BLOWFISH) {
		//echo "CRYPT_BLOWFISH is enabled!";
		//throw new Exception("CRYPT_BLOWFISH is enabled!");
	} else {
	//echo "CRYPT_BLOWFISH is not available";
		throw new Exception("CRYPT_BLOWFISH is not avaliable!");
	}
}

//Filter GET request that do not need to call autoload
function LOAD_AUTOLOAD( $_RESTRICTED ){
	$load = true;
	foreach( $_RESTRICTED as $restricted ){
		if(strstr($_SERVER['REQUEST_URI'], $restricted)) $load = false;
	}	
	
	return $load;
}

function RETRIEVE_VALUE( $input, $default ){	
	return $value = isset( $input) ? $input != '' ?  $input : $default : $default ;
	
}
function RETRIEVE_APPEND_VALUE( $input, $default , $strSep=' ' ){	
	return $value = isset( $input) ? $input != '' ?  $input.$strSep.$default : $default : $default ;
	
}
function FORM_BS_WIDTH ( $width ){		
	
	$widthCSS ='';
	if($width!=''){
		$widthCSS = ' col-md-'.$width.' col-lg-'.$width.' col-sm-'.$width.' ';
	}
	
	return $widthCSS;
}
function ERROR_MSG_CONTROL(){
	global $_ERROR_MSG_CONTROL_IDS;
	$Allowed_ID = !empty( $_ERROR_MSG_CONTROL_IDS ) ? $_ERROR_MSG_CONTROL_IDS : array(); //setting test accounts.
	
	$result = in_array( $_SESSION['LoginAccountID'], $Allowed_ID ) ? true : false;
	
	return $result;
}
function _echo( $msg ){
	if( ERROR_MSG_CONTROL() ){
		echo $msg;
	}
}
function _print_r( $arr ){
	if( ERROR_MSG_CONTROL() ){
		print_r( $arr );
	}
}
function PRINT_DIA_TEMPLATE( $title,$results ){

	if( ERROR_MSG_CONTROL() ){
		echo '<h2>'.$title.'</h2>';
		print_r($results);
		echo '<br>******************************************<br>';		
	}

}
function PRINT_WARNING_MSG_TEMPLATE( $msg,$more_details='' ){
	echo '<br><b>Warning: '.$msg.' </b><br>';
	print_r($more_details);
	echo '<hr>';
}
function SYS_UNIT_TEST_MSG( $status ){
	if($status=='Pass'){
		return "<span class=' label'>Pass</span>";
	} elseif($status=='Fail'){
		return "<span class=' label label-danger'>Fail</span>";
	}
}
function VALUE_EXIST( $value ){
	$exist = false;
	if(isset($value)){
		if(trim($value)!='') $exist = true;
	}
	return $exist;
}
function ARRAY_EXIST( $Arr ){
	$exist = false;
	if(isset($Arr)){
		if(is_array($Arr)){
			if( count($Arr)>0) $exist = true;
		}
	}
	return $exist;
}

//Print trace message on error log.
//set TraceThis to true during func call to specific messages not specified by $_ERRROR_TRACE at config.php
function _E_TRACE( $msg, $TraceThis=false ){
	global $_ERRROR_TRACE;
	if( isset($_ERRROR_TRACE) ){
		if( $_ERRROR_TRACE===true ){
			if( $_ERRROR_TRACE ) _ETXT( $msg ,'_E_TRACE::');
		} 
	}
	if( $TraceThis ){
		_ETXT( $msg ,'_E_TRACE::');
	}
	
}
function _E_TRACE_AJAX( $msg, $TraceThis=false ){
	global $_ERRROR_TRACE_AJAX;
	if( isset($_ERRROR_TRACE_AJAX) ){
		if( $_ERRROR_TRACE_AJAX===true ){
			if( $_ERRROR_TRACE_AJAX ) _ETXT( $msg, 'AJAX TRACE::');
		} 
	}
	
	if( $TraceThis ){
		_ETXT( $msg, 'AJAX TRACE::');
	} 	
	
}
function _ETXT($txt,$title=''){		

	if( is_array($txt) ){
		$txt = json_encode($txt);
	}

	$myfile = fopen("debug.txt", "a") or die("Unable to open file!");
	fwrite($myfile, "[ ".$title."] [ ".date('Y-m-d H:i:s')." ] ".$txt."\n");
	fclose($myfile);

}
function GET_id(){
	
	if( isset($_GET['id'])){		
		$GETID = base64_decode($_GET['id']);		
		$GETID =  !is_numeric($GETID) ?  'error' : $GETID ;
	} else {
		$GETID = '';
	}
	return $GETID;	
}
function GETID( $CURRURL ){
	$GETID='';
	$GETID = GET_id(); //get and process $_GET[id]	
	return $GETID;
}
function DATA_LABEL_GRPS_GENERAL (){
	$_DATA_LABEL_GRPS['general'] = array(
		'Active'=>'label label-primary',
		'Inactive'=>'label label-danger',
		'Deleted'=>'label',
		'Approved'=>'label label-primary',
		'Rejected'=>'label label-danger',
		'Overdue'=>'label label-danger',
		'Outstanding'=>'label label-danger',
		'Pending'=>'label label-warning-light',
	);
	return $_DATA_LABEL_GRPS;
}
//CREDITS: http://php.net/manual/en/function.base64-encode.php
function base64url_encode($data) {
  return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
}
//CREDITS: http://php.net/manual/en/function.base64-encode.php
function base64url_decode($data) {
  return base64_decode(str_pad(strtr($data, '-_', '+/'), strlen($data) % 4, '=', STR_PAD_RIGHT));
} 

function CURL_POST( $url, $data ,$type ='array'){
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,$url);
	curl_setopt($ch, CURLOPT_POST, 1); 
	curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
	//curl_setopt($ch, CURLOPT_HEADER, 1);
	
	//http://unitstep.net/blog/2009/05/05/using-curl-in-php-to-access-https-ssltls-protected-sites/
	//https://curl.haxx.se/libcurl/c/curl_easy_setopt.html
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true); //verify the peer's SSL certificate 
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2); //verify the certificate's name against host 
	//curl_setopt($ch, CURLOPT_CAINFO, getcwd() . "/CAcerts/BuiltinObjectToken-EquifaxSecureCA.crt"); //path to Certificate Authority (CA) bundle 
	
	switch($type){
		case "array":
			//echo http_build_query($data);
			curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
		break;
		
		case "json":

			$Input = json_encode($data);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $Input); 
			curl_setopt($ch, CURLOPT_HTTPHEADER, array(                                                                          
				'Content-Type: application/json',                                                                                
				'Content-Length: ' . strlen($Input))                                                                       
			);
		break;
	}
	
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); //Return response instead of printing.
	
	// receive server response ...
	$server_output = curl_exec ($ch);
	
	if(curl_errno($ch)){
		//echo 'Curl error: ' . curl_error($ch);
		_E_TRACE( 'Curl error: ' . curl_error($ch),true );
		//print_r(curl_getinfo($ch));
		_E_TRACE(curl_getinfo($ch),true);
	}
	
	
	curl_close ($ch);	
	return $server_output;
}
function CURL_POST_JSONRESPONSE( $url, $data ,$type ='array'){
	$result = CURL_POST( $url, $data ,$type);
	//result = file_get_contents($url); //print_r($result);
	//$result = '{"status":"success", "FAKED":"YEAH"}';
	return $result;
}
function IS_ASSOC($arr)
{
    return array_keys($arr) !== range(0, count($arr) - 1);
}

function BEFORE_NOW($Date){
	$bool = false;
	
	$DateInput = new DateTime($Date); 
	//$tz = $DateInput->getTimezone(); echo $tz->getName(); echo $DateInput->getTimestamp();
	$DateToday = new DateTime();
	//$tz = $DateToday->getTimezone(); echo $tz->getName(); echo $DateToday->getTimestamp(); echo $DateToday->format('Y-m-d H:i:s');
	$interval = $DateToday->diff($DateInput);
	$day_diff =  $interval->format('%a');
	$sign = $interval->format('%R');
		
	if($day_diff>0 && $sign=='-'){
		$bool = true;
	}	
	return $bool;
}
function BEFORE_UNIT_TEST(){
	//Y-m-d
	$testDates=array(
		array('2016-03-28','2015-03-28','before'),
		array('2017-03-28','2015-03-28','before'),
		array('2017-03-28','2019-03-28','after'),
		array('2017-03-28','2019-03-28','after'),
		array('2017-02-28','2019-03-28','after'),
	);
	echo '<hr><h1>BEFORE($RefDate, $TestDate) UNIT_TEST</h1>';
	foreach(array_keys($testDates) as $i){
		$RefDate = $testDates[$i][0];
		$TestDate = $testDates[$i][1];
		$result =  BEFORE($RefDate, $TestDate) ? 'before' : 'after';
		echo '<h3>'. $TestDate.' '.$result.' '.$RefDate.'</h3>';
		echo $final = $result==$testDates[$i][2] ? '' : 'ERROR!';
	}
}
function IN_DATE_RANGE_UNIT_TEST(){
	//Y-m-d
	$testDates=array(
		array('2015-03-28','2015-06-28','2015-04-28','2015-05-28','in'),
		array('2015-03-28','2015-06-28','2015-04-28','2015-09-28','out'),
		array('2015-03-28','2015-06-28','2015-01-28','2015-05-28','out'),
		array('2015-03-28','2015-06-28','2015-01-28','2019-05-28','out'),
		array('2015-03-28','2015-06-28','2015-03-28','2015-06-28','in'),
		array('2015-03-28','2015-06-28','2015-01-28','2015-06-28','out'),
		array('2015-03-28','2015-06-28','2015-03-28','2016-06-28','out'),
		array('2016-03-28','2015-06-28','2015-03-28','2016-06-28','out'),
	);
	echo '<hr><h1>IN_DATE_RANGE() UNIT_TEST</h1>';
	foreach(array_keys($testDates) as $i){

		$RefDateStart = $testDates[$i][0];
		$RefDateEnd = $testDates[$i][1];
		$TestDateStart = $testDates[$i][2];
		$TestDateEnd = $testDates[$i][3];
		$chkresult = IN_DATE_RANGE($RefDateStart, $RefDateEnd, $TestDateStart, $TestDateEnd) ; 
		$result =  $chkresult ? 'in' : 'out';
		echo '<h3>('. $TestDateStart.'-'.$TestDateEnd.') '.$result.' range of '.$RefDateStart.'-'.$RefDateEnd.'</h3>';
		echo $final = $result==$testDates[$i][4] ? '' : 'ERROR!';
		//echo $chkresult['warning'];
	}
}
// Is TestDateStart till TestDateEnd within RefDateStart till RefDateEnd
function IN_DATE_RANGE ($RefDateStart, $RefDateEnd, $TestDateStart, $TestDateEnd ){
	$bool = false;
	$Error = BEFORE($TestDateEnd, $TestDateStart) && BEFORE($RefDateEnd, $RefDateStart) ? false : true;
	
	if($Error===false){
		$test1 = BEFORE($RefDateEnd, $TestDateEnd) || DATE_EQUAL($RefDateEnd, $TestDateEnd) ? true : false ;
		$test2 = !BEFORE($RefDateStart, $TestDateStart)|| DATE_EQUAL($RefDateStart, $TestDateStart) ? true : false ;
		
		if($test1===true && $test2==true) {
			$bool = true;
		} else {
			$bool = false;
			
		}		
	} else {
		//echo 'Warning: Date sequence entry error.';
		if($Error) echo '<strong>Warning at function IN_DATE_RANGE() :</strong> Date sequence error. '.$RefDateStart.'-'.$RefDateEnd.'-'.$TestDateStart.'-'.$TestDateEnd;
	}

	return $bool;
}
function BETWEEN_DATES_UNIT_TEST(){
	//Y-m-d
	$testDates=array(
		array('2014-03-28','2015-03-28','2015-03-28','within'),
		array('2014-03-28','2015-03-28','2014-03-28','within'),
		array('2014-03-28','2015-03-28','2017-03-28','out'),
		array('2014-03-28','2015-03-28','2010-03-28','out'),
		array('2016-03-28','2015-03-28','2010-03-28','out'),
	);
	echo '<hr><h1>BETWEEN_DATES($RefDate, $TestDate) UNIT_TEST</h1>';
	foreach(array_keys($testDates) as $i){
		$RefDate = $testDates[$i][0];
		$RefDateEnd = $testDates[$i][1];
		$TestDate = $testDates[$i][2];
		$result =  BETWEEN_DATES($RefDate, $RefDateEnd, $TestDate) ? 'within' : 'out';
		echo '<h3>'. $TestDate.' '.$result.' '.$RefDate.' and '.$RefDateEnd.'</h3>';
		echo $final = $result==$testDates[$i][3] ? '' : 'ERROR!';
	}
}
// Is TestDate between RefDateStart and RefDateEnd
function BETWEEN_DATES ($RefDateStart, $RefDateEnd, $TestDateStart ){
	
	$Error = BEFORE($RefDateEnd, $RefDateStart) ? false : true;

	$test1 = BEFORE($RefDateEnd, $TestDateStart) || DATE_EQUAL($RefDateEnd, $TestDateStart) ? true : false ;
	$test2 = !BEFORE($RefDateStart, $TestDateStart)|| DATE_EQUAL($RefDateStart, $TestDateStart) ? true : false ;
	
	if($test1===true && $test2===true && $Error===false) {
		$bool = true;
	} else {
		$bool = false;
		if($Error) echo '<strong>Warning at function BETWEEN_DATES() :</strong>'.$RefDateStart.' should be earlier than '.$RefDateEnd;
	}
	return $bool;
}
function ADD_DAYS_UNIT_TEST(){
	$testDates=array(
		array('2016-08-09','1','2016-08-10'),
		array('2016-08-31','1','2016-09-01'),
	);
	echo '<hr><h1>ADD_DAYS() UNIT_TEST</h1>';
	foreach(array_keys($testDates) as $i){
		$date = $testDates[$i][0];
		$days = $testDates[$i][1];
		$correct_ans = $testDates[$i][2];
		
		$dateNew = ADD_DAYS($date,$days);
		echo '<h3>'. $date.' '.$days.' :: '.$dateNew.' vs '.$correct_ans.'</h3>';
		echo $final = $dateNew == $correct_ans ? '' : 'ERROR!';
		
		
	}
}
function ADD_DAYS($date,$days){
	$dateNew='';
	if($date!='' && $days!=''){
		$dateObj = new DateTime($date);
		$dateObj->add(new DateInterval('P'.$days.'D'));
		$dateNew = $dateObj->format('Y-m-d');
		
	} else {
		echo '<strong>Warning at function ADD_DAYS() :</strong> Missing argv 1 and argv 2';
	}
	
	return $dateNew;
	/*http://php.net/manual/en/dateinterval.construct.php*/
	/*
	The format starts with the letter P, for "period." Each duration period is represented by an integer value followed by a period designator. 
	If the duration contains time elements, that portion of the specification is preceded by the letter T. 
	examples. Two days is P2D. Two seconds is PT2S. Six years and five minutes is P6YT5M. 
	
	Do not use this technique for add months..it fails on calculate correctly if Feb is involved again.
	
	*/
}
function GIRO_NEXT_DEDUCTION_DATE($date,$mths){ //$mths is number of months from $date
	return GIRO_DEDUCTION_DATE( ADD_MTHS($date,$mths));
}
function GIRO_DEDUCTION_DATE($date){
	$dateObj = new DateTime($date);
	$dateNew = $dateObj->format('Y-m-20');
	return $dateNew;
}
function DATE_FORMAT_jS_M_Y($date){ 
	//eg: 20th Nov 2017 j=20, S=th, M=Nov,Y=2016
	$dateObj = new DateTime($date);
	return $date = $dateObj->format('jS M Y');	
}
function DATE_FORMAT_j_M_Y($date){ 
	//eg: 20 Nov 2017 j=20, M=Nov,Y=2016
	$dateObj = new DateTime($date);
	return $date = $dateObj->format('j M Y');	
}
function ADD_MTHS($date,$mths){
	//$date='2016-02-01'; $mths=1;
	$dateNew='';
	if($date!='' && $mths!=''){
		
		$dateObj = new DateTime($date);

		$date_Y = $dateObj->format('Y');
		$date_d = $dateObj->format('j');
		
		$dateMth = $dateObj->format('n');
		
		if($dateMth==12){
			$newMth = $mths;
			$date_Y = $date_Y + 1;
		} else {
			$newMth = $dateMth + $mths;
		}
				
		//$tObj = new DateTime('2017-02-01');
		//echo $tObj->format('n');
		

		//check if $date_d exist in $newMth
		//get last day of given month and check if it is within the range.
		
		$date_last_day_mth = LAST_DAY_OF_MTH( $date_Y, $newMth );
		$date_d = $date_d <= $date_last_day_mth ? $date_d : $date_last_day_mth;
		$dateNew=$date_Y.'-'.$newMth.'-'.$date_d;
		$dateNEWObj = new DateTime($dateNew);
		$dateNew = $dateNEWObj->format('Y-m-d');

		
	} else {
		echo '<strong>Warning at function ADD_MTHS() :</strong> Missing argv 1 and argv 2';
	}
	
	return $dateNew;
}
function LAST_DAY_OF_MTH($year,$mth){
	$testdate = $year.'-'.$mth;
	$testObj = new DateTime($testdate);
	$date_last_day_mth = $testObj->format('t'); //t-->last day of given mth
	return $date_last_day_mth;
}
function DAY_DIFF_UNIT_TEST (){
	$test=array(
		array('2016-03-28','2015-03-28','before'),
		array('2017-03-28','2015-03-28','before'),
		array('2017-03-28','2019-03-28','after'),
		array('2017-03-28','2019-03-28','after'),
		array('2017-02-28','2019-03-28','after'),
	);
	
	foreach(array_keys($test) as $i){
		$d1 = $test[$i][0];
		$d2 = $test[$i][1];
		$expectedoutcome = $test[$i][2];
		$result =  DAY_DIFF($d1, $d2);
		echo '<h3>DAY_DIFF('. $d1.','.$d2.') '.$result.'</h3>';
	}
}
//Number of days different between D1 and D2 (D1-D2)
function DAY_DIFF ($D1, $D2){
	
	//Create TestDate date obj
	$D1Obj = new DateTime($D1);
	$D2Obj = new DateTime($D2);

	
	$interval = $D2Obj->diff($D1Obj);
	return $interval->format('%R%a');
	
}
function IS_EXPIRYING_OR_OVERDUE_BY_DAYS_UNIT_TEST(){
	$test=array(
		array('2016-03-28','2015-03-28','30','none'),
		array('2017-03-28','2015-03-28','30','none'),
		array('2017-03-28','2017-03-28','30','expiring'),
		array('2017-03-28','2019-03-28','30','overdue'),
		array('2017-02-28','2017-02-01','30','expiring'),
		array('2016-08-31','2016-09-14','30','expiring'),
	);
	
	foreach(array_keys($test) as $i){
		$d1 = $test[$i][0];
		$d2 = $test[$i][1];
		$days_to_expiry = $test[$i][2];
		$expectedoutcome = $test[$i][3];
		$result =  IS_EXPIRYING_OR_OVERDUE_BY_DAYS($d1, $d2, $days_to_expiry);
		echo '<h3>IS_EXPIRYING_OR_OVERDUE_BY_DAYS('. $d1.','.$d2.' ,'.$days_to_expiry.') '.$result.'</h3>';
	}	
}
function IS_EXPIRYING_OR_OVERDUE_BY_DAYS($refdate,$needledate, $days_to_expiry){
	
	//echo '<h1>'.$refdate.'-'.$needledate.'</h1>';
	
	$day_diff = DAY_DIFF ($refdate, $needledate);
	$status = 'none';
	if($day_diff>=0 && abs($day_diff)<$days_to_expiry){
		$status = 'expiring';
	}
	if($day_diff<0){
		$status = 'overdue';
	}
	return $status;
	
}
// is TestDate before RefDate?
function BEFORE($RefDate, $TestDate){
	$bool = false;
	
	$TestDateobj = new DateTime($TestDate); 
	//$tz = $DateInput->getTimezone(); echo $tz->getName(); echo $DateInput->getTimestamp();
	$RefDateobj = new DateTime($RefDate);
	//$tz = $DateToday->getTimezone(); echo $tz->getName(); echo $DateToday->getTimestamp(); echo $DateToday->format('Y-m-d H:i:s');
	$interval = $RefDateobj->diff($TestDateobj);
	$day_diff =  $interval->format('%a');
	$sign = $interval->format('%R');
		
	if($day_diff>0 && $sign=='-'){
		$bool = true;
	}	
	return $bool;
}
// is TestDate = RefDate?
function DATE_EQUAL($RefDate, $TestDate){
	$bool = false;
	
	$TestDateobj = new DateTime($TestDate); 
	//$tz = $DateInput->getTimezone(); echo $tz->getName(); echo $DateInput->getTimestamp();
	$RefDateobj = new DateTime($RefDate);
	//$tz = $DateToday->getTimezone(); echo $tz->getName(); echo $DateToday->getTimestamp(); echo $DateToday->format('Y-m-d H:i:s');
	$interval = $RefDateobj->diff($TestDateobj);
	$day_diff =  $interval->format('%a');
	$sign = $interval->format('%R');
		
	if($day_diff==0 && $sign=='+'){
		$bool = true;
	}	
	return $bool;
}
function IS_UNSIGNED_NUMBERS($num){
	$bool = false;
	$bool = preg_match('/(^\\d+$)/',$num) ? true : false ;
	
	return $bool;
}
function HAVE_SIGNS($var){
	$bool = false;
	$bool = preg_match('/[\\+\\-]/',$var) ? true : false ;
	
	return $bool;
}
function IS_STRLEN_EQUAL($str,$length){
	//echo $str.'--'.strlen($str).'<br>';
	return strlen($str)==$length ? true : false ;
}
function ARRAY_HAS_ARRAYKEY($arr){
	//print_r($arr);
	$key = trim(key($arr));
	
	if($key=='') {
		//echo 'no array key';
		$result = false;
	} else {
		$result = true;
	}
	
	return $result;
}
function json_clean_up($Input){
	$Input= stripslashes($Input);
	$Input= str_replace("\"{\"","{\"",$Input);
	$Input= str_replace("}\"","}",$Input);
	return $Input;
}//json_clean_up

?>