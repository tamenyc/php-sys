<?php 
$GETID = GETID($Site->CURRURL); // For "edit" url, there must be a compulsory and valid id='numeric' && $GETID!='error'
if(use_script() && $GETID!='error') {

	//***************************************
	//KEY PARAM SETUP
	//***************************************
	$guide=array('QS','FS','FOPS','FFlow','SEARCH','FSORT','WID','FS_LAYOUT');
	
	foreach($guide as $k){
			if(isset($k)) $Datalogic->$k=$$k;
		}	
		if(isset($Datalogic->QS) || isset($Datalogic->_D) ) $Datalogic->HaveData=true;
		
		if(isset( $Datalogic->FOPS )){
			foreach(array_keys($Datalogic->FOPS) as $FSID){
				foreach(array_keys($Datalogic->FOPS[$FSID]) as $c){
					//if(array_key_exists('_showdata' ,$Datalogic->FOPS[$FSID][$c] )) $Datalogic->ShowData=true;
				}
			}			
		}
	
	//Grid Generator
	if(isset( $GRID )) $Layout->GRID = $GRID;
	
	//***************************************
	//NON DB related Data Initialisations
	//For DB related data initialisations, do it in Datalogic
	//***************************************
	
	//***************************************
	//PAGINATION
	//***************************************
	//$Layout->HtmlComponents->_PAGINATION_INI( $HTML_COMPOS ); 
	if($Layout) $Layout->HtmlComponents->HTML_COMPOS = $HTML_COMPOS; 
	
	
	//***************************************
	//FORM
	//***************************************	
	
	$Form_param=array('FS_LAYOUT', 'FS_TOOLBAR');
	foreach($Form_param as $k){
			//echo $k;
			if(isset($k)) $Form->$k=$$k;
	}
	//print_r($Form->FS_LAYOUT);
	//$Form->FS_LAYOUT=$FS_LAYOUT;

}
?>