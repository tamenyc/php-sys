<?php
/*************************************/
/* SITE CLASS
	framework uri schematics:
	http://host/_first/_second/_third(...../lang) where /lang is always stored as the last item in _third
	
	Note: URL must end off with '/' 
	
	REQUEST_1=_first
	REQUEST_2=_second
	REQUEST_3=_third................/lang
	
*/
/*************************************/
class Site{
	//$_REQUEST
	public $REQUEST_1;
	public $REQUEST_2;
	public $REQUEST_3;
	public $REQUEST_3_ARRAY=array();
	public $REQUEST_PARAMS; //processed into array
	public $REQUEST_PARAMS_P; //processed into array with standard query removed eg Submit=true...
	public $REQUEST_PARAMS_STRING; //full string
	public $REQUEST_PARAMS_STRING_P; //internal query param removed
	public $SITE_LANG;
	public $SETTINGS;
	public $_LOCAL_SSL = false;
	public $_HTTP='http://';
	public $CURRTREE;
	public $CURRURL;
	public $CURRCID;
	
	public $SUBDOMAIN;
	
	public $SYS_TYPE; // _CMS, _BIS, _CMS_ADMIN, _BIS_ADMIN 
	public $_CMS_STATIC;
	public $_CMS_ADMIN_STATIC;
	public $_BIS_STATIC;
	public $_BIS_ADMIN_STATIC;
	
	//Diagnostic*/
	public $CATEGORY_DIA=false;
	public $_FORMCURRURL_DIA=false;
	public $_GET_URL_DIA=false;
	
	
	//CATEGORY REQUIRED
	public $CATEGORY_DEF;
	public $Database;
	
	public function __construct($Settings, Database $Database){
		
		$this->REQUEST_1=isset($_REQUEST["_first"])? $_REQUEST["_first"] : "";
		$this->REQUEST_2=isset($_REQUEST["_second"])? $_REQUEST["_second"] : "";
		$this->REQUEST_3=isset($_REQUEST["_third"])? $_REQUEST["_third"] : "";
		$this->REQUEST_3_ARRAY=isset($_REQUEST["_third"])? explode("/",$_REQUEST["_third"]): array();
		$this->REQUEST_PARAMS=$this->_SET_REQUEST_PARAMS(); // returns internal query
		$this->REQUEST_PARAMS_P=$this->_SET_REQUEST_PARAMS( 'Processed'); // does not return internal query eg: Submit= true
		
		$this->SITE_LANG=$this->getlang();
		$this->SETTINGS=$Settings;
		$this->port_433();
		
		$this->SUBDOMAIN = $this->_GET_SUBDOMAIN();
		
		$this->Database=$Database;
	}
		
	
	public function ERROR_REDIRECT(){
		header("Location: //".$_SERVER['HTTP_HOST']."/error.php");
		die();
	}	
	
	//Set and block access to restricted folders
	function SET_BLOCK_FOLDERS( $_RESTRICTED ){
		foreach( $_RESTRICTED as $restricted ){
			if(strstr($_SERVER['REQUEST_URI'], $restricted)){ 
			
				/*
				if(!@include_once($_SERVER['DOCUMENT_ROOT']."/error.php") ) {
					echo 'Oops..Local error page missing. Please create your error page.<br>';
					if(!@include_once($_SERVER['DOCUMENT_ROOT'].$_DIR_MAPP."error.php") ) echo 'Oops..Error page missing';
				} */
				
				$this->Database->db->close(); 
				$this->ERROR_REDIRECT();
				//die();
				
			} 	
		}	
	}
	
	public function _GET_SUBDOMAIN(){
		$arr = array_shift((explode(".",$_SERVER['HTTP_HOST'])));
		//print_r( $arr );
		return $arr;
	}
		
	public function _SET_CATEGORY_PARAMS($Type){
		
		if($Type=='' || !isset($Type)){
			echo 'Fatal Error: Undefined _SYS_TYPE at _SET_CATEGORY_PARAMS($Type)';
		} else{
			$this->SYS_TYPE=$Type;
			_E_TRACE( 'site._SET_CATEGORY_PARAMS().SYS_TYPE=.'.$this->SYS_TYPE );
			_E_TRACE_AJAX( 'site._SET_CATEGORY_PARAMS().SYS_TYPE=.'.$this->SYS_TYPE );
		}
		_E_TRACE_AJAX('$this->CATEGORY_DEF=$this->_GET_CATEGORY_DEF()');
		$this->CATEGORY_DEF=$this->_GET_CATEGORY_DEF();	
		//_echo('CATEGORY_DEF--->');
		//_print_r($this->CATEGORY_DEF);
		if(strstr($_SERVER['REQUEST_URI'],"_ajax")===false){
			//CATEGORY RELATED OPS
			
			
			if($this->CATEGORY_DEF!==false){
				//Form curr category Tree
				$this->CURRTREE = $this->_FORM_CURR_TREE();	//_print_r($this->CURRTREE);
				//SET Current CategoryID
				//_E_TRACE($this->CATEGORY_DEF,true);
				//_E_TRACE($this->CURRTREE,true);
				if(is_array($this->CURRTREE)) $this->CURRCID = end($this->CURRTREE);

				//Form curr url
				$this->CURRURL = $this->_FORMCURRURL();
				_E_TRACE( 'site._SET_CATEGORY_PARAMS()'.$this->CURRURL );
				//TEST
				
				/*echo '<h1>TEST _GET_TREE_PARENTS_ONLY($cid) @class.site</h1>';  
				$test = $this->_GET_TREE_PARENTS_ONLY($_GET['t']);
				print_r($test);
				echo '<hr>';
				*/
			}			
		} else {
			//AJAX
			//echo $this->Site->SYS_TYPE;
			//_print_r($this->CATEGORY_DEF);
			//SET Current CategoryID
			if(!empty($_POST['CURRCID'])) {
				$this->CURRCID = trim($_POST['CURRCID'])!='' && is_numeric($_POST['CURRCID']) ? $_POST['CURRCID'] : end($this->CURRTREE);
			} 
			
			if(!empty($_POST['UrlLink'])) {
				//$this->CURRURL = parse_url($_POST['UrlLink'], PHP_URL_PATH);
			}
		}
	}
	

	
	public function _SET_REQUEST_PARAMS( $Type ='All' ){
		
		$request = false;

		//Process and remove duplicate url query parameters

		$processed = $this->_CLEAN_URL_PARAMS( $_SERVER['REQUEST_URI'] );
		//REFORM url
		$this->REQUEST_PARAMS_STRING = $processed['string']; //http_build_query($request);
		$request = $processed['array'];				
		
		//SET FOR PROCESSED PARAMS
		$request_p = $request;
		unset($request_p['Submit']);
		if(sizeof($request_p)!=0) {
			$this->REQUEST_PARAMS_STRING_P = '?'.http_build_query($request_p);
		} else {
			$request_p = array();
		}

		if($Type=='Processed') $request = $request_p;
		
		//echo '<h1>',$Type,'<br>'; print_r( $request ); echo '</h1>';

		return $request;
	}
	/******************************************************/
	//GET SITE CATEGORY DEFINITIONS
	/******************************************************/
	public function _GET_CATEGORY_DEF($local_type=''){
		if($this->CATEGORY_DIA) echo '<h1>SYS_TYPE = ',$this->SYS_TYPE,'</h1>'; //echo '<h1>SYS_TYPE = ',$this->SYS_TYPE,'</h1>'.$_SERVER['DOCUMENT_ROOT'];
		
		if($local_type==''){
			$sys_type = $this->SYS_TYPE;
		} else {
			$sys_type = $local_type;
		}
		_E_TRACE_AJAX('_GET_CATEGORY_DEF().site sys_type='.$sys_type);
		//_CMS, _BIS, _CMS_ADMIN, _BIS_ADMIN 
		if($sys_type =='_CMS'){
			if($this->_CMS_CAT_MANUAL_DEFINE) {
				include($_SERVER['DOCUMENT_ROOT']."/_includes/custom/site/site.category_cms.php");
			} else {
				//pull from database
			}
			
		} elseif($sys_type == '_BIS'){
			if($this->_BIS_CAT_MANUAL_DEFINE){ 
				include($_SERVER['DOCUMENT_ROOT']."/_includes/custom/site/site.category_bis.php");
			} else {
				//pull from database
			}			
			
			
		} elseif($sys_type == '_CMS_ADMIN'){
			if($this->_CMS_ADMIN_CAT_MANUAL_DEFINE){
				include($_SERVER['DOCUMENT_ROOT']."/_includes/custom/site/site.category_cms_admin.php");
			} else {
				//pull from database
			}
			
		} elseif($sys_type == '_BIS_ADMIN'){ 
			if($this->_BIS_ADMIN_CAT_MANUAL_DEFINE){
				if( include($_SERVER['DOCUMENT_ROOT']."/_includes/custom/site/site.category_bis_admin.php")){
					_E_TRACE_AJAX($_SERVER['DOCUMENT_ROOT']."/_includes/custom/site/site.category_bis_admin.php");
					_E_TRACE_AJAX(json_encode($CategoryDef));					
				}

				//if(!@include( $_SERVER['DOCUMENT_ROOT']."/_includes/custom/site/site.category_bis_admin.php")) throw new Exception("Failed to include 'category_bis_admin.php'");
			} else {
				//pull from database
			}
			
		}
		//_print_r($CategoryDef);
		//_print_r($_POST);

		if(!empty($CategoryDef)){
			$CategoryDefRETURN = $CategoryDef;
			//_print_r($CategoryDef);
		} else {

			$CategoryDefRETURN = false;
			throw new Exception('<b>Warning:</b>Undefined $CategoryDef array. Check config.php for $_CMS_CAT_MANUAL_DEFINE, $_CMS_ADMIN_CAT_MANUAL_DEFINE, $_BIS_CAT_MANUAL_DEFINE, $_BIS_ADMIN_CAT_MANUAL_DEFINE, settings.');
		}
		//print_r($CategoryDefRETURN);
		return $CategoryDefRETURN;
	}
	
	public function _GET_CATEGORY_CHILDREN($Tier=1){	
		$Children = false;

		if( isset( $this->CURRTREE[$Tier])){
			$CategoryID = $this->CURRTREE[$Tier]; 
		}
		//echo '<br>Tier=',$Tier;echo '<br>CategoryID=>',$CategoryID ; echo '<br>CURRTREE=';print_r($this->CURRTREE);
		
		if(isset($this->CATEGORY_DEF[$CategoryID]['Children'])){
			$Children = $this->CATEGORY_DEF[$CategoryID]['Children']; 
			
		}
		//echo 'Children Arr===>';print_r($Children);		
		return $Children;
	}
	



	private $_get_parents_stop=false;
	private $parents;
	public function _GET_TREE_PARENTS_ONLY( $cid ){
		$this->_get_parents_stop=false;
		$this->_FORM_CURR_TREE_get_parents_r( $cid );
		
		if(is_array( $this->parents )){
			$returnTree = array_reverse( $this->parents);
			unset($this->parents);
			return $returnTree;
		} else { 
			return false;
		}
		
	}
	public function _GET_TREE( $cid ){
		//echo $cid;
		$Tree = $this->_GET_TREE_PARENTS_ONLY( $cid );
		//print_r($Tree);
		//echo '-->';print_r($ParentTree); echo '<--';
		if($Tree!==false){
			$Tree[] = $cid;
			return $Tree;
		} else {
			return false;
		}		
		
	}
	//COUNT DIFFERENT BETWEEN CUURTREE AND C_TREE OF A GIVEN CATEGORYID
	public function _COUNT_TREE_DIFF($c_Tree){
		$Curr_Tree=$this->CURRTREE;
		$counter=0;
		foreach(array_keys($c_Tree) as $key){
			if($c_Tree[$key]!=$Curr_Tree[$key]){
				$counter++;
			}
		}
		return $counter;
	}

	
	//GET FONT_AWESOME ICON FOR THE CATEGORY
	public function _GET_ICON ( $CatID ){
		$Icon ='';
		if(isset( $this->CATEGORY_DEF[ $CatID]['Icon'] )){
			$Icon = $this->CATEGORY_DEF[ $CatID]['Icon'];
		} 
		return $Icon;
	}
	
	public function _GET_CATEGORY( $CategoryID='' ){
		
		if($CategoryID=='') $CategoryID = $this->CURRCID;
		
		$Category = '';
		if(isset($this->CATEGORY_DEF[ $CategoryID ]['Category'])){
			$Category = $this->CATEGORY_DEF[ $CategoryID ]['Category'];
		}
		return $Category;
	}
	
	public function _GET_URL_u_tree ( $Tree ){
		$current_url='';

		//if($error===false){
		if( is_array($Tree) ){
			if(isset($this->CATEGORY_DEF[end($Tree)]['Url_name'])){
				//echo $this->CATEGORY_DEF[end($Tree)]['Url_name'];
				reset($Tree);
				if(isset($this->CATEGORY_DEF[end($Tree)]['ToID'])){
					//Re form new Tree according to new ToID
					$Tree = $this->_GET_TREE( $this->CATEGORY_DEF[end($Tree)]['ToID'] );
				}
				reset($Tree);
				$URLstrSep ='';
				$FirstURLstrSep ='';
				
				foreach(array_keys($Tree) as $key){ 
				//echo $key,'-';
				//echo $Tree[$key];
					if(isset($this->CATEGORY_DEF[$Tree[$key]]['Url_name'])){
						
						$current_url = $current_url.$URLstrSep.$this->CATEGORY_DEF[$Tree[$key]]['Url_name'];
						$URLstrSep='/';
						$FirstURLstrSep ='/';
						
						$params = isset($this->CATEGORY_DEF[$Tree[$key]]['Url_params']) ? $this->CATEGORY_DEF[$Tree[$key]]['Url_params'] : '';
						
					} else {
						if($key!=0) echo 'Warning: Missing Url_name declaration in CATEGORY_DEF.';
					}
				}
				$current_url = $FirstURLstrSep.$current_url.'/';
				if($current_url=='//'){ //cms home page case
					$current_url = $this->_HTTP.$_SERVER['HTTP_HOST']; 
				}
				$current_url = str_replace('//','/',$current_url.$params);
			}			
		}		
		//echo $current_url;		
		return $current_url;
	}
	
	//Process $_GET
	//Repeated $GET[k] is removed
	public function _GET_PARAMS ($param_coded_in=''){
		$url_params ='';
		if(!empty($_GET)){
			foreach(array_keys($_GET) as $get_k){
				$sys_arr = array('Submit','_first','_second','_third');
				if(!in_array($get_k,$sys_arr)){
					$get_processed[$get_k] = $_GET[$get_k]; 
					$get_processed_key[] = $get_k;
				}
			}					
		}
		
		if(is_array($param_coded_in)){
			foreach(array_keys( $param_coded_in ) as $i){
				if(!in_array($i,$get_processed_key)){
					$get_processed[$i] = $param_coded_in[$i];
				}
			}
		}
		if(count($get_processed)>0){
			$url_params = '?'.http_build_query($get_processed);	
		}
		
		//echo $url_params;
		return $url_params;
	}
	
	//GET URL FROM TREE OF A GIVEN CATEGORY
	public function _GET_URL( $Tree='',$Category='', $CategoryID='' ){
		//print_r($Tree);
		//Form URL
		$current_url='';
		
		//Tree checks
		//$error = is_array($Tree) ?  false : true ;
		
		//1 ) Get URL using $Tree
		/*************************************************/
		if($Tree!='') $current_url = $this->_GET_URL_u_tree( $Tree );
		
		$GotTree = $Tree=='' ? 'no tree' : 'got tree';
		//_E_TRACE('site._GET_URL.GotTree::'.$GotTree,true);
		
		//2 ) Using Category to directly retrieve link
		/*************************************************/
		if( !is_array($Tree) && $Category!='' ){ 
			foreach( array_keys( $this->CATEGORY_DEF ) as $key ){
				if( $this->CATEGORY_DEF[ $key ]['Category']==$Category ) $current_url = $this->_GET_URL( $this->_GET_TREE( $key ) );
			}
		}
		
		//3 ) Using CategoryID to directly retrieve link
		/*************************************************/
		if( !is_array($Tree) && $CategoryID!='' ){ 
			foreach( array_keys( $this->CATEGORY_DEF ) as $key ){
				if($key==$CategoryID) $current_url = $this->_GET_URL( $this->_GET_TREE( $key ) );
			}
		}		
			
		/*Diagnostic*/
		/*************************************************/
		//_E_TRACE('site._GET_URL::'.$current_url,true);
		if($this->_GET_URL_DIA){
			echo '<h2>URL</h2>';
			echo $current_url;
		} 
		return $current_url = trim($current_url)!='' ? $current_url :  false ;		
	}
	//FORM URL QUERY STRING
	public function _FORM_URL_QUERY_STR( $string='' , $Type='Processed'){
		
		$new_string = false ;
		$strSep ='';
		
		//DETERMINE RETURN INTERNAL PARAMS OR NOT
		$existing_query_string = $Type== 'Processed' ? $this->REQUEST_PARAMS_STRING_P : $this->REQUEST_PARAMS_STRING ;
		
		//IF THERE IS EXISTING QUERY STRING...
		if($existing_query_string !='?') $strSep ='&';
		
		//$new_string = $existing_query_string.$strSep.$string;  
		$cleaned = $this->_CLEAN_URL_PARAMS( $existing_query_string.$strSep.$string );
		
		$new_string = str_replace('?&','?', '?'.$cleaned['string']);
		

		return $new_string;
		
	}
	
	//AUTO FORM URL FROM EXISTING URL
	public function _FORMCURRURL(){		
		//Form URL
		$Tree = $this->CURRTREE;
		
		$TreeMsg = is_array($Tree) ? 'tree is array' : 'tree is not array';
		//_E_TRACE('-------------------------------------------------->'.$TreeMsg,true);
		
		$current_url = $this->_GET_URL( $Tree );
		//_E_TRACE('-------------------------------------------------->'.$current_url,true);
		/*Diagnostic*/
		if($this->_FORMCURRURL_DIA){
			echo '<h2>Formed CurrURL</h2>';
			echo $current_url;
		} 
		return $current_url;
	}	
	
	public function BreadCrumb_Arr( $Tree='' ){
		if(!is_array( $Tree )) $Tree = $this->CURRTREE;
		$BreadCrumb_Arr = array();
		if(is_array($Tree)){
			foreach( $Tree as $CategoryID ){
				//echo $CategoryID;
				if($CategoryID!=0){
					//echo '<br>link=',$this->_GET_URL( '','', $CategoryID );
					//echo '<br>name=',$this->_GET_CATEGORY($CategoryID);
					$BreadCrumb_Arr[ $CategoryID ][ 'Link' ] = $this->_GET_URL( '','', $CategoryID );
					$BreadCrumb_Arr[ $CategoryID ][ 'Category' ] = $this->_GET_CATEGORY($CategoryID);
				}
			}		
		}
		return $BreadCrumb_Arr;
	}
	
	private function _FORM_CURR_TREE_get_parents_r( $cid ){
		
		if($this->_get_parents_stop===false){		

			foreach(array_keys($this->CATEGORY_DEF) as $id){ 
				if( isset($this->CATEGORY_DEF[$id]['Children']) ){ 
					
					//if($cid!=$id) echo "<br>children :$cid VS Parent: $id <br> ";
					//print_r($this->CATEGORY_DEF[$id]['Children']);
					//if($this->_get_parents_stop===false) echo 'false';
					
					
					if($cid!=$id && in_array( $cid , $this->CATEGORY_DEF[$id]['Children']) && $this->_get_parents_stop===false ){ 
						//echo '<br>//',$this->CATEGORY_DEF[$id]['Url_name'],$id,'//<br>';
						$this->parents[] = $id;
						if($id!=0) {					
							$this->_FORM_CURR_TREE_get_parents_r( $id );
						} else {
							$this->_get_parents_stop=true;
						}		
					} 
					
					
				} 				
			}		
		} 

	}
	
	private function _FORM_CURR_TREE_get_parent($Tmp, $ParentID){
		$nParentID = false;
		//echo sizeof($Tmp);
		if(sizeof($Tmp)>1){
			//sort out tree
			foreach($Tmp as $id){ 
				if( in_array( $id, $this->CATEGORY_DEF[ $ParentID ][ 'Children' ]) ){
					$nParentID = $id;
				}
			}			
		} else{
			if(is_array($Tmp)) $nParentID = end($Tmp);
			//echo 'TMP------>'; print_r($Tmp); echo '<br>';
		}
		//echo '<h1>nParentID=',$nParentID,'</h1>'; print_r($Tmp);
		
		return $nParentID;
	}
	private function _GET_SUBTREE($Tree,$func=''){
		$Tmp='';
		
		if($this->CATEGORY_DIA){ echo '<h1>Tree-->'; print_r($Tree); echo 'func=',$func,'</h1>'; }
		if( $func=='REQUEST_2' || $func=='REQUEST_1' ){
			$search_needle = $this->$func;
		} else {
			$search_needle = $func;
		}
		
		foreach(array_keys($this->CATEGORY_DEF) as $id){ 
			if($this->CATEGORY_DIA){ echo $id,'-',$this->CATEGORY_DEF[$id]['Url_name'],'=',$search_needle,'<br>'; }
			if( trim($this->CATEGORY_DEF[$id]['Url_name'])==$search_needle){ 
				
				if($this->CATEGORY_DIA){ echo'<h3>->',$id; echo $search_needle,'</h3>';}
				
				$TreeLocal = $this->_GET_TREE_PARENTS_ONLY($id); //echo '------------->'; print_r($TreeLocal);

				if(is_array($TreeLocal) && implode($Tree)==implode($TreeLocal)) {
					if($this->CATEGORY_DIA) print_r( $TreeLocal );
					if(is_array($TreeLocal)) {
						$ParentArrChk[$id] = $TreeLocal;
						//$Tree_t[$id] = $id;
						$Tmp_t[$id] = $id;
					}
				}
			}
		}

		if($this->CATEGORY_DIA) { echo '<h3>ParentArrChk'; print_r($ParentArrChk); echo '</h3>'; }
		//echo $func; print_r($Tree);
		if(sizeof($ParentArrChk)==1){ 
			$t_id = key($ParentArrChk);
			$Tmp = $ParentArrChk[ $t_id ];
			//print_r($Tree);
			$Tree[] = $t_id;
			
			$result['Tree'] = $Tree;
			$result['Tmp'] = $Tmp;
			
		} elseif(sizeof($ParentArrChk)>1) {
			echo 'Warning: Naming confilct in site.CATEGORY_DEF[$id][Url_name]<br>';
			print_r($ParentArrChk); echo '<br>';
		}
		//echo '<h1>Tree: '; print_r($Tree); echo '</h1>';
		return $result;
	}
	
	//FORMS TREE BASED ON RETRIEVED URL
	public function _FORM_CURR_TREE(){
		
		/*Diagnostic*/
		if($this->CATEGORY_DIA){
			echo '<h2>_REQUEST</h2>';
			print_r($_REQUEST);	
			echo '<h2>REQUEST_1/2/3</h2>';			
			echo 'REQUEST_1=',$this->REQUEST_1;
			echo '<br>REQUEST_2=',$this->REQUEST_2;	
			echo '<br>REQUEST_3=',$this->REQUEST_3;
			echo '<h2>REQUEST_3_ARRAY</h2>';			
			print_r($this->REQUEST_3_ARRAY);
		}	
		
		$Tree=array(0);
		$ParentID = 0;
		//1st Tier 
		//$this->_ROUTER_NAME contains all the url name set in config.php for each system type
		if( in_array($_REQUEST['_first'], $this->_ROUTER_NAME)){
		//if($_REQUEST['_first']!=''){
			
			$Result = $this->_GET_SUBTREE($Tree,'REQUEST_1');
			$Tree = $Result['Tree']; //echo 'xxxxxxxxx------->'; print_r($Tree);
			$Tmp = $Result['Tmp']; //echo 'xxxxxxxxx------->'; print_r($Tmp);
			$ParentID = $this->_FORM_CURR_TREE_get_parent($Tmp , $ParentID); 
			//_E_TRACE(implode(" ",$Tmp),true);
			//echo '<h1>ParentID=',$ParentID,'</h1>'; 
		} else {
			//This is the root Portion
			$Result = $this->_GET_SUBTREE($Tree,'REQUEST_1'); //echo '<h1>RESULT</h1>'; print_r($Result);
			$Tree = $Result['Tree']; //echo '<h1>Tree</h1>';  print_r($Tree);
			$ParentID = end($Tree);
			//echo '<h1>ParentID</h1>',$ParentID;
		}
		
		//2nd Tier 
		if($_REQUEST['_second']!=''){
			$Result = $this->_GET_SUBTREE($Tree,'REQUEST_2');
			$Tree = $Result['Tree']; //echo '-->';print_r($Tree);
			$Tmp = $Result['Tmp'];
			$ParentID = $this->_FORM_CURR_TREE_get_parent($Tmp , $ParentID);
			//echo '<h1>ParentID=',$ParentID,'</h1>'; 
		}
	
		
		//3rrd Tier onwards		
		
		if($_REQUEST['_third']!=''){
			$third_string = $_REQUEST['_third'];
			//echo '<h1>third_string</h1>',$third_string;
			
			if(isset($this->REQUEST_3_ARRAY)){ 
				
				foreach($this->REQUEST_3_ARRAY as $r3_category){			
					if($r3_category!='') $Tree_t3onwards[] = $r3_category; //echo $r3_category;
				}
				//print_r($Tree_t3onwards);
			}			
			if($this->CATEGORY_DIA) { echo '-->'; print_r($Tree_t3onwards); }
			//Form Tree from Tier 3 onwards
			
			$Tmp='';
			if(is_array($Tree_t3onwards)){
				foreach(array_keys($Tree_t3onwards) as $i){
					
					//echo $Tree_t3onwards[$i];
					$Result = $this->_GET_SUBTREE($Tree,$Tree_t3onwards[$i]); 
					$Tree = $Result['Tree']; //echo '-->';print_r($Tree);
					$Tmp = $Result['Tmp'];
					$ParentID = $this->_FORM_CURR_TREE_get_parent($Tmp , $ParentID); 
					//echo '<h1>ParentID=',$ParentID,'</h1>'; 

				}				
			}

		
		}
		
		if($this->CATEGORY_DIA){
			echo '<h2>Tree</h2>';
			print_r($Tree);
		}

		return $Tree;
		
	}
	
	//FORMS REQUEST STRING FROM URL
	public function _FORM_REQ_STRING( $exclude=array() ){
		$request_string = '';
		if(is_array($this->REQUEST_PARAMS)){
			foreach( array_keys($this->REQUEST_PARAMS) as $key ){
				if(in_array($key, $exclude )){
					unset( $this->REQUEST_PARAMS[$key] );
				} else {
					$request_string = $request_string.'&'.$key.'='.$this->REQUEST_PARAMS[$key];
				}
			}
		}
		
		//echo $request_string;
		return $request_string;
	}
	
	//global port 443 switch
	private function port_433(){
		//echo '-->'.$_SERVER['SERVER_PORT'].'<--';
		if($this->SETTINGS->_GLOBAL_SSL && $_SERVER['SERVER_PORT']!="443"){
			//echo 'https://'; //.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
			$this->_HTTP='https://';
			header('Location: https://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);
			//echo '1';
		//} elseif($this->_LOCAL_SSL && $_SERVER['SERVER_PORT']!="443") {
			} elseif($this->_LOCAL_SSL && $_SERVER['SERVER_PORT']!="443") {
			$this->_HTTP='https://';
			header('Location: https://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);
			//echo '2';
		} elseif($this->_GLOBAL_SSL===false && $_SERVER['SERVER_PORT']=="443") {
			$this->_HTTP='http://';
			header('Location: http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);
			//echo '2';
		}
		$this->_HTTP = $_SERVER['SERVER_PORT']=='443'? 'https://': $this->_HTTP;
	}

	//Set language
	public function getlang(){
		
		//
		$request_uri=explode("/",$_SERVER['REQUEST_URI']);
		//lang is always stored at the last array
		$last_arr=end($request_uri);
		
		//filtering
		if($last_arr=="en"){
			 $lang="English";
		} elseif($last_arr=="ch") { 
			$lang="Chinese";
		} else {
			//default english
			$lang="English";
		}
		return $lang;
		
	}
	
	//removes language from $REQUEST_3 and return an array without lang option
	public function get_request_3_array(){
		$request_3=$this->REQUEST_3;
		$request_3_arr=$this->REQUEST_3_ARRAY;
		if($request_3!=""){
			//language detection
			$get_lang=end($request_3_arr);
			if($get_lang=="en"){
				 $target="/en";
			} elseif($get_lang=="ch") { 
				$target="/ch";
			} 
			//remove language option if any
			if(isset($target)){
				$query_string=str_replace($target,"",$request_3);
			} else {
				$query_string=$request_3;
			}
			return explode("/",$query_string);
			} else {
				return $request_3;
			}
	}
	
	//Determines if current page. Mainly used for manual cases..
	public function _iscurrpage( $URL ){ 
		$iscurrent = false;
		
		if($this->REQUEST_PARAMS_STRING!='') $req_str = $this->REQUEST_PARAMS_STRING;
		
		if($URL.$req_str == $_SERVER['REQUEST_URI']){ 
		//if(strstr($_SERVER['REQUEST_URI'],$URL)){
			$iscurrent = true;
		}

		return $iscurrent;
		//echo $currURL;		
	}
	
	//Returns CSS for current page. Mainly used for manual cases..
	public function _iscurrpage_css($URL, $cssActive , $cssInactive=''){
		$css = false;
		$flag = $this->_iscurrpage($URL);
		if($flag){
			$css = $cssActive;
		} else {
			$css = $cssInactive;
		}
		
		return $css;
		
	}

	
	//****************************************
	//_GET_ROUTE
	//Does 2 things:
	//1) if AJAX, returns a link back to router to trigger ajax file handling.
	//2) else do file handling and loading for normal pages
	//****************************************
	public function _GET_ROUTE( $_ARR ){
		
		$Type = $_ARR['Type']; //refers to login type: _BIS, _BIS_ADMIN
		$Folder = $_ARR['Folder'];
		$Router_Name = $_ARR['Router_Name'];
		$LoginSrc = $_ARR['LoginSrc']; // "/admin/modules/login/index.php"; 
		$HomeURL = $_ARR['HomeURL']; //"/client/home/";
		$HomeSrc = $_ARR['HomeSrc']; //"/admin/modules/home/index.php";
		
		$NonLoginCustom = $_ARR['NonLoginCustom'] ;		
		$LoginCustom = $_ARR['LoginCustom']; 
	
		$rLink = false ;
		//SET SYS TYPE
		$this->_SET_CATEGORY_PARAMS($Type); 

		//****************************************
		//NOT LOGIN
		//****************************************
		_E_TRACE( 'Type='.$Type );
		if( $this->Login->_IS_LOGIN($Type)===false ){ 

		
			if($this->REQUEST_2==''){
				//LOGIN PAGE
				$rLink = $_SERVER['DOCUMENT_ROOT'].$LoginSrc;
				_E_TRACE( 'Site._GET_ROUTE.not login.$rLink='.$rLink );
			
			} else {
				
				if(isset( $NonLoginCustom[ $this->REQUEST_2 ] )){
					$rLink = $_SERVER['DOCUMENT_ROOT']. $NonLoginCustom[ $this->REQUEST_2 ];
					_E_TRACE( 'Site._GET_ROUTE.not login.$rLink='.$rLink );
				} else {
					_E_TRACE( 'Site._GET_ROUTE.not login.header='.$this->_HTTP.$_SERVER["HTTP_HOST"].'/'.$Router_Name.'/' );
					header('Location: '.$this->_HTTP.$_SERVER["HTTP_HOST"].'/'.$Router_Name.'/'); 
				}
				
			}			
		
		
		} else { 

			
		//****************************************
		//IS LOGINED
		//****************************************

			//GET AND SET USER RIGHTS?
			//$this->_GET_RIGHTS( $Type );
				
			//SET PATH OR RETURN LINK FOR AJAX's CASE
			if(isset($this->CATEGORY_DEF[ $this->CURRCID ]['Src']) && strstr($_SERVER['REQUEST_URI'],"_ajax")===false ){ 
				//AUTO LOAD SRC FILES
				$rLink =  $_SERVER['DOCUMENT_ROOT'].$this->CATEGORY_DEF[ $this->CURRCID ]['Src'] ;
			
			} elseif(strstr($_SERVER['REQUEST_URI'],"_ajax")){ 
				//ajax definition goes here. Ajax link are not defined in category, hence it would come here.
				//RETURNS LINK FOR AJAX
				$rLink = $_SERVER['DOCUMENT_ROOT']."/".$Folder."/_ajax/ajax.php" ;
				_E_TRACE( 'Site._GET_ROUTE.is login.$rLink='.$rLink );
					
			} else {
							
				if( $this->REQUEST_2=='' ){
					$rLink = $_SERVER['DOCUMENT_ROOT'].$HomeSrc;
					_E_TRACE( 'Site._GET_ROUTE.is login.this->REQUEST_2=="".$rLink='.$rLink );

				} else {
					
					if(isset( $LoginCustom[ $this->REQUEST_2 ] )){
						$rLink = $_SERVER['DOCUMENT_ROOT']. $LoginCustom[ $this->REQUEST_2 ];
						_E_TRACE( 'Site._GET_ROUTE.is custom login.$rLink='.$rLink );
					} else {
						//GO STRAIGHT TO NON AJAX PAGES
						//error_log('Site->header--->Location: '.$this->_HTTP.$_SERVER["HTTP_HOST"].$HomeURL, 0);	
						_E_TRACE( 'Site._GET_ROUTE.is login.header . $rLink='.$this->_HTTP.$_SERVER["HTTP_HOST"].$HomeURL );
						header('Location: '.$this->_HTTP.$_SERVER["HTTP_HOST"].$HomeURL); 


					}
				}			

			}		

		}	
		//_E_TRACE($rLink,true);
		return $rLink;
	
	}
	
	public function _GET_RIGHTS( $Type ){
		if( $this->Login->_IS_LOGIN($Type) ){ 
			//GET RIGHTS
			
			//SET RIGHTS
			$this->RIGHTS = array('read','mod','copy_to_invoice',$this->CURRCID);
		} else {
			error_log( 'site._GET_RIGHTS('.$Type.'):Not allowed to retrieve user rights.',0);
			throw new Exception('Not allowed to retrieve user rights.');
		}
	}
	
	//****************************************
	//Process any give url string, returns in array format
	//able to remove repeated string queries
	//****************************************
	public function _PARSE_GET_PARAMS( $urlstring ){
		
		$return_get = false;
		$parse_url_query = parse_url( $urlstring, PHP_URL_QUERY ); //extract query string from url into string
		parse_str( $parse_url_query, $parse_url_query_arr ); // parse string into array $parse_url_query_arr
		
		foreach( array_keys( $parse_url_query_arr ) as $key ){
			$return_get[ $key ]= $parse_url_query_arr[ $key ];
		}	
		
		return $return_get;
	}	
	
	public function _CLEAN_URL_PARAMS( $url_string ){
		
		$return = false;
		$parse_url= parse_url( $url_string , PHP_URL_QUERY ); 
		
		$arr = explode('&', $parse_url);
		
		foreach(array_keys($arr) as $key){
			
			//echo $arr[ $key ],'<br>';

			$arr_t = explode('=',$arr[ $key ]);
			//echo $arr_t[1],'x<br>';
			if($arr_t[1]!=''){	//excludes blank uri					
				$request[ $arr_t[0] ] = $arr_t[1];	//this line helps to remove duplicate query param entries	
			}			
		}
				
		//REFORM parse_url AND SET FOR ALL PARAMS
		if(isset($request)) $url_string = http_build_query($request);
		
		$return['string'] = $url_string;
		$return ['array'] = $request; //print_r($return);
		
		return $return;
	}
	
	public function __TGET(){
		if(isset($_GET['_third'])){
			if($_GET['_third']!=''){
				//explode();
			}
		}
	}
	
	//****************************************
	//print memory usuage
	//****************************************
	public function MemoryData(){
	
	?>
        <div id="SysMem">
        	
            <div class="syscell">
            <div><span>Memory used by emailloc()</span></div>
            <div><span><?php echo convert(memory_get_usage()); ?><em>real</em></span></div>
            <div><span><?php echo convert(memory_get_peak_usage()); ?><em>peak</em></span></div>
            </div>
            
           <div class="syscell">
           	<div><span>Memory allocated from system </span></div>
            <div><span><?php echo convert(memory_get_usage(true)); ?><em>real</em></span></div>
            <div><span><?php echo convert(memory_get_peak_usage(true)); ?><em>peak</em></span></div>
            </div>
			<?php $this->BenchMark()?>
        </div>
		<?php
		
	}
	//****************************************
	/**
	 * This code will benchmark your server to determine how high of a cost you can
	 * afford. You want to set the highest cost that you can without slowing down
	 * you server too much. 8-10 is a good baseline, and more is good if your servers
	 * are fast enough. The code below aims for ≤ 50 milliseconds stretching time,
	 * which is a good baseline for systems handling interactive logins.
	 */
	 //****************************************
	public function BenchMark(){
		
		$timeTarget = 0.05; // 50 milliseconds 

		$cost = 8;
		do {
			$cost++;
			$start = microtime(true);
			password_hash("test", PASSWORD_BCRYPT, ["cost" => $cost]);
			$end = microtime(true);
		} while (($end - $start) < $timeTarget);

		echo "Appropriate Cost Found: " . $cost . "\n";
	}
}

?>