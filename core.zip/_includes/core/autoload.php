<?php
_E_TRACE( 'autoload start' );
//LOAD FILES
require($_SERVER['DOCUMENT_ROOT'].$_DIR_MAPP.'/_includes/core/class.db.php');
	
//CREATE DB OBJECTS
$db=new DB($server, $database, $user, $password);

//LOCALISED AUTOLOAD CUSTOMIZATIONS	
require($_SERVER['DOCUMENT_ROOT']."/_includes/custom/autoload.php");

//CORE CLASS LOADER CALL	
spl_autoload_register('CoreClassLoader');
//LOCAL CLASS LOADER CALL
/* Location:  root/yourname/_includes/autoload.php */
spl_autoload_register('CustomClassLoader');

	
//Set up Settings
$Settings = new Settings();
$Settings_Arr = array('_REST' ,'_GLOBAL_SSL' ,'_HOST' ,'_MAIL_TEST' ,'_MAIL_ADMIN','_MAIL' );
foreach($Settings_Arr as $key){
	if($key!='_HOST'){
		$Settings->$key = $$key;
	} elseif( $key == '_HOST' ){
		$Settings->_HOST = isset($_HOST) ?  $_HOST!="" ? $_HOST : $_SERVER['HTTP_HOST'] : $_SERVER['HTTP_HOST'];
		$Settings->_HOST_DIR = isset($_HOST) ?  $_HOST!="" ?  "//".$_HOST."/" : "//".$_SERVER['HTTP_HOST']."/" : "//".$_SERVER['HTTP_HOST']."/"; 
	}
}

//Generic PDO queries...
$Database=new Databasefunc();
//Database setting
$Database->db=$db;
$Database->db->Settings=$Settings;

//Set Up SITE
//AJAX string request processing 
if( isset($_POST['UrlLink'] ) ){	
	
	if(sizeof($_POST['UrlLink'])!=0){
		$strlink = parse_url($_POST['UrlLink'], PHP_URL_QUERY);
		$_SERVER['REQUEST_URI'] = $_SERVER['REQUEST_URI'].'/?'.$strlink;	
		parse_str( $strlink , $_GET);		
	}

	
}
//Login
$Login = new Login_custom();
$Login->Database=$Database;

//Create Site Object
$Site= new Site($Settings, $Database);

$Site_Arr = array('_CMS_CAT_MANUAL_DEFINE' ,'_CMS_ADMIN_CAT_MANUAL_DEFINE' , '_BIS_CAT_MANUAL_DEFINE' ,'_BIS_ADMIN_CAT_MANUAL_DEFINE' ,'_SET_DEFAULT','Login' );
foreach($Site_Arr as $key){
	$Site->$key = $$key;
}
$Router_Nm_Arr = array('_BIS','_BIS_ADMIN','_CMS_ADMIN');
foreach($Router_Nm_Arr as $key){
	$Site->_ROUTER_NAME[ $key ] = $_ROUTER_NAME[ $key ];
}





?>