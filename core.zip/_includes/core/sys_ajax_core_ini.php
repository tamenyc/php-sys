<?php
if(use_script()) {
	//FORM CHECKS
	$Formchecks= new FormChecks_Custom();
	if(isset($Database)) $Formchecks->Database=$Database;
	
	//************* !IMPORTANT AJAX CLASS SETUP********************//
	//AJAX SETUP
	$Ajax = new Sys_Ajax_Custom();		
	$Ajax->Database = $Database;	
	$Ajax->Formchecks = $Formchecks;
	
	$Ajax->Site = $Site;
	$Ajax->Settings = $Settings;

	//Test entry
	//$_POST['ops_name']='TEMPLATE2';
	//$_POST['IUNum']='1031111111';
	
	if(method_exists($Ajax, 'AJAX_BOILER_PLATE')){ 
		//$Ajax->$_POST['ops_name']();
		_E_TRACE_AJAX('method_exists().sys_ajax_core_ini.php');
		$Ajax->AJAX_BOILER_PLATE();
		
	} else{
		$json_arr = array(
			"Error"=>"No AJAX_BOILER_PLATE method found."
		);
		/* Send as JSON */
		header("Content-Type: application/json", true);
		echo json_encode( $json_arr );
	}
}
?>