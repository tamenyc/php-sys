<?php
class Formchecks{
	
public $Login; //System login obj
public $Datalogic;
public $Database;

public $ERROR_DISPLAY_LOCATION='placeholder';  // i) placeholder: will display in placeholder ii) errorbox: display in standard error box
	
/*
****************************************************
Auto driver methods
****************************************************
*/	
	
	/*
	****************************************************
	_FORM_CHECKS driver method
	****************************************************
	*/
	public function _FORM_CHECKS(){ 
		_E_TRACE('_FORM_CHECKS().Formchecks'); 
		$go=false;
		$error = false;
		$this->Datalogic->FORM_ERROR = false;
		if(isset($this->Datalogic->_FV)) $go=true;
		
		if($go===false) {	
			_E_TRACE('formchecks._FORM_CHECKS(): _FV undefined.');
			echo 'formchecks._FORM_CHECKS(): _FV undefined.';
		}
		
		
		//CHECK FOR FORM FIELD VALUES
		if($go){
			
			//FOR AJAX
			if(!empty($this->Datalogic->FS_AJAX_ERROR_ID)){
				//_echo('<h1>FS_AJAX_ERROR_ID</h1>');
				//_print_r($this->Datalogic->FS_AJAX_ERROR_ID);
				foreach(array_keys($this->Datalogic->FS_AJAX_ERROR_ID)  as $fsid){
					unset($this->Datalogic->FS_AJAX_PROCESS_FSID[$fsid]);
				}
				
				if(isset($this->Datalogic->FS_AJAX_PROCESS_FSID)){
					foreach(array_keys($this->Datalogic->FS_AJAX_PROCESS_FSID) as $fsid ){
						$this->Datalogic->FS_AJAX_PROCESS_FSID_FINAL[] = $fsid;
					}
					//print_r($this->Datalogic->FS_AJAX_PROCESS_FSID_FINAL);					
				}
				
			}
			
			//CHECK LOGICS
			if(!empty($this->Datalogic->FS_LAYOUT)){
				foreach(array_keys($this->Datalogic->FS_LAYOUT) as $FS_LAYOUT_FSID){
					//_echo($FS_LAYOUT_FSID);
					
					//Level A NON-FS DEFINED CHECKS like _CHKED values..
					if(!empty($this->Datalogic->FS_LAYOUT[$FS_LAYOUT_FSID]['_fs_type']['_chked']['_checks']) && $this->Datalogic->FORM_ERROR===false){ 
					//_E_TRACE($this->Datalogic->FS_LAYOUT[$FS_LAYOUT_FSID]['_fs_type']['_chked']['_checks'],true);
						//Check level A fields then level B when level A checks yields no error
						$this->_level_A_CHKED_checks($FS_LAYOUT_FSID);
						
						if($this->Datalogic->FORM_ERROR) {
							$this->Datalogic->FORM_ERROR = true; //echo 'GOT ERROR';
						} else {
							//echo '_level_B_CHKED_driven_checks';  // Means will only check selected rows' form fields.
							$this->_level_B_CHKED_driven_checks();
							
						}
					} else { 
						//Perform level B on all fields as there is no level A checks defined.
						//echo '_level_B_all_fields_checks()';
						$this->_level_B_all_fields_checks();
					}					
				}

				//_echo('chk positioned form'); //This is for form fields that are outside the dynamic form loops
				$this->_chk_positioned_form_fields();
				//$this->Datalogic->FORM_ERROR = true; //force error
			}
						

		}		
		//$this->Datalogic->FORM_ERROR = true;  //FORCE ERROR
		
	}
	
private function _chk_positioned_form_fields(){
	
	if(is_array($this->Datalogic->_FV)){
		$_FV = $this->Datalogic->_FV;
		//print_r($_FV);
		foreach(array_keys($_FV) as $k){
			//_echo ($k);
			
			if(!empty($this->Datalogic->FS[$k])){
				$FS_fsid = $this->Datalogic->FS[$k]; //print_R($FS_fsid);
				foreach(array_keys($FS_fsid) as $colname){
					if( !empty($FS_fsid[$colname]['_position']) && !empty($FS_fsid[$colname]['_checks']) ){
						//echo $colname;
						foreach(array_keys($_FV[$k]) as $k2){
							$k2_tmp = explode('.#',$k2);
							if(!empty($k2_tmp[0])){
								//echo $k2_tmp[0];
								if($k2_tmp[0]==$colname){
									
									$value = $_FV[$k][$k2];
									$checkArr = $FS_fsid[$colname]['_checks'];
									$grpinfos = $k;
									$grpinfos_FS = $FSID;
									$input_infos = $k2;
									$input_info_fs = $colname;
									
									
									$error = $this->dochecks($value, $checkArr , $grpinfos, $grpinfos_FS, $input_infos , $input_info_fs);
									
									if($error) $this->Datalogic->FORM_ERROR = true;
								}
							}
						}
					}
				}
			}
			
			
		}
	}
}	
private function _level_A_CHKED_checks($FS_LAYOUT_FSID){
	
	$_CHKED_chks_OPS = $this->Datalogic->FS_LAYOUT[$FS_LAYOUT_FSID]['_fs_type']['_chked']['_checks'];
	foreach(array_keys($_CHKED_chks_OPS) as $_CHKED_chk_ops_name ){ //echo $_CHKED_chk_ops_name;
		if( method_exists($this,$_CHKED_chk_ops_name)){
			$error = $this->$_CHKED_chk_ops_name();
			if($error===true) {
				//_echo('A');
				$this->Datalogic->FORM_ERROR = true;
			}
		}
	}
	return $error;
}
//Checks level B form fields indicated by Level A _CHKED
private function _level_B_CHKED_driven_checks(){
	//print_r($this->Datalogic->_FV);
	if(!empty($_POST['_CHKED'])){ 
		foreach(array_keys($_POST['_CHKED']) as $k){ 
			foreach(array_keys($this->Datalogic->_FV[$k]) as $input_infos){
				//_echo ('<h1>'.$k.'-'.$input_infos.'</h1> ');
				$error = $this->_form_checks_do($k,$input_infos);								
				if($error===true) {
					//_echo('B chked driven');
					$this->Datalogic->FORM_ERROR = true; 
				}
			}
		}
	}	
}
//Checks all form fields
private function _level_B_all_fields_checks(){
	
	_E_TRACE('$go==true.formchecks._FORM_CHECKS().');
	//_ETXT($this->Datalogic->_FV,'$this->Datalogic->_FV');
	foreach(array_keys($this->Datalogic->_FV) as $datagrpinfos){
		//echo '--->'.$datagrpinfos;
		$t_arr = explode('.',$datagrpinfos);
		$FSID = $t_arr[0].'.'.$t_arr[1];
				
		if($_POST['FSID']==$FSID){ //This line ensures only the relevant form is being checked.
			foreach(array_keys($this->Datalogic->_FV[$datagrpinfos]) as $input_infos){
				//echo '<h1>',$datagrpinfos,'-',$input_infos,'</h1> ';
				$error = $this->_form_checks_do($datagrpinfos,$input_infos);
						
				if($error) {
					//_echo('_level_B_all_fields_checks');
					$this->Datalogic->FORM_ERROR = true; //echo '<h1>',$datagrpinfos,'-',$input_infos,'</h1> '; echo 'GOT ERROR';
				}
			}					
		} else {
			//echo 'No form ID defined.';
		}

	}

}
/*
****************************************************
Minor methods
****************************************************
*/	
	
	/*
	****************************************************
	_FORM_CHECKS do method
	****************************************************
	*/
	public function _form_checks_do($grpinfos,$input_infos){ //echo '_form_checks_do';
		//****************************************************
		//RETRIEVE VALUES
		$input_info_fs=$this->Datalogic->FS_input_info($grpinfos,$input_infos); //EG: This converts Address#0#0#0 to Address.2.2.2
		$value=$this->Datalogic->_FV[$grpinfos][$input_infos];
		$error = false;
		
		$arr=explode('.',$grpinfos);
		$grpinfos_FS=$arr[0].'.'.$arr[1];
		//print_r($this->Datalogic->_FV);
		//echo '<h1>[',$grpinfos_FS,'][',$input_info_fs,']</h1>';
		//****************************************************
		//CHECKS
		if( isset($this->Datalogic->FS[$grpinfos_FS][$input_info_fs]['_checks']) ) { //echo '<h1>[',$grpinfos_FS,'][',$input_info_fs,']</h1>';
			//_ETXT($grpinfos_FS.'-'.$input_info_fs);
			//_print_r($_POST);
			//_print_r($this->Datalogic->_FV);
			//_echo ($grpinfos.'-'.$input_infos);
			//_print_r($this->Datalogic->_FV[$grpinfos][$input_infos]);
			//_print_r($this->Datalogic->FS[$grpinfos_FS][$input_info_fs]['_checks']);
			$error = $this->dochecks($this->Datalogic->_FV[$grpinfos][$input_infos], $this->Datalogic->FS[$grpinfos_FS][$input_info_fs]['_checks'], $grpinfos, $grpinfos_FS, $input_infos,$input_info_fs);
			
			$FS_AJAX_PROCESS_FSID = $this->Datalogic->FS_AJAX_PROCESS_FSID;
			if($error){
				//echo '<br><strong>_FN[',$grpinfos,'][',$input_infos,']</strong>NOT OK<br>';
				//print_r($this->Datalogic->FS[$grpinfos_FS][$input_info_fs]['_checks']);
				//_echo ($grpinfos.'-'.$input_infos);
				//echo '<br>Error-->'.$error;
				//echo '<br>';	
				$this->Datalogic->FS_AJAX_ERROR_ID[$grpinfos] = $input_infos;
			} else {
				//echo '<br><strong>_FN[',$grpinfos,'][',$input_infos,']</strong>OK<br>'; 				
				$this->Datalogic->FS_AJAX_PROCESS_FSID[$grpinfos] = true;
			}

		}
		
		return $error;
	}
	



	public function dochecks($value, $checkArr , $grpinfos, $grpinfos_FS, $input_infos , $input_info_fs){ 
		//_echo ('<h2>'.$grpinfos.$grpinfos_FS.$input_infos.$input_info_fs.'</h2>');
		//_ETXT($checkArr);
		//print_r($checkArr);
		$errMessage=false;
		if( IS_ASSOC($checkArr) ){
			//echo 'associative array';
			//Associative array checkArr. Older version used this FS[a.1a]['Hello']['_checks'] = array(compulsory'=>'Missing name.');
			//Should upgrade to indexed version. Indexed version supports repeated '_checks' methods call from FS. Repeat '_checks' method call causes system error whereby certain checks are skipped.
			//EG:
			//FS[a.1a]['DateTo']['_checks'] = array(check_date'=> array('params'=>array('DateTo')) ), check_date'=> array('params'=>array('DateFrom')) ));
			//The above example ends up checking "DateFrom" skipping "DateTo".
			foreach(array_keys($checkArr) as $checkType){
				
					//_echo ('<br>_chk_'.$checkType);
					$func='_chk_'.$checkType;
					//_ETXT($func);
					//_echo ('<h3>dochecks()._chck_'.$func.'</h3>');
					$error=$this->$func($value, $checkArr[$checkType] , $grpinfos, $grpinfos_FS, $input_infos, $input_info_fs);

				if($error!==false) break;	

			}	
		} else {
			//Indexed array checkArr. FS[a.1a]['Hello']['_checks'] = array('0'=>array(compulsory'=>'Missing name.'), '1'=>array("chk_name"=>"Invalid name."));
			//Supports repeated '_checks' methods call from FS.
			foreach(array_keys($checkArr) as $checkTypeIndex){
				foreach(array_keys($checkArr[$checkTypeIndex]) as $checkType){
					//_echo ('<h4>_chk_'.$checkType.'</h4>');
					$func='_chk_'.$checkType;
					//_ETXT($func);
					//_echo ('<h3>dochecks()._chck_'.$func.'</h3>');
					$error=$this->$func($value, $checkArr[$checkTypeIndex][$checkType] , $grpinfos, $grpinfos_FS, $input_infos, $input_info_fs);

					if($error!==false) break;				
				}
				if($error!==false) break;	

			}			
		}

		return $error;

	}
	
	public function addCSS ($grpinfos, $grpinfos_FS, $input_info_fs ,$class){
		$this->Datalogic->FS[$grpinfos_FS][$input_info_fs]['_class']=$this->Datalogic->FS[$grpinfos_FS][$input_info_fs]['_class'].' '.$class;
	}
	
	public function replaceValue ($grpinfos, $input_infos ,$value){
		$this->Datalogic->_FV[$grpinfos][$input_infos]=$value;
		//echo $this->Datalogic->_FV[$grpinfos][$input_infos];
	}
	
	public function form_error_ops_logic ($grpinfos, $grpinfos_FS,$input_infos,$input_info_fs,  array $chkArr){
		
		if( isset($chkArr['_hide_error_msg']) ){
			if( $chkArr['_hide_error_msg']===true ){
				//Do nothing. Do not perform form_error_ops() to display error message.
			}
								
		} else {
			//Display error message.
			if($chkArr['msg']=='') $chkArr['msg']='Incorrect entry.';
			$this->form_error_ops ($grpinfos, $grpinfos_FS, $input_infos, $input_info_fs, $chkArr['msg']);
		}
		
	}
	
	public function form_error_ops ($grpinfos, $grpinfos_FS,$input_infos,$input_info_fs,  $message){
		//$this->replaceValue ($grpinfos, $input_infos ,'');
		$this->Datalogic->_ERROR[$grpinfos][$input_infos]=$message;
		//echo '------xxxxxxxxxxx';print_r($this->Datalogic->_ERROR);
		
	}
/*
****************************************************
Check operation methods
****************************************************
NOTE:
_chk_compulsory($param1, $param2,....)

[$param2]
i) $param2 will be $errMessage for QS entries like "_checks"=>array("compulsory"=>"Missing vehicle no.")
ii) $param2 will be $chkArr for QS entries like "_checks"=>array("not_same"=>array("FromVehicleID","ToVehicleID"),"msg"=>"The error message")
*/

	
	public function _chk_CHKED_compulsory_at_least_one (){ //_E_TRACE('_chk_CHKED_compulsory_at_least_one',true);
		$error = false;
		
		if(empty($_POST['_CHKED'])){
			//_E_TRACE('error yes',true);
			$this->Datalogic->_ERROR['_CHKED']='Missing selection(s).';
			
			$error = true;
		}		
			
		return $error;
	}
	//w/o +65
	public function _chk_validate_tel_num_unsigned($contactno, $errMessage, $grpinfos, $grpinfos_FS, $input_infos ,$input_info_fs){ 
		
		$error=false;

		if(!IS_UNSIGNED_NUMBERS($contactno)){
		  // invalid input.
		  $error=true;
		  if(HAVE_SIGNS($contactno)){
			  $errMessage = 'Do not enter area code here.';
		  } else {
			  $errMessage = 'Invalid number.';
		  }
		  
		}
		
		if($error==true) { 
			//echo '--'.$value;
			//echo $grpinfos,$grpinfos_FS,$input_infos,$input_info_fs,$errMessage;
			$this->form_error_ops ($grpinfos, $grpinfos_FS, $input_infos, $input_info_fs, $errMessage);
		} 
		return $error;	
	}
	public function _chk_validate_tel_num_len_sg($contactno, $errMessage, $grpinfos, $grpinfos_FS, $input_infos ,$input_info_fs){ 
		
		$error=false;

		if(!IS_STRLEN_EQUAL($contactno,'8')){
			$error = true;
			$errMessage = 'Must have 8 digits.';
		}
		
		if($error==true) { 
			//echo '--'.$value;
			//echo $grpinfos,$grpinfos_FS,$input_infos,$input_info_fs,$errMessage;
			$this->form_error_ops ($grpinfos, $grpinfos_FS, $input_infos, $input_info_fs, $errMessage);
		} 
		return $error;	
	}
	public function _chk_validate_tel_num_sg_first_number($contactno, $errMessage, $grpinfos, $grpinfos_FS, $input_infos ,$input_info_fs){ 
		
		$error=false;

		$exceptions = array('8','6','9');
		if(!in_array($contactno[0],$exceptions)){
			$error =true;
			$errMessage = 'First number must be "8","6" or "9"';
		}
		
		if($error==true) { 
			//echo '--'.$value;
			//echo $grpinfos,$grpinfos_FS,$input_infos,$input_info_fs,$errMessage;
			$this->form_error_ops ($grpinfos, $grpinfos_FS, $input_infos, $input_info_fs, $errMessage);
		} 
		return $error;	
	}
	public function _chk_validate_sg_tel_num_no_area_code($contactno, $errMessage, $grpinfos, $grpinfos_FS, $input_infos ,$input_info_fs){ 
	
		if($this->_chk_validate_tel_num_unsigned($contactno, $errMessage, $grpinfos, $grpinfos_FS, $input_infos ,$input_info_fs)){
			$error = true;
		} elseif($this->_chk_validate_tel_num_len_sg($contactno, $errMessage, $grpinfos, $grpinfos_FS, $input_infos ,$input_info_fs)) {
			$error = true;
		} elseif($this->_chk_validate_tel_num_sg_first_number($contactno, $errMessage, $grpinfos, $grpinfos_FS, $input_infos ,$input_info_fs)){
			$error = true;
		} else {
			$error = false;
		}
		
		
		return $error;
	}
	public function _chk_min_strlen_eight($str, $errMessage, $grpinfos, $grpinfos_FS, $input_infos ,$input_info_fs){ 
		
		$error=false;

		if(strlen(trim($str))<8){
			$error = true;
			$errMessage = 'Min 8 characters.';
		}
		
		if($error==true) { 
			//echo '--'.$value;
			//echo $grpinfos,$grpinfos_FS,$input_infos,$input_info_fs,$errMessage;
			$this->form_error_ops ($grpinfos, $grpinfos_FS, $input_infos, $input_info_fs, $errMessage);
		} 
		return $error;	
	}
	public function _chk_has_alphanumeric_mix($str, $errMessage, $grpinfos, $grpinfos_FS, $input_infos ,$input_info_fs){ 
		
		$error=false;
		$errMessage = 'Must contain a alphanumeric characters like a-z, 0-9. Non alphanumeric characters are not allowed. Eg: ".","*","!"';
		
		if(ctype_alpha($str)){
			//all alpha check
			$error = true;
		} elseif(ctype_digit($str)){
			//all digit check
			$error = true;
		} elseif(!ctype_alnum($str)){
			//contains characters other than alphanumeric characters eg #!@
			$error = true;
		}
		
		if($error==true) { 
			//echo '--'.$value;
			//echo $grpinfos,$grpinfos_FS,$input_infos,$input_info_fs,$errMessage;
			$this->form_error_ops ($grpinfos, $grpinfos_FS, $input_infos, $input_info_fs, $errMessage);
		} 
		return $error;	
	}
	public function _chk_validate_email($email, $errMessage, $grpinfos, $grpinfos_FS, $input_infos ,$input_info_fs){ 
	
		$error=false;
		
		if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
			$error = true;
		}
		
		
		if($error==true) { 
			//echo '--'.$value;
			//echo $grpinfos,$grpinfos_FS,$input_infos,$input_info_fs,$errMessage;
			$this->form_error_ops ($grpinfos, $grpinfos_FS, $input_infos, $input_info_fs, $errMessage);
		} 
		return $error;	
	}
	
	public function _chk_compulsory($value, $errMessage, $grpinfos, $grpinfos_FS, $input_infos ,$input_info_fs){ 
		//_echo('<h1>'.$grpinfos.'-'.$input_info_fs.'</h1>'); 
		//$this->Datalogic->_print_post_fv();
		//_echo ('value-'.$value.'<br>');
		
		$error=false;
		if($value=='') { 
			//echo '--'.$value;
			//echo $grpinfos,$grpinfos_FS,$input_infos,$input_info_fs,$errMessage;
			$this->form_error_ops ($grpinfos, $grpinfos_FS, $input_infos, $input_info_fs, $errMessage);
			$error=true; 
		} 
		return $error;
	}


	public function _chk_checkdate($value, $chkArr, $grpinfos, $grpinfos_FS, $input_infos ,$input_info_fs){
		$error=false;
		//_echo('<h1>_chk_checkdate '.$grpinfos.'-'.$grpinfos_FS.'-'.$input_infos.'-'.$input_info_fs.'</h1>');
		//RETRIEVE
		$input_infosArr = explode('.',$input_infos);
		$TierInfo = $input_infosArr[1];
		//_print_r($chkArr['params']);
		//_print_r($this->Datalogic->_FV);
		if(!empty($chkArr['params'])){
			foreach($chkArr['params'] as $colname){
				if($chkArr['params'][0]==$colname) { 
					$Date = $this->Datalogic->_FV[$grpinfos][$colname.'.'.$TierInfo]; 
				} 
			}
		}
		$DateTest = explode('-',$Date); //_print_r($DateTest);
		
		$got_blank = false;
		if(is_array($DateTest)){
			$DateTestArrSize = count($DateTest);
		}
		
		if($DateTestArrSize==3){
			//_echo('<h2>_chk_checkdate '.$grpinfos.'-'.$grpinfos_FS.'-'.$input_infos.'-'.$input_info_fs.'</h2>');
			//checkdate(month,day,year);
			if(checkdate($DateTest[1],$DateTest[2],$DateTest[0])){
				//_echo('<h3>_chk_checkdate '.$grpinfos.'-'.$grpinfos_FS.'-'.$input_infos.'-'.$input_info_fs.'---OK</h3>');
			} else {
				//_echo('<h3>_chk_checkdate '.$grpinfos.'-'.$grpinfos_FS.'-'.$input_infos.'-'.$input_info_fs.'---Invalid date 1</h3>');
				if(empty($chkArr['msg'])) $chkArr['msg'] = 'Invalid date.';
				$error = true;
			}
		} else {
			//_echo('<h3>_chk_checkdate '.$grpinfos.'-'.$grpinfos_FS.'-'.$input_infos.'-'.$input_info_fs.'---Invalid date 2</h3>');
			//echo 'err';
			if(empty($chkArr['msg'])) $chkArr['msg'] = 'Invalid date.';
			$error = true;
		}
		
		if($error===true) $this->form_error_ops ($grpinfos, $grpinfos_FS, $input_infos, $input_info_fs, $chkArr['msg']);		
		return $error;
	}
	public function _chk_check_date_sequence($value, $chkArr, $grpinfos, $grpinfos_FS, $input_infos ,$input_info_fs){
		$error=false;
		
		//RETRIEVE TIERINFO
		$input_infosArr = explode('.',$input_infos);
		$TierInfo = $input_infosArr[1];
		//print_r($chkArr['params']);
		
		if(!empty($chkArr['params'])){
			foreach($chkArr['params'] as $colname){
				if($chkArr['params'][0]==$colname) {
					$d1 = $this->Datalogic->_FV[$grpinfos][$colname.'.'.$TierInfo];
				} elseif($chkArr['params'][1]==$colname){
					$d2 = $this->Datalogic->_FV[$grpinfos][$colname.'.'.$TierInfo];
				}
				
			}			
		}
		//echo $d1.'---'.$d2;
		
		$error = $this->Datalogic->check_date_sequence($d1,$d2);
		
		if($error===true) $this->form_error_ops_logic ($grpinfos, $grpinfos_FS, $input_infos, $input_info_fs, $chkArr);
		return $error;
	}
	//Returns false on
	/*
		i) both are blank
		ii) both are filled
	*/
	public function _chk_compulsory_either($value, $chkArr, $grpinfos, $grpinfos_FS, $input_infos ,$input_info_fs){
		$error=false;
		
		//RETRIEVE TIERINFO
		$input_infosArr = explode('.',$input_infos);
		$TierInfo = $input_infosArr[1];
		
		//Loop thru $chkArr['params'] to get _FV to check for empty entries
		$counter=0;
		$counterFilled=0;
		foreach($chkArr['params'] as $colname){
			//echo $grpinfos.'--'.$colname.'.'.$TierInfo,'<br>'; //echo $this->Datalogic->_FV[$grpinfos][$colname.'.'.$TierInfo];
			if($this->Datalogic->_FV[$grpinfos][$colname.'.'.$TierInfo]=='') {
				$counter++;		
			} else {
				$counterFilled++;
			}
		}
		
		//if($counter>1 || $counterFilled==2){
		if($counter==2){
			$error=true; 
			$this->form_error_ops ($grpinfos, $grpinfos_FS, $input_infos, $input_info_fs, $chkArr['msg']);
			foreach($chkArr['params'] as $colname){
				$this->Datalogic->_FV[$grpinfos][$colname.'.'.$TierInfo]='';
			}
		}

		return $error;
	}
	
	public function _chk_not_same($value, $chkArr, $grpinfos, $grpinfos_FS, $input_infos, $input_info_fs){
		$error=false;
		$string=array();
		
		//RETRIEVE TIERINFO
		$input_infosArr = explode('.',$input_infos);
		$TierInfo = $input_infosArr[1];
		
		foreach($chkArr['params'] as $colname){
			//echo $colname;
			if(isset($this->Datalogic->_FV[$grpinfos][$colname.'.'.$TierInfo])){
				$string[] = $this->Datalogic->_FV[$grpinfos][$colname.'.'.$TierInfo];
			}
		}
		//print_r($string);
		if( strcasecmp($string[0],$string[1])==0 ){ //same=>error
			$error = true;
			$this->form_error_ops ($grpinfos, $grpinfos_FS, $input_infos, $input_info_fs, $chkArr['msg']);
		} 
		
		return $error;	
	}
	
	public function _chk_same($value, $chkArr, $grpinfos, $grpinfos_FS, $input_infos, $input_info_fs){
		$error=false;
		$string=array();
		
		//RETRIEVE TIERINFO
		$input_infosArr = explode('.',$input_infos);
		$TierInfo = $input_infosArr[1];
		//print_r($_POST); 
		//print_r($this->Datalogic->_FV);
		
		foreach($chkArr['params'] as $colname){
			//echo '//',$grpinfos,'-',$colname,'-',$TierInfo,'_FV-->', $this->Datalogic->_FV[$grpinfos][$colname.'.'.$TierInfo],'<br>';
			//echo $this->Datalogic->_FV[$grpinfos][$colname.'.'.$TierInfo];
			if(isset($this->Datalogic->_FV[$grpinfos][$colname.'.'.$TierInfo])){
				$string[] = $this->Datalogic->_FV[$grpinfos][$colname.'.'.$TierInfo];
			}
		}
		//print_r($string);
		//echo '<h1>',strcasecmp($string[0],$string[1]),'</h1>';
		
		if( strcasecmp($string[0],$string[1])!=0 ){ //not same=>error
			$error = true;
			$this->form_error_ops ($grpinfos, $grpinfos_FS, $input_infos, $input_info_fs, $chkArr['msg']);
		} 
		
		return $error;	
	}
	
	public function _chk_email($value, $errMessage, $grpinfos, $grpinfos_FS, $input_infos, $input_info_fs){
		$error=false;
		//_ETXT('hello');
		//if(strpos($value,"@")===false){
		if( !filter_var($value, FILTER_VALIDATE_EMAIL) ){
			$error=true;
			$this->form_error_ops ($grpinfos, $grpinfos_FS, $input_infos, $input_info_fs, $errMessage);
		}
		return $error;
	}
	

	
	public function _chk_clientpw($value, $errMessage, $grpinfos, $grpinfos_FS, $input_infos ,$input_info_fs){
		//echo '<h1>',$value,'</h1>';
		$error=false;
		
		$error = false;

		if($this->Datalogic->_FV['a.1a']['Email.#0']!=''){
			$error = $this->Login->_CHECK_CLIENT_PW($value); 
			if($error) $errMessage = 'Password is wrong';
		} 
		
		if($error){
			$this->form_error_ops ($grpinfos, $grpinfos_FS, $input_infos,$input_info_fs,  $errMessage);
		}	
		
		return $error;
	}
		
	public function _chk_adminpw($value, $errMessage, $grpinfos, $grpinfos_FS, $input_infos ,$input_info_fs){
		//echo '<h1>',$value,'</h1>';
		$error=false;
		
		$error = false;

		if($this->Datalogic->_FV['a.1a']['Username.#0']!=''){
			$error = $this->Login->_CHECK_ADMIN_PW($value); 
			if($error) $errMessage = 'Password is wrong';
		} 
		
		if($error){
			$this->form_error_ops ($grpinfos, $grpinfos_FS, $input_infos,$input_info_fs,  $errMessage);
		}	
		
		return $error;
	}
	
	public function _chk_spamblock($value, $chkArr, $grpinfos, $grpinfos_FS, $input_infos ,$input_info_fs){
		$error=false;
		if($_POST[ $chkArr[0] ]!='') { 
			$this->form_error_ops ($grpinfos, $grpinfos_FS, $input_infos, $input_info_fs, '');
			$error=true; 
		} 
		//print_r($chkArr);
		//$error=true; 
		return $error;
	}
	
	public function _chk_check_repeated_entries($value, $chkArr, $grpinfos, $grpinfos_FS, $input_infos ,$input_info_fs){
		$error=false;
		//Columns earmarked for comparison are set the array.
		//RETRIEVE TIERINFO
		$input_infosArr = explode('.',$input_infos);
		$TierInfo = $input_infosArr[1];
		//print_r($chkArr['params']);
		
		//Form current data row string check
		if(!empty($chkArr['params'])){
			$strSep='';
			$_curr_chk_str_data='';
			foreach($chkArr['params'] as $colname){
				$_curr_chk_str_data = $_curr_chk_str_data.$strSep.$this->Datalogic->_FV[$grpinfos][$colname.'.'.$TierInfo]; 
				$strSep = '_';
			}			
		}		
		//echo $_curr_chk_str_data.'<br>';
		

		//Pass into stored data to prevent this loop from executing more than once in the script.		
		if(empty($this->Datalogic->_STORED_DATA['Data_Checks_Repeated'][$grpinfos][$input_info_fs])) {
			//Form data string checks from FV
			$FV = $this->Datalogic->_FV;
			foreach(array_keys($FV[$grpinfos]) as $k){ 
				$k_arr = explode('.',$k);
				
				$strSep='';
				$_data_chk_arr [ $k_arr[1] ] = '';
				//Form check strings pulled from _FV filtered by columns stated in $chkArr['params']
				foreach($chkArr['params'] as $colname){
					$_data_chk_arr [ $k_arr[1] ] = $_data_chk_arr [ $k_arr[1] ].$strSep.$FV[$grpinfos][$colname.'.'.$k_arr[1]];
					$strSep = '_';
				}
								
			}
			//echo $grpinfos.'-'.$input_info_fs;
			$this->Datalogic->_STORED_DATA['Data_Checks_Repeated'][$grpinfos][$input_info_fs] = $_data_chk_arr;
		} else {
			$_data_chk_arr = $this->Datalogic->_STORED_DATA['Data_Checks_Repeated'][$grpinfos][$input_info_fs];
		}		
		//print_r($_data_chk_arr);
		foreach(array_keys($_data_chk_arr) as $i ){ 
			if($i!==$TierInfo){ //exclude checking on current row during iteration.
				if($_curr_chk_str_data == $_data_chk_arr[$i]){
					//echo 'error';
					$error = true;
				}
			}
		}

		
		if($error===true) $this->form_error_ops ($grpinfos, $grpinfos_FS, $input_infos, $input_info_fs, $chkArr['msg']);
		//$error = true; //force error
		return $error;		
	}

	
}
?>