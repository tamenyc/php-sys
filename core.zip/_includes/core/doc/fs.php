<?php
if(use_script()) {

	$HTML_COMPOS[ 'a.1a' ]['pagination']['max_display'] = 4;
	$HTML_COMPOS[ 'a.1a' ]['pagination']['Pagination_PAGE_BTN_MAX'] = 10;
	$HTML_COMPOS[ 'a.1a' ]['pagination']['position'] = 'bot'; //bot, top, both
	$HTML_COMPOS[ 'a.1a' ]['pagination']['qs_target'] = '1a';
	$HTML_COMPOS[ 'a.1a' ]['pagination']['parameters'] = ''; //query params to find total number of row results
	

	$SEARCH[ 'a.1a' ]['CSS'] = '';
	$SEARCH[ 'a.1a' ]['FS'] = array(
		/*
		array(
			"_type"=>"text",
			"_key"=>"CONCAT(Salutation,' ',FirstName,' ',LastName,' ',CompanyName,' ',Address,' ',PostalCode,' ',Email,' ',ContactNo)",
			"_url_key"=>"name",
			"_class"=>"",
			"_alias"=>"Name",
			"_operator"=>'rlike',
			"_opperand"=>"AND",
			"_ctype"=>"std"
		),
		*/
		array(
			"_type"=>"text",
			"_location"=>"top_row",
			"_concat"=>array('Salutation','FirstName','LastName',' CompanyName','Address','PostalCode','Email','ContactNo'),
			"_url_key"=>"search",
			"_class"=>"",
			"_alias"=>"Search",
			"_operator"=>'rlike',
			"_opperand"=>"AND",
			"_ctype"=>"std",
			"_placeholder"=>'Search projects',
			"_col_w"=>'4',
			/*
			"_input-group-addon"=>array(
				array(
					"_alias"=>'@',
					"_icon"=>'',
					"_class"=>'',				
				),
				array(
					"_alias"=>'Search',
					"_icon"=>'',
					"_class"=>'',				
				),
			),
			*/
			"_input-group-btn"=>array(
				"_alias"=>'',
				"_icon"=>'fa fa-search',
				"_class"=>'',
			)
		),
		array(
			"_type"=>"select",
			"_location"=>"top_row",
			"_class"=>"",
			"_alias"=>'Status',
			"_url_key"=>"state",
			"_key"=>"Status",
			"_operator"=>'equal',
			"_opperand"=>"AND",
			"_group"=>array(
				array(								
					"_gvalue"=>"",
					"_display"=>"Select status",
				),
				array(								
					"_gvalue"=>"Active",
					"_display"=>"Active",
				),
				array(
					"_gvalue"=>"Inactive",
					"_display"=>"Inactive",
				),
			),
		),

		
	);
	

	$FSORT[ 'a.1a' ]['SORT_TYPE'] = 'single'; 
	$FSORT[ 'a.1a' ]['FS'] = array(
		array(
			"_type"=>"alink",			
			"_key"=>"Name",
			"_url_key"=>"sn",
			"_class"=>"",

		),
		array(
			"_type"=>"alink",			
			"_key"=>"CompanyName",
			"_url_key"=>"spro",
			"_class"=>"",

		),
		array(
			"_type"=>"alink",			
			"_key"=>"Address",
			"_url_key"=>"sa",
			"_class"=>"",
		),
		array(
			"_type"=>"alink",			
			"_key"=>"PostalCode",
			"_url_key"=>"spc",
			"_class"=>"",

		),
		array(
			"_type"=>"alink",			
			"_key"=>"Email",
			"_url_key"=>"s_email",
			"_class"=>"",

		),
		array(
			"_type"=>"alink",			
			"_key"=>"Status",
			"_url_key"=>"s_state",
			"_class"=>"",

		),
		array(
			"_type"=>"alink",			
			"_key"=>"ContactNo",
			"_url_key"=>"s_cn",
			"_class"=>"",

		),
		array(
			"_type"=>"alink",			
			"_key"=>"Completion",
			"_url_key"=>"s_cm",
			"_class"=>"",

		),
	); 

	
	$GRID=array(
		/*
		'#class.0.row dashboard-header white-bg animated fadeIn'=>array(  
			'#class.0.col-sm-12'=>array(
				'_content'=>'WID#1' //rule: never embed content directly here. Do it in the class.
			),
		),
		*/
		'#class.1.wrapper wrapper-content animated fadeInRight'=>array(  
			'#class.0.row m-t-sm'=>array(
				'#class.0.col-sm-12'=>array(
					//'_content'=>array('WID#1','FS#a.1a','FS#b.2a') //rule: never embed content directly here. Do it in the class.
					//'_content'=>array('WID#1','FS#a.1a')
					'_content'=>array('FS#a.1a'),
				),
			),
		)
	);

	$WID=array(

				"1"=>array(
					"_qs"=>"7a",
					"_type"=>"Stats_Display",
					"_title"=>"Season Parking",
					"_title_emp"=>"Total",				
					"_text"=>"require your attention",
					"_link"=>"client/parking/renew/",
					"_result"=>array(
						"ExpiringNo"=>array(
							"_class"=>"_WIG_PENDING",
							"_link"=>"client/parking/renew/?status=expiring",
							"_alias"=>"expiring"
						), 
						"OverdueNo"=>array(
							"_class"=>"_WIG_ALERT",
							"_link"=>"client/parking/renew/?status=overdue",
							"_alias"=>"overdue"
						),
					)
						
				)

	);

	$QS=array(
		"1a"=>array(
			"_table"=>"project_demo",
			"_colnames"=>"CONCAT( IFNULL(Salutation,' '),' ',IFNULL(FirstName,' '),' ',IFNULL(LastName,' ') ) as Name , Completion, CompanyName ,Address,PostalCode,ContactNo,Email,ClientID,Status",
			//"_filter"=>"Status<>'Deleted'",
			"_filter"=>"Status<>'Deleted'",
			"_keyID"=>"ClientID",
			//"_llimit"=>$_STARTKEY,
			//"_ulimit"=>$_LIMIT,
			"_order"=>"AddedDate DESC"
			
		),
		"2a"=>array(
			"_table"=>"project_demo",
			"_colnames"=>"Salutation, FirstName, LastName, CompanyName, Email, ContactNo, Address, Block, UnitNo,PostalCode, Country,ClientID",
			"_filter"=>"ClientID=?",
			"_keyID"=>"ClientID",
			"_valueEB"=>array(
					/*INSERT PARAMETERS
					"AddedBy"=>$_SESSION['Name'],
					"AddedByID"=>$_SESSION['LoginAccountID'],
					"AddedByType"=>"Client",
					"AddedDate"=>"NOW()",*/
					
					/*UPDATE PARAMETERS*/
					"ModifiedBy"=>$_SESSION['Username'],
					"ModifiedByID"=>$_SESSION['LoginAccountID'],
					"ModifiedByType"=>"Client",
					"ModifiedDate"=>"NOW()",
					
					/*STATUS PARAMETERS*/
					//remove 'Status if it's appears in the form field'
					"Status"=>"Active",
					"StatusDate"=>"NOW()",

							
				),
			"_ops"=>array(
				"Keyword"=>array("_qs_concatenate"=>array("params"=>array(Address))),			
			)
		),
		"3a"=>array(
			"_table"=>"country_list",
			"_colnames"=>"Name AS Country ,CountriesID",
			"_keyID"=>"Country",
			"_order"=>"Country",
			"_group_gen_displayname"=>"Country",
			"_group_gen_id"=>"Country",
		),
		"4a"=>array(
			"_table"=>"salutation",
			"_colnames"=>"Salutation ,SalutationID",
			"_keyID"=>"SalutationID",
			"_order"=>"DisplayOrder",
			"_group_gen_displayname"=>"Salutation",
			"_group_gen_id"=>"Salutation",
		),
		"7a"=>array(
			"_table"=>"invoice,invoice_item",
			"_colnames"=>"SUM(IF(invoice.Status='Paid'  AND PeriodTo BETWEEN NOW() AND DATE_ADD(NOW(), INTERVAL 60 DAY) ,1,0)) AS Paid,
	SUM(IF( PeriodTo BETWEEN NOW() AND DATE_ADD(NOW(), INTERVAL 60 DAY) AND invoice.Status<>'Paid',1,0)) AS Expiring,
	SUM(IF( PeriodTo < NOW() AND invoice.Status<>'Paid' ,1,0 )) AS Overdue,
	SUM(IF( STATUS<>'Paid' ,1,0 ))  AS Total",
			"_filter"=>"ClientID=? AND invoice.InvoiceID=invoice_item.InvoiceID AND invoice.Status<>'Delete'",
		),
		
	);
	$FS_TOOLBAR[ "a.1a" ]=array(
		"_add"=>array(
			//"_modal_call"=>"b.2a",
			""=>"",
			"_icon"=>"",
		),
		"_delete"=>array(
			"_icon"=>""
		),

		
	);
	$FS_LAYOUT=array(
		"a.1a"=>array(
			"_height"=>'h600', //css class
			"_display_title"=>'Project Summary',
			"_title"=>'', //html form attri
			"_class"=>'',
			"_fs_type"=>array(
				"_type"=>'table',
				"_static_table"=>false,
				"_table_code"=>'dynamic_3A',
			),
			"_submit_btn"=>array(
				"_class"=>'',
				"_value"=>''
			)
		),
		"b.2a"=>array(
			"_height"=>'h600', //css class
			"_display_title"=>'Add Client',
			"_title"=>'',
			"_class"=>'',
			"_modal"=>false,
			"_fs_type"=>array(
				"_type"=>'div',
				"_static_table"=>true,
				//"_table_code"=>'dynamic_3A',
			),
			"_submit_btn"=>array(
				"_class"=>'',
				"_value"=>''
			)
		)
	);
	
	$FS=array(
		"a.1a"=>array(
			"CompanyName"=>array(
				"_type"=>"display",
				"_class"=>"",
				"_alias"=>"Project",				
			),
			"Name"=>array(
				"_type"=>"display",
				"_class"=>"",
				"_alias"=>"Name",				
				
			),

			"Address"=>array(
				"_type"=>"display",
				"_class"=>"",
				"_alias"=>"Address",
			),

			
			"ContactNo"=>array(
				"_type"=>"display",
				"_class"=>"",
				"_alias"=>'<i class="fa fa-phone"></i>',
			),
			"Completion"=>array(
				"_type"=>"piety",
				"_class"=>"",
				"_alias"=>'Completed', 
			),
			"Status"=>array(
				"_type"=>"display_data_label", //calls display_data_label method
				"_display_data_label"=>'general', 
				//this must be used in tandem with "_type"=>"display_data_label". This contains the css settings for different status.
				//The settings are set at config.php
				"_class"=>"",
				"_alias"=>'Status',
			),
			
		),
		"b.2a"=>array(

			"Salutation"=>array(
				"_type"=>"select",
				"_class"=>"form",
				"_alias"=>"Salutation",
				"_group_gen"=>"4a",
				"_placeholder"=>"Select",
				"_cell_w"=>'',
				"_col_w"=>"2",
				"_col_class"=>"fh-70 m-b",
				//"_checks"=>array("compulsory"=>"Missing country"),	
	
			),
			"FirstName"=>array(
				"_type"=>"text",
				"_class"=>"form",
				"_alias"=>"First Name",
				"_cell_w"=>'',
				"_col_w"=>"2",
				"_col_class"=>"fh-70 m-b",
				
			),
			"LastName"=>array(
				"_type"=>"text",
				"_class"=>"form",
				"_alias"=>"Last Name",
				"_cell_w"=>'',
				"_col_w"=>"6",
				"_col_class"=>"fh-70 m-b",
				"_clear"=>"hr-line-dashed"
				
			),			
			"Address"=>array(
				"_type"=>"text",
				"_class"=>"form",
				"_alias"=>"Address",
				"_cell_w"=>'10',
				"_col_w"=>"",
				"_col_class"=>"fh-70 m-b",
				
			),
			"Block"=>array(
				"_type"=>"text",
				"_class"=>"form",
				"_alias"=>"Block Number",
				"_cell_w"=>'',
				"_col_w"=>"2",
				"_col_class"=>"fh-70 m-b",
				
			),
			"UnitNo"=>array(
				"_type"=>"text",
				"_class"=>"form",
				"_alias"=>"Unit No",
				"_cell_w"=>'',
				"_col_w"=>"2",
				"_col_class"=>"fh-70 m-b",
				
			),
			"PostalCode"=>array(
				"_type"=>"text",
				"_class"=>"form",
				"_alias"=>"Postal Code",
				"_cell_w"=>'',
				"_col_w"=>"2",
				"_col_class"=>"fh-70 m-b",
				"_clear"=>"hr-line-dashed"
				
			),

			"Country"=>array(
				"_type"=>"select",
				"_class"=>"form",
				"_alias"=>"Country",
				"_group_gen"=>"3a",
				"_placeholder"=>"Select",
				"_checks"=>array("compulsory"=>"Missing country"),	
				"_cell_w"=>'6',
				"_col_w"=>"12",
				"_col_class"=>"fh-70 m-b row",
			),
			"CompanyName"=>array(
				"_type"=>"text",
				"_class"=>"form",
				"_alias"=>"Company Name",
				"_cell_w"=>'6',
				"_col_w"=>"12",
				"_col_class"=>"fh-70 m-b row",
				
			),
			"Email"=>array(
				"_type"=>"text",
				"_class"=>"form",
				"_alias"=>"Email",
				"_checks"=>array("compulsory"=>"Missing email"),
				"_cell_w"=>'6',
				"_col_w"=>"12",
				"_col_class"=>"fh-70 m-b row",
			),
			"ContactNo"=>array(
				"_type"=>"text",
				"_class"=>"form",
				"_alias"=>"Tel",
				"_checks"=>array("compulsory"=>"Missing tel"),
				"_cell_w"=>'6',
				"_col_w"=>"12",
				"_col_class"=>"fh-70 m-b row",
			),
		),
	);
	
	$FOPS['a.1a']=array(
		/*array('_insert'=>true),*/
		array('_showdata'=>true),
		array('_update'=>true),
		array('_delete'=>true),
		//array('email_renew_parking'=>true,
	);
	$FOPS['b.2a']=array(
		array('_insert'=>true),
	);
	$FFlow['a.1a']=array(
		'_url'=>'admin/client/list/',
		'_form_success_msg'=>'',
	);
	$FFlow['b.2a']=array(
		'_url'=>'admin/client/list/',
		'_form_success_msg'=>'',
	);
						
	global $_FS_INI;		
	require($_FS_INI);

	$uid=$_SESSION['LoginAccountID'];
	//param pulled from $_GET
	//$vparam['1a']=array($uid);
	$vparam['4a']=array($uid,'Active');
	$vparam['7a']=array($uid);
	$vparam['2a']=array($uid);
	
	





}
?>