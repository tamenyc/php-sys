<?php
if(use_script()) {
	$Settings = $this->Settings;
	$Database = $this->Database;
	$Site = isset( $this->Site ) ? $this->Site : false ; 
	//_E_TRACE_AJAX('sys_ajax_ini.php   ---- >$CatDef = $Site->_GET_CATEGORY_DEF( $Site->SYS_TYPE )');
	//retrieve category from category file.
	$CatDef = $Site->_GET_CATEGORY_DEF( $Site->SYS_TYPE ); 

	//throw new Exception( $Site->SYS_TYPE );
	//throw new Exception($_POST['CURRCID']);
	
	$CatDef[ $_POST['CURRCID'] ]['Src'] ;
	
	//retrieve source link
	$Srclink = str_replace('/index.php','', $CatDef[ $_POST['CURRCID'] ]['Src'] );	
	$nolink= $Srclink=='' ? true : false ;
	
	//if no Srclink is retrieved, go to error page.
	if($nolink) header("Location: error");
	
	//Initialise all core classes
	$FromAjaxCall = true;

	
	if(!@include($_SERVER['DOCUMENT_ROOT'].$Srclink."/index.php") ) throw new Exception("Failed to include 'index.php'");
		

	//Set Datalogic to Ajax mode
	$Datalogic->Ajax=true;
	
	//Set respective DIR
	$Layout->HTMLFORM->DIR=$_SERVER['DOCUMENT_ROOT'].$Srclink;
	$this->Pagination_TOTAL_PG = $Layout->HTMLFORM->HtmlComponents->Pagination_TOTAL_PG;
	
	//Put objects into object
	$this->Datalogic = $Datalogic;
	$this->Layout = $Layout;

}
?>