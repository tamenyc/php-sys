<?php
class PHPMailer_TS{
	public $mailArr;
	private $mailobj;
	private $_SMTPAuth;
	public $_Server;
	
	
	 function __construct ($mailArr, PHPMailer $mailobj){
		 $this->mailArr=$mailArr;
		 $this->mailobj=$mailobj;
		 
		 //print_r($this->mailArr);
		$mystring = $_SERVER["SERVER_SOFTWARE"];
		$MS   = 'Microsoft';
		$Apache   = 'Apache';
		if(strchr($mystring, $Apache)!="") $server="Apache";
		if(strchr($mystring, $MS)!="") $server="Microsoft";
		//echo $server;
		$this->_Server=$server;
			 
		date_default_timezone_set("Asia/Singapore");
		/*
		define("DEBUG", true);
		ini_set("display_errors", "1");
		error_reporting(E_ALL^E_NOTICE);
		*/
		
	}
	
	public function sendMail($MailType="Text"){
		$mail=$this->mailobj;
		$mail_arr=$this->mailArr;
		
		try {
			

			//$body             = file_get_contents('contents.html');
			
			if($MailType=="Text"){
				$mail->IsHTML(false); // send as text
				$mail->WordWrap   = 80; // set word wrap
				$body=nl2br($mail_arr["Body"]); //insert line breaks
				

			}else{
				$mail->IsHTML(true); // send as text
				$body= preg_replace('/\\\\/','', $mail_arr["Body"]); //Strip backslashes
				$body=nl2br($mail_arr["Body"]); 
				$mail->WordWrap   = 80; // set word wrap
			}
			if(isset($mail_arr["SMTPDebug"])){
				$mail->SMTPDebug=$this->mailArr["SMTPDebug"];
			}
			$mail->IsSMTP();	// tell the class to use SMTP
			if($this->mailArr["SMTPSecure"]!=""){
				$mail->SMTPSecure = $this->mailArr["SMTPSecure"];//"tls"; 
			}
			
			$this->_SMTPAuth=isset($mail_arr["SMTPAuth"])? $mail_arr["SMTPAuth"]: false;
			if($this->_SMTPAuth) $mail->SMTPAuth   = true;	// enable SMTP authentication
			$mail->Port       = $this->mailArr["Port"];		// set the SMTP server port
			$mail->Host       = $this->mailArr["Host"];		// SMTP server
			$mail->Username   = $this->mailArr["Username"];	// SMTP server username
			$mail->Password   = $this->mailArr["Password"];	// SMTP server password

			if($this->_Server!="Microsoft"){
				if($this->mailArr["_SENDMAIL"]!="NO"){
					//NOTE THAT FOR GMAIL, YOU DO NOT USE THIS TOO, SO FOR GMAIL YOU WILL NEED TO SET _SENDMAIL TO no TOO
					$mail->IsSendmail();  // tell the class to use Sendmail; switch off for window
				}
			}

			$mail->AddReplyTo($this->mailArr["Replyto"],$this->mailArr["Replytoname"]);

			$mail->From       = $this->mailArr["From"];
			$mail->FromName   = $this->mailArr["Fromname"];

			$to = $this->mailArr["To"];

			foreach($to as $emailto){
				$mail->AddAddress($emailto);
			}

			$mail->Subject  = $this->mailArr["Subject"];

			$mail->AltBody    = "To view the message, please use an HTML compatible email viewer!"; // optional, comment out and test
			

			$mail->MsgHTML($body);
			
			
			if(isset($this->mailArr["SMTPDebug"])){
				echo "<h2>Custom Message</h2>";
				echo "Server Type: ",$this->_Server,"<br>";
				echo "<hr>";
			}
			

			$mail->Send();
			if(isset($this->mailArr["SMTPDebug"])){
				echo 'Message has been sent.';
			}
			return "true";
		} catch (phpmailerException $e) {
			if(isset($this->mailArr["SMTPDebug"])){
				echo $e->errorMessage();
			}
			
			return  "false";
		}
	}
}

?>