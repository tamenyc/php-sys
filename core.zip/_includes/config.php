<?php
session_start(); //print_r($_SESSION);
date_default_timezone_set("Asia/Singapore"); 
//*************************************************	

//GLOBAL SETTINGS

//*************************************************
$_DIR_MAPP = '/../'; // set to '/' if it's root. This is set as global in utils.php function CoreClassLoader()
$_FS_INI = $_SERVER['DOCUMENT_ROOT'].$_DIR_MAPP."_includes/core/fs_ini.php";
$_SYS_INI = $_SERVER['DOCUMENT_ROOT'].$_DIR_MAPP."_includes/core/sys_ini.php";

//*************************************************	
//DATABASE STUFFS
//*************************************************
if($_SERVER["SERVER_NAME"]=="localhost") {
	$database="ur_db_name";
	$server="127.0.0.1";
	$user = 'root';
	$password = '1234';
} else {
	$database="live_db_name";
	$server="127.0.0.1";
	$user = 'username';
	$password = 'pw';
} 
//*************************************************
//SITE CONFIGS
//*************************************************
$_CMS_STATIC = true;
$_CMS_ADMIN_STATIC = true;
$_BIS_STATIC = true;
$_BIS_ADMIN_STATIC = true;


//*************************************************
//ROUTER CONFIGS
//*************************************************
$_ROUTER_NAME['_BIS'] = 'client';
$_ROUTER_NAME['_BIS_ADMIN'] = 'admin';
$_ROUTER_NAME['_CMS_ADMIN'] = 'cms-admin';

//Router CONFIGS
//*************************************************
$_BIS['Type'] = '_BIS';
$_BIS['Router_Name'] = $_ROUTER_NAME['_BIS']; //name shown on url
$_BIS['Folder'] = "front";
$_BIS['LoginSrc'] = "/front/modules/login/index.php";
$_BIS['HomeURL'] = "/client/home/";
$_BIS['HomeSrc'] = "/front/modules/home/index.php";
		
$_BIS['NonLoginCustom'] ["new-account"] = "/front/modules/account/create/index.php";
$_BIS['NonLoginCustom'] ["forgot-password"] = "/front/modules/account/password_reset/index.php";
		
$_BIS['LoginCustom'] ["tamesoft"] = "/front/modules/dev2/index.php";



$_BIS_ADMIN['Type'] = '_BIS_ADMIN';
$_BIS_ADMIN['Router_Name'] = $_ROUTER_NAME['_BIS_ADMIN']; //name shown on url
$_BIS_ADMIN['Folder'] = "admin";
$_BIS_ADMIN['LoginSrc'] = "/admin/modules/login/index.php";
$_BIS_ADMIN['HomeURL'] = "/admin/home/";
$_BIS_ADMIN['HomeSrc'] = "/admin/modules/home/index.php";
		
$_BIS_ADMIN['NonLoginCustom'] ["new-account"] = "/admin/modules/account/create/index.php";
$_BIS_ADMIN['NonLoginCustom'] ["forgot-password"] = "/admin/modules/account/password_reset/index.php";
		
$_BIS_ADMIN['LoginCustom'] ["tamesoft"] = "/admin/modules/dev2/index.php";


//HOST RELATED
//*************************************************
$_HOST = '';
$_REST = false;
$_GLOBAL_SSL = false;

//_MAIL_TEST
//*************************************************
$_MAIL_TEST['Username'] = 'name@example.com';
$_MAIL_TEST['Password'] = 'yourpassword';
$_MAIL_TEST['Replyto'] = 'name@example.com';
$_MAIL_TEST['Replytoname'] = 'name@example.com';
$_MAIL_TEST['From'] = 'name@example.com';
$_MAIL_TEST['Fromname'] = 'name@example.com';
$_MAIL_TEST['To'] = array('name@example.com');
//$_MAIL_TEST['Body'] = 'Hi,<br>This is a test email.<br>';
//$_MAIL_TEST['Subject'] = 'Test Mail Subject';
$_MAIL_TEST['Host'] = 'smtp.gmail.com';
$_MAIL_TEST['Port'] = '587';
$_MAIL_TEST['SMTPAuth'] = true;
$_MAIL_TEST['SMTPDebug'] = '2';
$_MAIL_TEST['SMTPSecure'] = 'tls';
$_MAIL_TEST['_SENDMAIL'] = 'NO'; //std anws: NO

//_MAIL_ADMIN
//*************************************************
$_MAIL_ADMIN['Username'] = 'name@example.com';
$_MAIL_ADMIN['Password'] = 'yourpassword';
$_MAIL_ADMIN['Replyto'] = 'name@example.com';
$_MAIL_ADMIN['Replytoname'] = 'name@example.com';
$_MAIL_ADMIN['From'] = 'name@example.com';
$_MAIL_ADMIN['Fromname'] = 'name@example.com';
$_MAIL_ADMIN['To'] = array('name@example.com');
//$_MAIL_ADMIN['Body'] = 'Hi,<br>This is a test email.<br>';
//$_MAIL_ADMIN['Subject'] = 'Test Mail Subject';
$_MAIL_ADMIN['Host'] = 'smtp.gmail.com';
$_MAIL_ADMIN['Port'] = '587';
$_MAIL_ADMIN['SMTPAuth'] = true;
$_MAIL_ADMIN['SMTPDebug'] = '2';
$_MAIL_ADMIN['SMTPSecure'] = 'tls';
$_MAIL_ADMIN['_SENDMAIL'] = 'NO'; //std anws: NO

//_MAIL
//*************************************************
$_MAIL[0]['Username'] = 'name@example.com';
$_MAIL[0]['Password'] = 'yourpassword';
$_MAIL[0]['Replyto'] = 'do-not-reply@lhnparking.com.sg';
$_MAIL[0]['Replytoname'] = 'do-not-reply';
$_MAIL[0]['From'] = 'name@example.com';
$_MAIL[0]['Fromname'] = 'LHN System';
$_MAIL[0]['To'] = array('name@example.com');
//$_MAIL[0]['Body'] = 'Hi,<br>This is a test email.<br>';
//$_MAIL[0]['Subject'] = 'Test Mail Subject';
$_MAIL[0]['Host'] = 'smtp.gmail.com';
$_MAIL[0]['Port'] = '587';
$_MAIL[0]['SMTPAuth'] = true;
$_MAIL[0]['SMTPDebug'] = '2';
$_MAIL[0]['SMTPSecure'] = 'tls';
$_MAIL[0]['_SENDMAIL'] = 'NO'; //std anws: NO











//NOTES:
// Good reference for PDO: http://wiki.hashphp.org/PDO_Tutorial_for_MySQL_Developers
?>