(function($){
	
	$.fn.test = function( options ) {
		
		var opts = $.extend( {}, $.fn.test.defaults, options );
		
		// Iterate and reformat each matched element.
		return this.each(function() {
	 
			var elem = $( this );
	 
			// ...
	 
			var markup = elem.html();
	 
			// Call our format function.
			markup = $.fn.test.format( markup );
	 
			elem.html( markup );
	 
		});
		
		/*
		return settings.hello().this.css({
            color: settings.color,
            backgroundColor: settings.backgroundColor
        });
		*/		
	};	
	
	$.fn.test.defaults = {
		color: "#556b2f",
        backgroundColor: "pink",

	};
	
	$.fn.test.format = function( txt ) {
		//alert(txt);
		return "<strong>" + txt + "</strong>";
	};
	
	/*************************************************/
	//System INI
	/************************************************/	
	$.fn.systemINI = function ( options ){

		//curl = $(this).page({get: 'curl'}); alert(curl);
		var data_ajax = 'false';
		data_ajax = $('body').attr('data-ajax'); //console.log(data_ajax);
		
		//disable link
		if(data_ajax===true){
			$(this).systemINI.targets_preventDefault();
		}
		//$(this).systemINI.grab_FSID();
		
		$(this).sys_ui();
		$(this).pagination();
		$(this).form_filter(); 	
		//console.log('fn.systemINI');
		
		if(data_ajax===true) $(this).ajax();
		//var allListElements = $( "input, select" );
		//$('._PAGIN_MARKER').find( allListElements ).css({'background':'red'});
	}
	$.fn.systemINI.targets_preventDefault = function (){
				
		//disable link
		$('ul.pagination li a, ._FSORT a, input[name="_GOTO"]').on("click", function(e){
				e.preventDefault();
		});	
		
				
	}
	$.fn.systemINI.grab_FSID = function (){

		$('ul.pagination li a, ._FSORT a, input, select').on("click", function(){
			//var test = $(this).val();
			var FSID = $.fn.utils.get_FSID ( $(this) );
			alert('RETRIEVE VALUE = '+FSID);
		});	
		//alert(FSID);
		//return FSID;
		
	}
	/*************************************************/
	//form filter related operations
	/************************************************/
	$.fn.form_filter = function ( options ){
		$.fn.form_filter.process_request_url();
	}
	
	//removes empty $_GET request
	$.fn.form_filter.process_request_url = function (){
		var value, name;
		$('input[name=_SUBMIT_FILTER]').on('click',function(event){
			$(this).attr('name',''); // prevents the button from being appended to $_GET string request
			$('._FORM_FILTERS').each(function(){
				value = $(this).val(); 
				//alert(value);
				
				//removes empy $_GET request from url
				if(value==''){
					$(this).attr('name','');
				}

			});
		});
	}
	
	/*************************************************/
	//pagination url redirect submission
	/************************************************/
	$.fn.pagination = function ( options ){
		
		var allListElements = $( "input, select" );
			
		if( $('input[name=_GOTO]').length){
			
			//check and mark out changed input fields
			//event trigger type is change
			$('._PAGIN_MARKER').find( allListElements ).validate({ check_type: 'change' });
			//$('._PAGIN_MARKER').css({'color':'red'});
			
			$('._GOTO').on("blur", function(){
				var pageNo = $(this).val();
				test_len = $.fn.validate.count_input_changed(); //count the number of changed input fields
				
				if(test_len>0){
					//alert('changed, do not proceed');
					$.fn.utils.dialog_box('Please submit changes before proceeding to next page.');
					//$(this).prop( "disabled", true );
				} else {
					//alert('ok, procced');				
					//$.fn.pagination.process_pagin_req( pageNo );								
				}
				
			});
			
			$('._PAGINATION a, ._FSORT a').on("click",function( event ){
				test_len = $.fn.validate.count_input_changed(); //count the number of changed input fields
				if(test_len>0){
					event.preventDefault();
					$.fn.utils.dialog_box('Please submit changes before proceeding to next page.');
				} 
												
			});
		} 

	}
	//check if page is invalid
	$.fn.pagination.is_valid_page = function (){

		var page = $.fn.pagination.get_page_no(); //$('.clearfix').append('page='+page+'<br>');
		//alert($('._PAGINATION_TOTAL').attr('data-pagination-total-result'));
		
		if( $('._PAGINATION_TOTAL').attr('data-pagination-total-result')>0 || page==1 || page===false){
			//there are results when page=.. is > 0 and there is pagination element.
			//$('.clearfix').append('harlow...have results<br>');
			
		} else {
			//there no results to display, hence redirect to prev page
			//$('.clearfix').append('harlow...No results<br>');
			var curl = $(this).page({get:'curl'});//.split('?',1); //$('.clearfix').append(curl);
			page = Number (page) -1 ; //redirects back to prev page.
			var pageStr = page< 0 ? '' : "page="+page; //prevents negative page number
			var url = curl.replace(/(page=)([0-9]+)/g, pageStr); //$('.clearfix').append(url);
			window.location.href = url;
		}

	}
	
	//get current page number
	$.fn.pagination.get_page_no = function (){
		
		var page = false;
		var curl_string_params = $.fn.page({get:'curl_string_params'}); //$('.clearfix').append(curl_string_params+'<br>');
		var patt = /(page=)([0-9]+)/g;  
		var str = curl_string_params ;//'lalala=1&page=1000&lala=haha&page=4';
		//remove repeated param
		str = $.fn.page.process_URL_PARAMS  ( str, 'str_url' ); //$('.clearfix').append('str='+str);
				 
		var matches = $.fn.utils.parse_regex(str , patt); 
		
		//$('.clearfix').append(matches.toString());
		//$('.clearfix').append(matches[2]);	
		if (Array.isArray(matches)) var page = matches[2];	
		
		return page;
	}
	
	//process pagination request
	$.fn.pagination.process_pagin_req = function ( pageNo, AJAX ){
		
		if(AJAX) {
			//alert(AJAX);
		} else {
			AJAX = false;
		}
		
		curl = $(this).page({get:'curl'}).split('?',1); //alert(curl);
		curl_string_params = $(this).page({get:'curl_string_params'}); //alert(curl_string_params);
		currPARAM = $.fn.page.process_URL_PARAMS( curl_string_params , 'str_url' ); //alert(currPARAM);
		url = '';
		var currPARAM_url;
					 
		if(pageNo!='' && $.isNumeric(pageNo)) {
			//alert(pageNo);
						   
			currPARAM_url = currPARAM+'&page='+pageNo;
			//alert(currPARAM_url);
			//CLEAN UP AND REMOVE REPEATED STRING URL
			param_url = $.fn.page.process_URL_PARAMS( currPARAM_url , 'str_url' );  //alert(param_url);
						
			//form new url
			url = curl+'?'+param_url;
			//do redirect
			if(AJAX===false) {
				window.location.href = url;
			} 
			
		} else {
			$(this).val('');
		}	
		
		return url;
	}
	//Updates pagination li
	$.fn.pagination.update_li =function (page){
			$('ul.pagination li').each( function(){ 
			//alert(page);
						
				var li_value = $(this).children().attr('data-pagin'); //alert( li_value );
				var li_class = $(this).attr('class');
						
				if( li_class!='_PAGINATION_BTN'){
					if(page==li_value){
						$(this).attr('class','active');
					} else {
						$(this).removeClass();
					}						
				}

						
			});
	}
	/*************************************************/
	//page
	/************************************************/
	$.fn.page = function ( options ){
		
		var 
			curl = window.location.href,
			curl_string_params = decodeURIComponent(window.location.search.substring(1)),
			curl_string_params_variables = curl_string_params.split('&')
		;
		
		var settings = $.extend( {}, $.fn.page.defaults, options );

		switch( settings.get ){
			case 'curl':
				return curl; 
			break;
			
			case 'curl_string_params':
				return curl_string_params; 
			break;
			
			case 'curl_string_params_variables':
				return curl_string_params_variables;
			break;
		}
			
	}
	
	$.fn.page.defaults = {
		get : "curl",
	};
	
	//process and return url string  in url string / array format, repeated strings are removed
	$.fn.page.process_URL_PARAMS = function ( str_params, type , debug ){
		
		var str_params_variables = str_params.split('&');
		
		if(debug===true) alert(str_params_variables);
			var 
				sParams = new Array(),
				i,
				skey
			;
				
			for (i = 0; i < str_params_variables.length; i++) { 
				skey = str_params_variables[i].split('=');
				//alert(skey[0]);
				if(skey[0] in sParams) {
					//url param key already in array
					sParams[skey[0]]=skey[1];
				} else {
					//url param key not in array=>new array() 
					sParams.push( skey[0]); //alert(skey[0]);
					sParams.splice(0,1); 
					sParams[skey[0]] = new Array( skey[1]  ); //alert(sParams[ skey[0] ]+'--'+skey[1]);
				}
				
			}
			//alert(sParams);
			if(type==='array') return sParams;
			
			if(type==='str_url'){
				var 				
					url_str='',
					temp,
					strSep=''
				;
				
				for (var key in sParams) { //alert(key);
					 if ( sParams.hasOwnProperty(key) && key!=0 ) {
						temp = key+"="+sParams[key];
						//alert(temp);	
						url_str = url_str+strSep+temp;
						strSep ='&';
					 }				
				}
				if(debug===true) alert(url_str);
				return url_str;		
			}
	};
	
	$.fn.page.remove_pagination_QUERY_PARAMS = function ( url ){
		//url = "/?page=5&la=huh";
		var pattern = new RegExp( /&page=[0-9]/g);
		var pattern2 = new RegExp( /page=[0-9]/g);
		var pattern3 = new RegExp( /\?\&/g);
		var pattern4 = new RegExp( /\?\?/g);
		var res = pattern.test(url);
		//alert(res);
			
		//replace pattern 1
		new_url = url.replace(pattern, '');
		new_url = new_url.replace(pattern2, '');
		new_url = new_url.replace(pattern3, '?');
		new_url = new_url.replace(pattern4, '?');
		//alert(new_url);
		
		return new_url;
	}
	
	$.fn.page.process_ADD_QUERY_PARAMS = function ( query_param, query_param_val ){
		
		curl = $(this).page({get:'curl'}).split('?',1); //alert(curl);		
		curl_string_params = $(this).page({get:'curl_string_params'}); //alert(curl_string_params);
		
		currPARAM = $.fn.page.process_URL_PARAMS( curl_string_params , 'str_url' ); //alert(currPARAM);
		url = '';
		var currPARAM_url = currPARAM+'&'+query_param+'='+query_param_val;
		
		param_url = $.fn.page.process_URL_PARAMS( currPARAM_url , 'str_url' );  //alert(param_url);
						
		//form new url
		url = curl+'?'+param_url; //alert(url);
		
		return url;
	}
	//This is used as a skeleton function for handling events...
	//$.fn.event_handler_boilerplate = function ( Mode='on'){
	$.fn.event_handler_boilerplate = function ( Mode){
		
		if(Mode=='') Mode='on';
		
		switch(Mode) {
			
			case 'on':
				$('th').on("click", $.fn.testfunc); console.log('on');
				break;
			case 'off':
				$('th').off("click", $.fn.testfunc); console.log('off');
				break;
			default:
				alert('fatal error');
		} 

	}

	$.fn.testfunc = function (){
		console.log('testfunc');
	}
	
	/*************************************************/
	//AJAX
	/************************************************/
	$.fn.ajax = function ( options ){
		//console.log('ajax');
		//$.fn.event_handler_boilerplate('on');
		$('input[name="_GOTO"]').on("change", $.fn.ajax.pagination );
		$("ul.pagination li a").on("click", $.fn.ajax.pagination );
		$('._FORM_FILTERS').on("change", $.fn.ajax.form_filters );
		$('._FSORT a').on("click", $.fn.ajax.fsort );	
		
		$('._AJAX ._AJAX_U').on("change", $.fn.ajax.datalogic_update );
		//$('._AJAX ._AJAX_A').on("change", $.fn.ajax.datalogic_add-kiv );
		$('._AJAX_ADD').on("click", $.fn.ajax.datalogic_add );
		$('._AJAX_ADD_N').on("click", $.fn.ajax.datalogic_add_nested );
		$('._AJAX_DEL').on("click", $.fn.ajax.datalogic_delete );
		//$('input[type="checkbox"]._DYN_DELETE').on("click", $.fn.ajax.update_chked_history);
		$('._DYN_DELETE').on("click", $.fn.ajax.update_chked_history);
		
		$('._AJAX_MODAL_ADD').on("click", $.fn.ajax.modal_add );
		
		$(this).ajax.append_ajax_loader();
		//console.log('fn.ajax.ajax_loader');
		$.fn.ajax.ajax_loader();
		
		return this;
	}
	$.fn.ajax.tester = function (){
		console.log('tester');
	}
	//AJAX Loader
	$.fn.ajax.ajax_loader = function (){
		
		var loader = $('._AJAX_LOADER').hide();
		var Disabled_Elements = $('.form-control, select');
		
		$(document)
		  .ajaxStart(function () {			
			//console.log('ajax_loader.ajaxStart');
			//Show ajax loader
			loader.show();
			//console.log('ajax start');
			//Disable form filters
			//Disaable form filters
			Disabled_Elements.prop( "disabled", true ); //'._FORM_FILTERS, 
			
		  })
		  .ajaxSuccess(function() {
			  //console.log('ajax success');
			  //console.log('ajax_loader-->ajaxSuccess');

		  })
		  .ajaxSend(function(e, xhr, opt) {
			//console.log('ajax send');
			//console.log('ajax_loader-->START!!!'+e+xhr+JSON.stringify(opt));
			//console.log('ajax_loader-->START!!!'+JSON.stringify(opt.data));
		  })
		  .ajaxStop(function () {
			// console.log('ajax stop');
			/*****************************************/
			//This is a jquery method to trigger methods when ajax has stopped loading
			/***********************************/
			//console.log('ajax_loader-->ajaxStop');
			//Remove ajax loader
			loader.hide();
			$.fn.pagination.is_valid_page();
			
			//Enable form filters
			Disabled_Elements.prop( "disabled", false );
			//preventDefault
			$(this).systemINI.targets_preventDefault();
			
			//Reinstantiate jquery ui				

			//IMPORTANT!! DETTACH EVENTS TO PREVENT OVERATTACHING EVENTS
			
			$("._GOTO").off("change", $.fn.ajax.pagination );
			$("ul.pagination li a").off("click", $.fn.ajax.pagination );
			$('._FORM_FILTERS').off("change", $.fn.ajax.form_filters );
			$('._FSORT a').off("click", $.fn.ajax.fsort );	
			$('._AJAX ._AJAX_U').off("change", $.fn.ajax.datalogic_update );
			//$('._AJAX ._AJAX_A').off("change", $.fn.ajax.datalogic_add-kiv );
			$('._AJAX_ADD').off("click", $.fn.ajax.datalogic_add );
			$('._AJAX_ADD_N').off("click", $.fn.ajax.datalogic_add_nested );
			$('._AJAX_DEL').off("click", $.fn.ajax.datalogic_delete );

			//$('input[type="checkbox"]._DYN_DELETE').off("click", $.fn.ajax.update_chked_history);
			$('._DYN_DELETE').off("click", $.fn.ajax.update_chked_history);
			
			$('._AJAX_MODAL_ADD').off("click", $.fn.ajax.modal_add );
			//$.fn.event_handler_boilerplate('off');	
			$.fn.sys_ui.destroy();
			//REINITIALISE..
			//console.log('ajax_loader-->REINITIALISE');
			$(this).ajax();
			$(this).sys_ui();
									
			// IMPORTANT!!! THIS IS NEEDED TO PREVENT OVERATTACHNG ajax_loader. 
			$(this).off();
			//console.log('ajax_loader-->OFF');

			
			
			
			
		  });	
		
			
	}
	//AJAX Loader Custom
	$.fn.ajax.ajax_loader_custom = function ( selectors , trigger_event , methodcall){
		$(document)
		.ready(function(){	
			$(selectors).off( trigger_event, methodcall); 
			$(selectors).on(trigger_event, methodcall);
		})
		.ajaxStart(function () {
			//$('body').css({'background-color':'blue'});
		})
		.ajaxStop(function () {
			$(this).ajax();
			$(selectors).off(trigger_event, methodcall );
			$(selectors).on(trigger_event, methodcall);
			
		})
		
	}
	
	//AJAX Boilerplate
	//$.fn.ajax.ajax_form_boiler_plate = function( Element, UrlLink ,Post_Data='' , Ajax_Action='', Post_Add_Data=''){ 
	$.fn.ajax.ajax_form_boiler_plate = function( Element, UrlLink ,Post_Data , Ajax_Action, Post_Add_Data){ 
	
	
	//console.log('ajax_form_boiler_plate');
		//console.log(UrlLink);		
		//RETRIEVE VALUES
		var CURRCID = $('input[name="CURRCID"]').val();
		var FSID = $.fn.utils.get_FSID( Element ); 
		
		$(this).find( 'input' ).validate({ check_type: 'change' });

		var AJAXID = $.fn.utils.form_UniqueAJAXID( FSID ); //alert('AJAXID='+AJAXID);
		var AJAX_ID = $("#"+AJAXID); //AJAX_ID.append('Hello'+AJAXID);
		

		
		//Retrieve Post_Chked from html
		var Post_Chked =[];
		Post_Chked = $.fn.ajax.get_dyn_chk_data(); //$('.clearfix').append(Post_Chked);
		
		if(Post_Chked.length>0){
			Post_Chked = JSON.stringify(Post_Chked) ;
			//$('.clearfix').append(Post_Chked+'<br>');
		}
		//Retrieve Chked_Hist from html with stated FSID
		var Chked_Hist = $("input[name='_CHK_HISTORY["+FSID+"]']").val();
		
		//Clear HTML stored constant of representative FSID
		$.fn.ajax.clear_form_constant( $(this) ,FSID ,Ajax_Action ); //console.log(Ajax_Action);

		//console.log(Post_Data);
		
		$.ajax({
				method: "POST",
				url: "_ajax", 
				dataType: "json",
				cache: true,
				data: { AJAXID: AJAXID ,FSID: FSID, CURRCID: CURRCID , UrlLink: UrlLink , Post_Data : Post_Data,Post_Chked: Post_Chked, Ajax_Action: Ajax_Action , Chked_Hist : Chked_Hist, Post_Add_Data: Post_Add_Data},
				success: function( response ){
					
					//Use this to demo the negative effects of multiple attaching of methods
					//$(window).on("click", function(){ alert('h'); } );
					//console.log('success');

					if(Ajax_Action=='_AJAX_ADD'){
						//****NON NESTED DATA AJAX ADD
							//Do not append back the ajax result
							//If append, it will append back the empty form field (_FN[a.1a][name.#0]) and lastinsertID result _FN[a.1a.434][name.#0]
							//The later happens during php's ajax calling _FORM_RETRIEVE_MAIN() again
						AJAX_ID.html(response.Body);
						if( response.Error==='') {							
							$('._AJAX_A').val('');
						}						
						
					} else {
						AJAX_ID.html(response.Body);//.append('Hello');
					}
					
					
					
					//Clear _CHK_HISTORY
					if(Ajax_Action=='_AJAX_DEL') $("input[name='_CHK_HISTORY["+FSID+"]']").val('');
				
					//alert(response.Error);								
					if(response.Error!=''){
						//alert(response.Error);	
						AJAX_ID.prepend('<div>'+response.Error+'</div>');					
					} 

				},
				beforeSend: function (){
					//console.log('beforeSend');
				},
				error: function( jqXHR, textStatus, errorThrown ){
					AJAX_ID.text('Error: '+textStatus+errorThrown); 
					//alert(textStatus);	
					//$('._PAGINATION').css({'display':'none'});
				}
			});				

				
	}
	
	//Append Ajax Loader
	$.fn.ajax.append_ajax_loader = function (){

		$('#AJAX_LOADER').detach();
		var $div = $('<div />').appendTo('body');
		$div.attr('id', 'AJAX_LOADER');
		$('#AJAX_LOADER').addClass('_AJAX_LOADER');
		$('#AJAX_LOADER').html('<span class="_AJAX_LOADER_ICON_LOADING"></span><h1>Loading</h1>');
		//<span class="_AJAX_LOADER_ICON_LOADING"></span><h1>Loading</h1>

		
	}

	//AJAX PROCESS DATALOGIC
	//THis method is the control logics for deciding which ajax operation to perform. (Delete, Update)
	$.fn.ajax.modal_add = function(){
		//console.log('modal add');
		var UrlLink = $(this).page({get:'curl'});
		var fsid = $.fn.utils.get_FSID ($(this) ); //console.log(fsid);
	}
	$.fn.ajax.datalogic_update = function (){ 
		//console.log('update');
		var UrlLink = $(this).page({get:'curl'});
		var name = $(this).attr('name');  //$('.clearfix').append(name);	
		var value = $(this).val(); //$('.clearfix').append(value);
		var fsid = $.fn.utils.get_FSID ($(this) ); //$('.clearfix').append('fsid='+fsid);
		/************************************************************/
		// Scan for data for updating
		//************************************************************/
		var post_data=[];
		var ini_val = $("input[name='_POST_DATA_HISTORY["+fsid+"]']").val();
		
		if(ini_val.length>0){
			/* Comment off for Diagnostic purposes only */
			/*
			$('.clearfix').append('<hr>');

			JSON.parse( ini_val , function( k, v) {
			  if ( k!=='' ) { 
				 if(typeof v == 'string'){
					 $('.clearfix').append('k='+k+' v= '+v+'<br>');
					 //post_data.push( { "name": name , "value": value } );
				 } 
				 if(typeof v == 'object'){
					$('.clearfix').append('K----->'+k+'<br>');
				 }
			  }			  			  
			}); 
			*/
		} else {
			//$.fn.output_test('<b>ini_val==0, PUSH</b>::'+name+' value=>'+value+' curr value=>'+value+'<br>', false);
			post_data.push( { name: name , value: value } );
		}

		function update_arr(item, index) {
			if(item.name===name && item.value!=value){
				//$.fn.output_test('<b>'+index+' UPDATE</b><br>item.name=>'+item.name+'<Br>item.value=>'+item.value+'<br>');
				//$.fn.output_test('<h3>Update</h3>'+name+'--'+value);
				//update
				item.value = value;
				return item;
			} else {
				return false;
			}
		}

		if(ini_val.length>0) {
			post_data = JSON.parse(ini_val);

			if( typeof post_data.find(update_arr)=== 'undefined' ){
				//$.fn.output_test('<h3>Push</h3>'+name+'--'+value);
				post_data.push( { name: name , value: value } );
			};

		}

		//retrieve and form post_data
				
		post_data = JSON.stringify(post_data);
		$("input[name='_POST_DATA_HISTORY["+fsid+"]']").val(post_data);
		//$('.clearfix').html('<h2>post data</h2>'+post_data+'<hr>');	
		//$.fn.output_test('<h2>post data</h2>'+post_data+'<hr>', true, 'html');		
		

		/************************************************************/
		// UPDATE
		//************************************************************/
		$.fn.ajax.ajax_form_boiler_plate( $(this), UrlLink , post_data );	

	}

	$.fn.ajax.datalogic_add = function (){ 
		//console.log('datalogic_add');
		var UrlLink = $(this).page({get:'curl'});
		var name, fsid, value, post_add_data=[] ;
		fsid = $.fn.utils.get_FSID( $(this) ); //$('.clearfix').append(fsid);

		// Scan for non nested data for adding
		$('._AJAX_A').each(function(i){ 
		
			name = $(this).attr('name'); //$('.clearfix').append(name);
			fsid = $.fn.utils.get_FSID_from_input( name ); //$('.clearfix').append(fsid);
			value = $(this).val(); //$('.clearfix').append(name);
			post_add_data.push( { "name": name , "value": value } ); // push into array[i] = ....
			//NOTE: json_decode($_POST['Post_Add_Data'], true) --> in php json_decode need to set to true if array is associative.
		});

		post_add_data = JSON.stringify(post_add_data); //$.fn.output_test(post_add_data);		
		//console.log(post_add_data);

		$.fn.ajax.ajax_form_boiler_plate( $(this), UrlLink , '', '_AJAX_ADD', post_add_data );	

	}
	
	$.fn.ajax.datalogic_add_nested = function (){ 
		$.fn.output_test('NESTED ARRAY ADD');	
		var UrlLink = $(this).page({get:'curl'});
		var name = $(this).attr('name');  
		/************************************************************/
		// Scan for data for updating
		//************************************************************/
		var post_data=[];
		var value = $(this).val(); //$('.clearfix').append(value);	
		
		/************************************************************/
		// ADD NESTED
		//************************************************************/
		//$.fn.ajax.ajax_form_boiler_plate( $(this), UrlLink , post_data );	

	}	

	$.fn.ajax.datalogic_delete = function (){ 
		var _logic_type = $.fn.ajax.get_logic_type( $(this) );
		//alert('delete');
		if(_logic_type=='AJAX_DEL'){
			var UrlLink = $(this).page({get:'curl'});
			post_data ='';	
			$.fn.ajax.ajax_form_boiler_plate( $(this), UrlLink , post_data ,'_AJAX_DEL');			
		}


	}
	
	$.fn.ajax.get_logic_type = function ( Elem ){
		/*************************************************************/
		//Determine any dashboard action.
		//Egs of dashboard action: _AJAX_DEL
		//Potential actions : _AJAX_EXPORT_CSV, _AJAX_PRINT_PDF ... 
		/*************************************************************/
		var _logic_type = false ;
		var _fsid_index = $.fn.utils.get_FSID_index_from_input(name);
		var _change = $.fn.utils.check_input_change(Elem);
		var _dashboard_action = $.fn.ajax.get_dashboard_action_type( Elem ); //$('.clearfix').append('_dashboard_action='+_dashboard_action);
		var _CHKED =[];
		_CHKED = $.fn.ajax.get_dyn_chk_data(); //$('.clearfix').append(_CHKED);
		//$('.clearfix').append('_CHKED='+_CHKED+' _CHKED.length='+_CHKED.length);
		
		/**********************************************/
		//Event EXEMPTED from triggering datalogic actions
		/**********************************************/
		var _do_datalogic = true;
		if( Elem.hasClass('_FORM_FILTERS') ) {
			_do_datalogic = false;
		}
		if( Elem.hasClass('_GOTO') ) {
			_do_datalogic = false;
		}	

		//DELETE
		/*****************************************************************/			
		//1) There must be _CHKED checkboxes containing information about which item to delete.
		//2) _do_datalogic=>not triggered by form search, filters.	
		if( _dashboard_action == '_AJAX_DEL' && _CHKED.length>0 && _do_datalogic===true ) _logic_type = 'AJAX_DEL';
		
		//UPDATE
		/*****************************************************************/
		//1) change === true = >There must be change in form input values
		//2) _fsid_index!==null => Must have fsid_index to do db update
		//3) Do_Datalogic=>not triggered by form search, filters.	
		if( _dashboard_action == false && _change === true && _fsid_index!==null && _do_datalogic===true ) _logic_type = 'AJAX_UPDATE';
		
		
		
		//$('.clearfix').append(_logic_type);
		return _logic_type;
		
	}
	$.fn.ajax.clear_form_constant = function ( Elem , FSID, AJAX_ACTION ){
		//$.fn.output_test('Clear constant');
		var haveUpdate, haveAdd, haveDelete;
		//RETRIEVE VALUES
		if( $.fn.utils.haveRights('update', FSID)){
			//console.log('have update');
			haveUpdate = true;
		};
		
		//PERFORM CLEAR
		if(AJAX_ACTION=='_AJAX_PAGINATION' &&  haveUpdate ){
			//console.log('Clear _POST_DATA_HISTORY');
			//Form constant will not remember Post_Data once user goes to another page. Post_Data is used for storing update values.
			$("input[name='_POST_DATA_HISTORY["+FSID+"]']").val('');
		}
		
		
	}
	$.fn.ajax.get_dyn_chk_data = function (){
		
		var _chkbox_type = $.fn.ajax.get_dyn_chkbx_type();
		var _ARR=[];
		var _CHECKBOX = $( "._DYN_CHKBOX_LABEL input[type='checkbox']" );
			
		if( _chkbox_type=='_CHKED' ) {			
					
			_CHECKBOX.prop( "checked", function( i, val ) {
				
				//$('.clearfix').append(i+' '+val+'----');
				//if checked, val is true
				if(val){
						
					var _attr_name = $(this).attr('name');
					//$('.clearfix').append( _del_name );

					//returns eg. a.1a.157
					var _chked_fsid = $.fn.utils.get_CHKED_input_info( _attr_name );
					//$('.clearfix').append( _del_fsid );
					_ARR.push(_chked_fsid);						

				}
					
			});			
		}

		//$('.clearfix').append( '<br>_ARR'+_ARR );	
		
		return _ARR;
	}

	
	$.fn.ajax.get_dashboard_action_type = function ( elem ){
		var _ajax_act_type = false;
		
		if( elem.hasClass('_AJAX_DEL') ) _ajax_act_type = '_AJAX_DEL';
		
		
		return _ajax_act_type;
	}
	
	$.fn.ajax.get_dyn_chkbx_type = function (){

		var _chkbox_tye = false;
		var _checkbox = $( "._DYN_CHKBOX_LABEL input[type='checkbox']" );
		var _attr_name = _checkbox.attr('name');
		
		//if( RegExp("_DELE").test(_attr_name) === true) _chkbox_tye = '_DELE'; 
		if( RegExp("_CHKED").test(_attr_name) === true) _chkbox_tye = '_CHKED'; 
			
		//$('.clearfix').append( _chkbox_tye );	
		return _chkbox_tye;
	}
	
	$.fn.ajax.update_chked_history = function(){

		//There is an hidden field input[name='_CHK_HISTORY["+fsid+"]'] storing json string of checked element.
		//This method works by pulling the value from this element.
		//Scans the current updated checked values and update to this hidden field.

		var name = $(this).attr("name"); //$('.clearfix').append('name'+name);
		var fsid = $.fn.utils.get_FSID( $(this) ); //$('.clearfix').append('fsid'+fsid);
		var chk_history_elem = $("input[name='_CHK_HISTORY["+fsid+"]']");
		var checkedID = $.fn.utils.get_CHKED_input_info( name );
		//$('.clearfix').append( checkedID );
		var _CHK_HISTORY_VAL = chk_history_elem.val(); //$('.clearfix').append('_CHK_HISTORY_VAL'+_CHK_HISTORY_VAL+'<br>' );
		
		var _CHK_HISTORY =[];
		if(_CHK_HISTORY_VAL!== undefined){
			if(_CHK_HISTORY_VAL.length>0){
				//$('.clearfix').append( 'has value' );
				_CHK_HISTORY =JSON.parse(_CHK_HISTORY_VAL);
				var n = _CHK_HISTORY.indexOf( checkedID ); 
				
				//var _curr_pg_chked = $.fn.ajax.get_dyn_chk_data(); $('.clearfix').html( '<br>'+_curr_pg_chked+'<br>' );
				// n = -1 implies not found in array
				if(n<0) {
					//NOT IN _CHK_HISTORY[], thus add to array using .push()
					$(this).prop( "checked", function( i, val ) {
						if(val) _CHK_HISTORY.push( checkedID );
					});
					
				} else {
					//IN _CHK_HISTORY, remove if unchecked
					$(this).prop( "checked", function( i, val ) {
						if(!val) {
							//fsid is in _CHK_HISTORY[] and is unchecked, thus remove from array
							//$('.clearfix').html('<br>'+n+'<br>');
							//Do remove at nth position, 1 element
							_CHK_HISTORY.splice(n, 1); 
						}
					});
					
				}
			} else {
				//Empty array=>fresh form.
				//$('.clearfix').append( 'no value<br>' );			
				_CHK_HISTORY.push( checkedID );
				//$('.clearfix').append( _CHK_HISTORY+'<br>' );
			}			
		}


		
		//$('.clearfix').html( '<br>'+_CHK_HISTORY );
		
		var _CHK_HISTORY_JSON = JSON.stringify( _CHK_HISTORY );
		//Update  finalized json value
		chk_history_elem.val(_CHK_HISTORY_JSON);
	}
	
	//AJAX Form Filters
	$.fn.ajax.form_filters = function (){
			
		var name =$(this).attr("Name"); 
		var value =$(this).val(); 
		var UrlLink = $.fn.page.process_ADD_QUERY_PARAMS(name,value);
			
		UrlLink = $.fn.page.remove_pagination_QUERY_PARAMS ( UrlLink );
		
		//Check illegal string input
		var Error = $.fn.utils.check_illegal_input ( $(this), UrlLink );
		
		if(Error===false){
			//update browser url without reloading
			window.history.pushState("object or string", "Title", UrlLink);
			//Reset pagination active to page 1
			$.fn.pagination.update_li('1');
			//ajax actions
			$.fn.ajax.ajax_form_boiler_plate($(this),UrlLink);			
		}

		
	}
	//AJAX FSORT
	$.fn.ajax.fsort = function (){
		var UrlLink = $(this).attr("href"); 
		
		//Check illegal string input
		var Error = $.fn.utils.check_illegal_input ( $(this), UrlLink );
		
		if(Error===false){
			//update browser url without reloading
			window.history.pushState("object or string", "Title", UrlLink);	
			$.fn.ajax.ajax_form_boiler_plate($(this),UrlLink);
		}
		
	}

	//AJAX Pagination
	$.fn.ajax.pagination = function (){
		//FOR ._GOTO
		//alert($(this).attr("class"));
		var name =$(this).attr("Name"); 
		var page =$(this).val(); //alert(page); 
					
		//FOR ul.pagination li a
		var data_pagin = $(this).attr('data-pagin'); //alert(data_pagin);
		if(data_pagin) {
			//assign page number
			page = data_pagin; //alert(data_pagin);							
		}
		//alert(page); 			
		//Updates pagination li
		$.fn.pagination.update_li(page);					
		//Form new url
		var UrlLink = $.fn.pagination.process_pagin_req(page,true); //alert(UrlLink); 	
		
		//Check illegal string input
		var Error = $.fn.utils.check_illegal_input ( $(this), UrlLink );
		
		if(Error===false){
			//update browser url without reloading
			window.history.pushState("object or string", "Title", UrlLink);
			//ajax actions	
			$.fn.ajax.ajax_form_boiler_plate( $(this), UrlLink,'','_AJAX_PAGINATION' );
		}
	}
	
	/*************************************************/
	//Utils
	/************************************************/
	$.fn.utils = function ( options ){
		return this;
	}
	
	$.fn.utils.bin2hex = function (mystr){
		
		var str_len = mystr.length; //alert(str_len);
		var converted_str='', code='';
		for(var i =0; i<str_len ; i++){
			//console.log(mystr[i]);
			code = mystr.charCodeAt(i).toString(16); //console.log(code);
			converted_str = converted_str+code;
		}
		//console.log(converted_str);
		return converted_str;
	}
	
	$.fn.utils.is_empty_value = function (value){
		var bool = false;
		
		var value_len = value.trim().length; //console.log('value_len='+value_len);
		if(value_len === undefined || value_len == 0){
			//console.log('field is empty');
			bool = true;
		} else {
			//console.log('field value='+value);
		}	
		
		return bool;
	}
	
	$.fn.utils.retrieve_form_value = function(name){
		//console.log(name);
		var Elem = $('[name="'+name+'"]');
		var value='';
		value = Elem.val(); //console.log(value);
		return value;
	}
	$.fn.utils.monthDiff = function (d1, d2) {
		
		//console.log(d1);
		//console.log(d2);
		
		var months;
		months = (d2.getFullYear() - d1.getFullYear()) * 12; 
		months -= d1.getMonth() + 1;
		months += d2.getMonth(); //console.log('months='+months);
		
		if(months<0){
			months = 1;
		} else {
			months = months + 2;
		} 
	
		//console.log('months='+months);
		return months;
		//return months <= 0 ? 0 : months;
	}	
	//dialog box
	$.fn.utils.dialog_box = function ( msg ){
		confirm(msg);
	}
	
	$.fn.ErrorMessage = function ( ErrorMsg ){
		ErrorMsg = '<span class="_ERRORMSG">'+ErrorMsg+'</span>';
		return ErrorMsg;
	}	
	$.fn.utils.appendErrorMsg = function ( Elem, ErrorMsg , name ){
		var ErrorName = '_ERR'+name; //console.log(ErrorName);					
		Elem.closest('div._CELL').children('span._ERRORMSG').detach();
		Elem.closest('div._CELL').addClass('_ERROR').append('<span class="_ERRORMSG" name="'+ErrorName+'">"'+ErrorMsg+'"</span>');					
	}
	$.fn.utils.removeErrorMsg = function ( Elem ){
		Elem.closest('div._CELL').find('span._ERRORMSG').detach();
		Elem.closest('div._CELL').removeClass('_ERROR').closest( 'div._CELL' ).removeClass('_ERROR');					
	}
	
	$.fn.utils.check_illegal_input = function ( Elem, str ){
		//Scan UrlLink for illegal string
		var Error = false;
		var matches = $.fn.utils.parse_regex( str , /([\<\>])/ );
		if (Array.isArray(matches)) {
			//console.log('match '+matches[0]);
			alert('Error : Illegal string');
			//set offender to blank
			Elem.val('');
			Error = true;
		}
		return Error;
	}
	
	$.fn.utils.haveString = function(Patt, SearchStr){
		SearchStr.search(Patt);
		var result = SearchStr.length>0 ? true : false ;
		return result;
	}
	$.fn.utils.haveRights = function ( Patt ,FSID ){
		var Patt, str;
		FSID = FSID.replace('.','_');
		str = $('form[id="'+FSID+'"]').attr('data-ops'); 
		return $.fn.utils.haveString (Patt, str);
	}

	$.fn.utils.form_UniqueFormID = function ( FSID , Header ){
		var ID;
		ID = Header+FSID;
		ID = ID.replace('.','_');	
		//alert(ID);
		return ID;
	}
	$.fn.utils.form_UniqueAJAXID = function ( FSID ){ 
		//alert( $.fn.utils.form_UniqueFormID( FSID , 'AJAX_') );
		return AJAXID = $.fn.utils.form_UniqueFormID( FSID , 'AJAX_');
	}
	$.fn.utils.get_FSID = function( Target ){
		//Find <form data-fsid=''> where FSID is stored.
		var FSID = Target.closest('form').attr('data-fsid');
		//alert(FSID);
		return FSID;
	}
	$.fn.utils.set_input_change = function ( _this ){	
		
		name = _this.attr("name");		
		change = false;
		//$('.clearfix').append('type:'+_type);
		//_class = _this.attr('class'); alert(_class);
		
		var change = $.fn.utils.check_input_change ( _this );	
		change===true ? _this.attr('_INPUT_CHANGED', true) :  _this.attr('_INPUT_CHANGED', false);
		
		if(_this.attr('_INPUT_CHANGED')==='false') {
			$('input[name="'+name+'"]').removeAttr('_INPUT_CHANGED');
		}
	}

	$.fn.utils.get_CHKED_input_info = function( name ){

		var fsid, matches;
		var patt = /(\[)([a-zA-Z0-9].+)(\])/;  
		matches = $.fn.utils.parse_regex(name , patt);
		
		//$('.clearfix').append(matches.toString());
		//$('.clearfix').append('-->'+matches[2]);	
		if (Array.isArray(matches)) fsid = matches[2];
		return fsid;		
	}
	//get FSID from input[name]
	$.fn.utils.get_FSID_from_input = function( name ){
		
		/*Parse html 'name' attr to get fsid's index. The index is query table's primary key*/
		var fsid, matches;
		var patt = /(\[)([a-zA-Z0-9].+)(\]\[)/;  
		matches = $.fn.utils.parse_regex(name , patt);
		
		//$('.clearfix').append(matches.toString());
		//$('.clearfix').append(matches[2]);	
		if (Array.isArray(matches)) fsid = matches[2];
		return fsid;
	}
	
	$.fn.utils.get_FSID_index_from_input = function( name){

		var fsid, fsid_index, matches;
		
		fsid = $.fn.utils.get_FSID_from_input(name); //alert(fsid);
		//fsid = 'a.1a.111';
		var patt = /([a-zA-Z0-9]+)(\.)([a-zA-Z0-9]+)(\.)([a-zA-Z0-9]+)/; 
		matches = $.fn.utils.parse_regex(fsid , patt);
		
		//$('.clearfix').append(matches.toString());
		//$('.clearfix').append(matches[5]);	

		if(matches!==null) {
			if (Array.isArray(matches)) fsid_index = matches[5];
			//$('.clearfix').append(matches[5]);
		} else {
			fsid_index = null;
			//$('.clearfix').append('Null matches');
		}
		
		return fsid_index;
	}
	
	$.fn.utils.parse_regex = function ( str , patt ){
		
		var str;
		var m;
		if ((m = patt.exec(str)) !== null) {
			if (m.index === patt.lastIndex) {
				//console.log(index);
				patt.lastIndex++;
			}
			// View your result using the m-variable.
			// eg m[0] etc.
			
		}
		return m;
	}
	
	//get input default values and see if input has changed
	$.fn.utils.check_input_change = function ( _this ){
		
		ID = _this.attr("ID"); //alert(ID);
		_type = _this.prop( 'type' ); //alert(_type);
		name = _this.attr("name");
		var change = false;
		switch( _type ){
			case 'text':
				dvalue = _this.prop( 'defaultValue' );
				value = _this.val();
				//alert(value+'--'+dvalue);
				
				if(dvalue!==value){
					//alert('text has changed');
					change = true;
				}
			break;
			
			case 'checkbox':
				//alert( 'defaultChecked:'+_this.prop( 'defaultChecked' ) );
				//alert( 'checked:'+_this.prop( 'checked' ) );
				
				if( _this.prop( 'defaultChecked' )!== _this.prop( 'checked' ) ){
					//alert('checkbox has changed');
					change = true;
				}
				
			break;
			
			case 'select-one':
				
				//alert(ID);
				var eleID = document.getElementById(ID);
				if (!eleID.options[eleID.selectedIndex].defaultSelected) {
					//alert(ID+" has changed");
					change = true;
				}

			break;
			
			case 'radio':
				var eleID = document.getElementById(ID);
				if (eleID.checked != eleID.defaultChecked)  {
					//alert(_this.attr("name")+" has changed");
					change = true;
				}
				
			break;
			
		}
		//alert(change);
		return change;
		
	}
	
	/* data_dyn_single_disable */
	//trigger_name : this element will not be affected by disabled action
	//trigger_data_name : refers to attribute data_name embedded by the system.
	//other_data_name : the other element to be disabled
	//do_disable : true | set to disabled, false or empty | do nothing. 
	//Will append 'data-dyn-disable' to prevent the disabled status from being cloned by sys_ui js method.
	//*** $.fn.utils.data_dyn_single_disable = function(trigger_name ,other_data_name, do_disable=true){
	$.fn.utils.data_dyn_single_disable = function(trigger_name ,other_data_name, do_disable){
		//alert(do_disable); 
		if(do_disable==undefined) do_disable=true;
		var Elem;
		var trigger_data_name = $('[name="'+trigger_name+'"]').attr('data-name'); //console.log('trigger_data_name = '+trigger_data_name);
		
		if( trigger_data_name!== undefined && other_data_name!='' ){
			
			other_name = trigger_name.replace(trigger_data_name,other_data_name); //console.log('other_name = '+other_name);
			other_id = $('[name="'+other_name+'"]').attr('id');
			//Process the following elements
			if(do_disable===true) {
				$('#'+other_id).prop('disabled', do_disable).attr('data-dyn-disable','true');
			} else {
				$('#'+other_id).prop('disabled', false).attr('data-dyn-disable','');
				
				Elem = $('[name="'+trigger_name+'"]');
				$.fn.utils.remove_error_html(Elem);
				//console.log('trigger_name='+trigger_name); //alert(trigger_name);
			}
		} else {
			alert('Error: $.fn.utils.data_dyn_single_disable has empty values.');
		}
		
	}
	
	$.fn.utils.remove_error_html = function (Elem){
		Elem.removeClass('_ERROR').attr('title','').closest('div._CELL').removeClass('_ERROR').closest( 'div._CELL' ).removeClass('_ERROR');
		Elem.siblings('._ERRORMSG').detach();
	}
	//***$.fn.utils.data_dyn_multiple_disable = function(trigger_name ,other_data_names=[], do_disable=true){
	$.fn.utils.data_dyn_multiple_disable = function(trigger_name ,other_data_names, do_disable){
		if(do_disable==undefined) do_disable=true;
		if(other_data_names==undefined) other_data_names=[];
		var other_data_name;
		
		if( $.fn.utils.isArray(other_data_names) ) {
			//alert('is array!');
			
			arrLen = other_data_names.length;
			for (i = 0; i < arrLen; i++) {
				other_data_name = other_data_names[i]; //console.log(trigger_name+' - '+other_data_name);
				//call single func
				$.fn.utils.data_dyn_single_disable(trigger_name,other_data_name);
			} 
			
		} else {
			alert('Error: $.fn.utils.data_dyn_multiple_disable 2nd agv is not array.');
		}
		
	}
	
	$.fn.utils.isArray = function(test_arr) {
		return test_arr.constructor.toString().indexOf("Array") > -1;
	}
	//TO OUTPUT TEST RESULTS
	//***$.fn.output_test = function ( Output , On=true, Mode='append' ){
	$.fn.output_test = function ( Output , On , Mode){
		if(On==undefined) On=true;
		if(Mode==undefined) Mode='append';
		if(On){
			//$('.JS_TEST').detach();
			if($('.JS_TEST').length==0) {
				
					$('body').prepend('<div class="JS_TEST"><button class="btn btn-sm pull-right _DEBUG_CLEAR" type="button"><i class="fa fa-trash-o"></i></button><span></span></div>');
			}
			if(Mode==='append') $(".JS_TEST span").append( Output);	
			if(Mode==='html') $(".JS_TEST span").html( Output);	
			$('._DEBUG_CLEAR').on("click", function(){
				$('.JS_TEST span').html('');
			});
		}

	}
	/*************************************************/
	//validate
	/************************************************/	
	$.fn.validate = function(options) { 
		
		var protected_settings = {
			error_plugin_setup: function ( msg ){
				alert(msg);
			}
		};
		
		var settings = $.extend( {}, $.fn.validate.defaults, options );
		
			switch( settings.check_type ){
				case 'change':
					return this.on(settings.event, function(){
						if( $(this).attr('class')!=='_GOTO'){
							$(this).utils.set_input_change( $(this) ); 
							
						}

					});
				break;
				
				case 'blank':
					return this.on(settings.event, function(){
						this.value.trim()!=='' ? settings.success.call(this) : settings.error.call(this);
					});
				break;
				
				default: 
					return this.on(settings.event, function(){
						protected_settings.error_plugin_setup.call(this, 'Missing "check_type" in "validate" plugin setup');
					});			
			}
		
		

	};
	$.fn.validate.defaults = {
		event : "change",
		check_type: 'change',
		success: function() {
			alert('Success int!');
		},
		error: function() {
			alert('Invalid int!');
		}

	};
	
	//Count the number of changed fields
	$.fn.validate.count_input_changed = function (){
			//Loop thru all inputs to find attr '_INPUT_CHANGED'
				var test_len = 0;
				var _attr;
				 
				$('input, select').each(function(){		

					_attr = $(this).attr('_INPUT_CHANGED');
					if (typeof _attr !== typeof undefined && _attr !== false && $(this).hasClass('_GOTO')!==true) {
						if($(this).attr('_INPUT_CHANGED')==='true'){
							test_len = test_len + 1;
							//alert( $(this).attr('name') );
						}
					}
					
				});
				
			$('body').attr('len',test_len);		
			
		return test_len;
	}
	$.fn.jqcal = function (){
		
	}
	//***$.fn.jqcal.ini = function ( Elem='' ){
	$.fn.jqcal.ini = function ( Elem ){
		
		if(Elem==undefined) Elem='';
		//console.log( Elem.attr('class'));
		var dateObj = new Date();
		var CurYr = dateObj.getFullYear();  
		var EndYr=CurYr+1; 
		
		var minYr = '';
		var minMth = '';
		var minDay = '';
		var maxYr = '';
		var maxDay = '';
		var maxMth = '';
		
		//Set yr range
		var YrRange=String(CurYr)+":"+String(EndYr);
		
		if(Elem!==''){

		}
		
		if(Elem===''){
			//console.log('normal load up');
			//Classic view
			$.fn.jqcal.ymdFormat( $("._DATE, ._DATE_M_Y,  ._DATESTART, ._DATEEND") );	
			//User only selects month and year with a set YrRange set via the settings
			$.fn.jqcal.select_mm_yr( $( "._DATEEND_M_Y" ) , YrRange , 'LastDayofMonth', true );
			//User only selects month and year with a set YrRange. Date is defaulted to first day of the month
			$.fn.jqcal.select_mm_yr ( $( "._DATE_M_Y, ._DATESTART_M_Y" ) , YrRange, 'FirstDayofMonth', true);
			
					
		} else {
			//console.log('thin this is for ajax..');
			if( Elem.hasClass('_DATE') || Elem.hasClass('_DATESTART') || Elem.hasClass('_DATEEND') ){
				$(Elem).jqcal.ymdFormat( Elem ,minYr,minMth,minDay,maxYr,maxMth,maxDay) ;
			}
			if( Elem.hasClass('_DATEEND_M_Y') ){
				$.fn.jqcal.select_mm_yr( Elem , YrRange , 'LastDayofMonth', true) ;
			}
			if( Elem.hasClass('_DATE_M_Y') || Elem.hasClass('_DATESTART_M_Y') ){
				$.fn.jqcal.select_mm_yr ( Elem , YrRange, 'FirstDayofMonth', false);
			}
			
		}
		//Disables the calendar view
		//$.fn.jqcal.disable_cal_view( $("._DATE_M_Y, ._DATESTART_M_Y, ._DATEEND_M_Y") );	
		$.fn.jqcal.enable_cal_view( $("._DATE,  ._DATESTART, ._DATEEND") );	
		
		
 
	}
	//***$.fn.jqcal.select_mm_yr = function ( Elem, YrRange, SetDay='LastDayofMonth', showBtn=true){
	$.fn.jqcal.select_mm_yr = function ( Elem, YrRange, SetDay, showBtn){
			
			if(showBtn==undefined) showBtn=true;
			if(SetDay==undefined) SetDay='LastDayofMonth';
			
			var dateObj = new Date();
			var CurYr = dateObj.getFullYear();
			//retrieve for minDate
			var minYr =CurYr;
			var minMth ='1';
			var minDay ='1';
			var date_min_attr = Elem.attr('datepicker-date-min'); //console.log('date_min_attr='+date_min_attr);
			if (typeof date_min_attr !== typeof undefined && date_min_attr !== false) {
				var d = new Date(date_min_attr);
				minYr = d.getFullYear(); //console.log(minYr);
				minMth = d.getMonth(); //console.log(minMth);
				minDay = d.getDate(); //console.log(minDay);
			}
			
			//retrieve for maxDate
			var today = new Date();
			var curyear = today.getFullYear(); 
			
			var maxYr = Number(curyear) + 50;
			var maxMth ='1';
			var maxDay ='1';
			var date_max_attr = Elem.attr('datepicker-date-max'); //console.log(date_max_attr);
			if (typeof date_max_attr !== typeof undefined && date_max_attr !== false) {
				var d = new Date(date_max_attr);
				maxYr = d.getFullYear();// console.log(maxYr);
				maxMth = d.getMonth(); //console.log(maxMth);
				maxDay = d.getDate(); //console.log(maxDay);
			}	
		//if (typeof datepicker !== 'undefined' && $.isFunction(datepicker)) {
			Elem.datepicker({
				changeMonth: true,
				changeYear: true,
				showButtonPanel: showBtn,
				//yearRange: YrRange,//'2015:2018',
				dateFormat: 'yy-mm-dd',	
				minDate: new Date(minYr, minMth , minDay),
				maxDate: new Date(maxYr, maxMth ,maxDay),

				
			}).focus( function(){
				//console.log('focus');
				var _name = $(this).attr('name'); //console.log(_name);
				var CurrElem = $('[name="'+_name+'"]');
				
				 //$('.ui-datepicker-close').on("click",function(){
					var month = $("#ui-datepicker-div .ui-datepicker-month :selected").val(); 
					var year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
					var date = new Date(year, month);  //console.log( date);
					switch(SetDay){
						
						case 'LastDayofMonth':
							var DaySet = new Date(date.getFullYear(), date.getMonth() + 1, 0); 
							DaySet = DaySet.getDate();
						break;
						
						case 'FirstDayofMonth':
							var DaySet = 01;
						break;
					}
					
					CurrElem.datepicker('setDate', new Date(year, month, DaySet)); //console.log( new Date(year, month, DaySet));
					
					$.fn.utils.set_input_change(Elem);
				 //});
			});
		//}

	}
	
	//***$.fn.jqcal.enable_cal_view = function ( Elem='' ){
	$.fn.jqcal.enable_cal_view = function ( Elem ){
		//Disables the calendar view
		Elem.focus(function () {
			$(".ui-datepicker-calendar").show();
			//$("#ui-datepicker-div").css({'margin-top':'237px'});
		});	
	}
	//***$.fn.jqcal.ymdFormat = function ( Elem=''){
	$.fn.jqcal.ymdFormat = function ( Elem){
			//retrieve for minDate
			var dateObj = new Date();
			var CurYr = dateObj.getFullYear();
			var minYr =CurYr;
			var minMth ='1';
			var minDay ='1';
			var date_min_attr = Elem.attr('datepicker-date-min'); //console.log('date_min_attr='+date_min_attr);
			if (typeof date_min_attr !== typeof undefined && date_min_attr !== false) {
				var d = new Date(date_min_attr);
				minYr = d.getFullYear(); //console.log(minYr);
				minMth = d.getMonth(); //console.log(minMth);
				minDay = d.getDate(); //console.log(minDay);
			}
			
			//retrieve for maxDate
			var today = new Date();
			var curyear = today.getFullYear(); 
			
			var maxYr = Number(curyear) + 50;
			var maxMth ='1';
			var maxDay ='1';
			var date_max_attr = Elem.attr('datepicker-date-max'); //console.log(date_max_attr);
			if (typeof date_max_attr !== typeof undefined && date_max_attr !== false) {
				var d = new Date(date_max_attr);
				maxYr = d.getFullYear();// console.log(maxYr);
				maxMth = d.getMonth(); //console.log(maxMth);
				maxDay = d.getDate(); //console.log(maxDay);
			}
		/*			
		if (typeof datepicker !== typeof undefined && $.isFunction(datepicker)) {
			//alert('datepicker exist');
			Elem.datepicker({
				minDate: new Date(minYr, minMth , minDay),
				maxDate: new Date(maxYr, maxMth ,maxDay),
				gotoCurrent: true,
				dateFormat: 'yy-mm-dd',	
				onClose: function(dateText, inst) {
					$.fn.utils.set_input_change(Elem);
				}		
			});
		} else {
			//alert('datepicker does not exist');
		}*/
		Elem.datepicker({
			minDate: new Date(minYr, minMth , minDay),
			maxDate: new Date(maxYr, maxMth ,maxDay),
			gotoCurrent: true,
			dateFormat: 'yy-mm-dd',	
			onClose: function(dateText, inst) {
				$.fn.utils.set_input_change(Elem);
			}		
		});	
		
	}

	/*************************************************/
	//sys_ui
	/************************************************/	
	$.fn.sys_ui = function (){
		
		$.fn.sys_ui.form_processor();
		
		/*
		$("tr td").each(function(){
			if( $(this).hasClass("_HIGHLIGHT")===true ){
				$(this).parent().addClass('_HIGHLIGHT');
			}
		});*/
		
		
		$.fn.jqcal.ini();
		
		//TOOLTIPS
		$('.tooltip-call').tooltip({
			selector: "[data-toggle=tooltip]",
			container: "body"
		});
		/*
		var tooltips= $( "input[title]" ).tooltip({
			position: {
				my: "left top",
				at: "left-0 top-45",						 					 
				using: function( position, feedback ) {
					$( this ).css( position ).addClass( "_ERROR_CONTENT" );
					$( "<div>" )
					.addClass( "arrow" )
					.addClass( feedback.vertical )
					.addClass( feedback.horizontal )
					.appendTo( this );
					}
				},
		});*/
		
		var tooltips_icon= $( "._TOOLBAR [data-toggle=tooltip]" ).tooltip({});
		
		/*$( "<button>" ).text( "Show help" ).button().on("click", function() {
			tooltips.tooltip( "open" );
		}).insertAfter( "form" );*/
			
		
		//PIETY
		if (typeof peity !== 'undefined' && $.isFunction(peity)) {
			$("span.pie").peity("pie", {
				fill: ['#1ab394', '#d7d7d7', '#ffffff']
			});
		}
		
		//http://rocha.la/jQuery-slimScroll
		//if (typeof slimScroll !== 'undefined' && $.isFunction(slimScroll)) {
			$('.full_height_scroll').slimScroll({
				/*position: 'left',*/
				height: 'auto',
				alwaysVisible: true
			});
		//}
		
		$.fn.sys_ui.scroller_clone_header();
		
	}
	/*DESTROY EVENTS LINKED FUNCTIONS*/
	$.fn.sys_ui.destroy = function (){
		$.fn.sys_ui.form_processor_destroy();
	}
	$.fn.sys_ui.scroller_clone_header = function(){
			
			var TargetTable = $('.add_scroller .add_scroller_table'); // retrieve	
			var bool = TargetTable.text!='' ? true : false; //check if present

			if(bool===true){
				
				var clonedtable = TargetTable.clone();
				var table_attr = TargetTable.attr('data-table');
				TargetTable.find('thead').addClass('show_none');
				clonedtable.attr('id',table_attr).removeClass('add_scroller_table').addClass('m-b-none');
				//$('.add_scroller').prepend(clonedtable);
				$('.add_scroller').parent().prepend(clonedtable);
				$('#'+table_attr+' tbody').detach(); //show_none					
			} else {
				//alert('.add_scroller not found.');
			}
		
		}	
	/* CORE SYSTEM FORM PROCESSORS */
	$.fn.sys_ui.form_processor = function (){
		/* Add tr */
		$.fn.sys_ui.add_tr();
		/*Delete related actions*/
		$.fn.sys_ui.delete_checkbox();
		$.fn.sys_ui.delete_tr();
		$.fn.sys_ui.delete_tr_warn();
		$.fn.sys_ui.delete_detach();
	}
	$.fn.sys_ui.form_processor_destroy = function (){
		/* Add tr */
		$.fn.sys_ui.add_tr_destroy();
		/*Delete related actions*/
		$.fn.sys_ui.delete_checkbox_destroy();
		$.fn.sys_ui.delete_tr_destroy();
		$.fn.sys_ui.delete_tr_warn_destroy();
		$.fn.sys_ui.delete_detach_destroy();
	}


	/* DETACHES TR UPON CLICKING */
	$.fn.sys_ui.delete_detach = function(){
		$('._DELETE_DETACH').on("click",$.fn.sys_ui.delete_detach_func);	
	}
	$.fn.sys_ui.delete_detach_destroy = function(){
		$('._DELETE_DETACH').off("click",$.fn.sys_ui.delete_detach_func);	
	}	
	$.fn.sys_ui.delete_detach_func = function(){
		
		var TargetTR=$(this).parentsUntil('tr').parent();
		var SelectedTable=$(this).closest('table').attr('data-table'); //alert('SelectedTable'+SelectedTable);
		
		TargetTR.detach();
		$.fn.sys_ui.update_tr_counter(SelectedTable);
				
		//Check if delete_detach_func_CALL has been written
		if( $.isFunction( $.fn.sys_ui.delete_detach_func_CALL ) ) $.fn.sys_ui.delete_detach_func_CALL();
	}

	/*FOR ADDING TR*/
	$.fn.sys_ui.add_tr = function (){
		$('._ADD_TR').on("click", $.fn.sys_ui.add_tr_func );		
	}
	$.fn.sys_ui.add_tr_destroy = function (){
		$('._ADD_TR').off("click", $.fn.sys_ui.add_tr_func );		
	}
	/*Function call back for $.fn.sys_ui.add_tr */
	$.fn.sys_ui.add_tr_func = function(){
		var TargetTR=$(this).closest('tr'); //.css({'background-color':'red'});
		//var TargetTR_Counter = $(this).closest('tr').attr('data-counter'); console.log(TargetTR_Counter);
			
		var cloned = TargetTR.clone(true); 
		
		//cloned.children('td').children('._CELL').children('._DATA').attr('name','').attr('id','').val('');
		cloned.children('td').children('._CELL').children('._DATA').each(function(){
			if( $(this).is(':checkbox')===true || $(this).is(':radio')===true){
				//is checkbox or radio
				$(this).attr('name','').attr('id','').prop("checked", false);
			} else {
				//other input types
				$(this).attr('name','').attr('id','').val('');
				
				if( $(this).attr('data-dyn-disable')=='true' ){
					//alert(name);
					$(this).prop("disabled", false).attr('data-dyn-disable','');
				}
			}
		});
		


		cloned.children('td').children('input._DYN_DELETE').attr('data-code','C1');
		cloned.attr('class','');
		
		//Remove error attributes from cloned form.
		cloned.children('td').children('._CELL').children('._DATA').removeClass('_ERROR');
		cloned.children('td').children('._CELL').removeClass('_ERROR');
		cloned.children('td').children('._CELL').children('._ERRORMSG').detach();
		
		
		cloned.insertAfter(TargetTR);
			
		var SelectedTable=$(this).closest('table').attr('data-table');
		//alert(SelectedTable);
		$.fn.sys_ui.update_tr_counter(SelectedTable);
		
		//for testing purposes... $('<input type="text" class="_DATESTART "/>').insertAfter('h1'); $.fn.sys_ui.jqcal_ymd();
			
	}
	/*FOR DELETEING TR (WITHOUT WARNING DIALOG)*/
	 $.fn.sys_ui.delete_tr = function(){
		$('._DELETE_TR').on("click", $.fn.sys_ui.delete_tr_func);
		
	}	
	$.fn.sys_ui.delete_tr_destroy = function(){
		$('._DELETE_TR').off("click", $.fn.sys_ui.delete_tr_func);
		
	}
	 $.fn.sys_ui.delete_tr_func = function(){

			//console.log('sys_ui.delete_tr');
			var TargetTR=$(this).parentsUntil('tr').parent(); 
			//var TargetTR_Counter = $(this).closest('tr').attr('data-counter'); console.log('delete: '+TargetTR_Counter);			
			TargetTR.detach();
			var SelectedTable=$(this).closest('table').attr('data-table'); //console.log('('SelectedTable'+SelectedTable);
			$.fn.sys_ui.update_tr_counter(SelectedTable);

		
	}	
	/*FOR DELETEING TR (WITH WARNING DIALOG)*/
	$.fn.sys_ui.delete_tr_warn = function (){
		$('._DELETE_TR_WARN').on("click", $.fn.sys_ui.delete_tr_warn_func );
		
	}
	$.fn.sys_ui.delete_tr_warn_destroy = function (){
		$('._DELETE_TR_WARN').off("click", $.fn.sys_ui.delete_tr_warn_func );
		
	}
	$.fn.sys_ui.delete_tr_warn_func = function (){
			var TargetTR=$(this).parentsUntil('tr').parent();
			TargetTR.detach();
		
	}	
	/* DELETE CHECKBOX ACTIONS */
	$.fn.sys_ui.delete_checkbox = function (){
		//This version is preferred as this is <label> compatible.
		//To get this version to work, user must really click on the check box and not the .fa icon like the DELETE_CHKBOX_BACKUP() version.
		//Hence, must use CSS position absolute to place checkbox above the .fa icon while setting opacity of checkbox to 0.
		
		$('._DYN_CHKBOX_LABEL').on("click", $.fn.sys_ui.delete_checkbox_func);		
	}
	$.fn.sys_ui.delete_checkbox_destroy = function (){
		$('._DYN_CHKBOX_LABEL').off("click", $.fn.sys_ui.delete_checkbox_func);		
	}
	$.fn.sys_ui.delete_checkbox_func = function (){

			//console.log('sys_ui.delete_checkbox');
			if($(this).attr('data-code')=='C1'){
						
				$(this).parentsUntil('tbody').detach();				
				
			} else {
				//alert($(this).attr('name'));
				$(this).closest('tr').toggleClass('dyn_delete_marked');			

			}
		
	}
	/* UPDATE COUNTERS */
	$.fn.sys_ui.update_tr_counter = function (SelectedTable){
		var counter=0;

		$('table[data-table='+SelectedTable+'] tbody tr').each( function(){ 
			//console.log(counter);
			//Update TR COUNTER													  
			//if( $(this).attr('data-counter')!= undefined ){
				/*
				The above line was commented off due to complain that add new vehicle set up would cause the counter not to be updated. - Aug 5th 2016
				*/
				//alert( $(this).attr('data-counter') );
				$(this).attr('data-counter',counter); 
				//console.log('counter'+counter); 				
				//console.log($(this).html());
				
				$.fn.sys_ui.update_tr_td(SelectedTable,counter);
				counter++;
			//} 

		});
		
		//$.fn.sys_ui.update_tr_td (SelectedTable,'restofdata'); //mm....it didn't work..i need to get back to this..	
	}
	/* UPDATE COUNTERS TD */
	//***$.fn.sys_ui.update_tr_td = function (SelectedTable, counter=''){
	$.fn.sys_ui.update_tr_td = function (SelectedTable, counter){
		
		$('table[data-table='+SelectedTable+'] tbody tr[data-counter='+counter+'] td ._CELL ._DATA').each( function(){
			$(this).attr('data-pos',counter); //console.log('data-pos'+$(this).attr('data-pos')); 
			
			//console.log('id->'+$(this).attr('id'));
				//console.log($(this).html()); 
				var pos = $(this).attr('data-pos'); 
				//console.log(pos);
				//console.log($(this).attr('data-f'));
				var newname = $(this).attr('data-f').concat(pos,']');  //console.log('newname'+newname);
				newname = newname.replace(']'+pos+']', pos+']'); //console.log('newname'+newname);
				//var newid = newname; // newname.replace(/\./g,"_"); // console.log(newid); 
				var newid =$(this).utils.bin2hex(newname);

			
			if($(this).attr('name')==''){ 
			
				//console.log($(this).attr('id'));
				$(this).attr('name', newname ); //console.log($(this).attr('data-f')); 
				$(this).attr('id', newid ); //console.log($(this).attr('data-f')); 
					
				$(this).datepicker('destroy').jqcal.ymdFormat( $(this) );
				$(this).datepicker('destroy').jqcal.ini( $(this) );
				
			} else { 
			
				//console.log($(this).attr('id'));
				pos = $(this).attr('data-pos'); 
				var name = $(this).attr('name');
				var n = name.lastIndexOf('#');
				//console.log(name+'--->'+n);
				var name_tmp = name.slice(0,Number(n)+1).concat(pos,']');
				//console.log(name_tmp);
				$(this).attr('name', name_tmp ); //console.log($(this).attr('data-f')); 
				var id_tmp = $(this).utils.bin2hex(name_tmp); //name_tmp.replace(/\./g,"_"); //console.log(id_tmp);
				$(this).attr('id', id_tmp ); //console.log($(this).attr('data-f')); 
				//$(this).datepicker('destroy').jqcal.ymdFormat( $(this) );
				$(this).datepicker('destroy').jqcal.ini( $(this) );
				
				
				
			}
		});
	}
	//***$.fn.sys_ui.update_tr_td_BACK_REFINE_LATER = function (SelectedTable, counter=''){
	$.fn.sys_ui.update_tr_td_BACK_REFINE_LATER = function (SelectedTable, counter){
		
		
		if(counter!=='restofdata'){
			$('table[data-table='+SelectedTable+'] tbody tr[data-counter='+counter+'] td ._CELL ._DATA').each( function(){
				$(this).attr('data-pos',counter); //console.log('data-pos'+$(this).attr('data-pos')); 
			});
		} else { 
			$('table[data-table='+SelectedTable+'] tbody tr td ._CELL ._DATA').each( function(){ 
				
				//console.log('id->'+$(this).attr('id'));
				//console.log($(this).html()); 
				var pos = $(this).attr('data-pos'); 
				//console.log(pos);
				//console.log($(this).attr('data-f'));
				var newname = $(this).attr('data-f').concat(pos,']');  //console.log('newname'+newname);
				//newname = newname.replace(']'+pos+']', pos+']'); //console.log('newname'+newname);
				var newid = newname; // newname.replace(/\./g,"_"); // console.log(newid);
				
				if($(this).attr('name')==''){ 
					//console.log($(this).attr('id'));
					$(this).attr('name', newname ); //console.log($(this).attr('data-f')); 
					$(this).attr('id', newid ); //console.log($(this).attr('data-f')); 
					
					//$(this).datepicker('destroy').jqcal.ymdFormat( $(this) );
					$(this).datepicker('destroy').jqcal.ini( $(this) );
				} else { 
					//console.log($(this).attr('id'));
					pos = $(this).attr('data-pos'); 
					var name = $(this).attr('name');
					var n = name.lastIndexOf('#');
					//console.log(name+'--->'+n);
					var name_tmp = name.slice(0,n+1).concat(pos,']');
					//console.log(name_tmp);
					$(this).attr('name', name_tmp ); //console.log($(this).attr('data-f')); 
					var id_tmp = name_tmp; //name_tmp.replace(/\./g,"_"); //console.log(id_tmp);
					$(this).attr('id', id_tmp ); //console.log($(this).attr('data-f')); 
					//$(this).datepicker('destroy').jqcal.ymdFormat( $(this) );
					$(this).datepicker('destroy').jqcal.ini( $(this) );
				}
				
			});
		
		}		
	}
	
	
})(jQuery);
$(document).ready(function(){	
	//System initialise
	$(this).systemINI();

});