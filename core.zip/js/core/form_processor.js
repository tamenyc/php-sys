// JavaScript Document
$(document).ready(function () {
	
	/*DYNAMIC TABLE OPERATIONS*/
	TR_ADD_DELETE();
	//INPUT_DATEPICKER();
	
	/*CART OPERATIONS*/
	GRANDTOTALPRICE();
	
	$('._DELETE_TR_WARN').on("click",function(){
		ConfirmDialog("Confirm deletion?");										  
	});	
	
});
/***********GRANDTOTALPRICE**********************************/
function GRANDTOTALPRICE(){
	//Sum all _CartItemPrice
	var TotalPrice=0;
	$('._CartItemPrice').each(function(){
		var curItemPrice=$(this).attr('data-item-price');	//alert(curItemPrice);
		TotalPrice = TotalPrice + parseInt(curItemPrice);							   
	});
	$('#_CartGrandTotal').text(TotalPrice);
	
}

/***********DATEPICKER UI**********************************/
/*
function INPUT_DATEPICKER(){
	$( "._DATESTART" ).datepicker();
	$( "._DATEEND" ).datepicker();
}
*/

/*************FOR CLONING TR*******************************/
function TR_ADD_DELETE(){
	ADD_TR();
	DELETE_CHKBOX();
	//DELETE_TR();
	DELETE_TR_WARN();
	DELETE_DETACH();
}

function ADD_TR(){
	$('._ADD_TR').on("click",function(){
		var TargetTR=$(this).parentsUntil('tr').parent();
		var $cloned = TargetTR.clone(true);
		$cloned.children('td').children('._CELL').children('._DATA').attr('name','').attr('id','').attr('value','');
		$cloned.children('td').children('input._DYN_DELETE').attr('data-code','C1');
		$cloned.attr('class','');
		$cloned.insertAfter(TargetTR);
		var SelectedTable=$(this).parentsUntil('table').parent().attr('data-table');
		//alert(SelectedTable);
		UPDATE_TR_COUNTER(SelectedTable);
	});
}
/*CHECKBOX DELETE */
function DELETE_CHKBOX_BACKUP(){
	//This version works for delete checkbox not wrapped in <label>
	//This will select respective delete checkbox when the .fa icon is clicked using JS.
	$('._DYN_DELETE').on("click",function(){
		//This works without the label..strange...
		if($(this).attr('data-code')=='C1'){
			$(this).parentsUntil('tbody').detach();
		} else {
			//alert($(this).attr('name'));
			$(this).closest('tr').toggleClass('dyn_delete_marked');
			
			var name = $(this).attr('id');
			if ($('input[name="'+name+'"]').prop('checked')) {
				$('input[name="'+name+'"]').prop('checked',false);
				$('.clearfix').append('unchecked');
			} else {
				$('.clearfix').append('nah');
				$('input[name="'+name+'"]').prop('checked',true);
			}

		}
		
		
	});

}
function DELETE_CHKBOX(){
	//This version is preferred as this is <label> compatible.
	//To get this version to work, user must really click on the check box and not the .fa icon like the DELETE_CHKBOX_BACKUP() version.
	//Hence, must use CSS position absolute to place checkbox above the .fa icon while setting opacity of checkbox to 0.
	$('._DYN_DELETE_LABEL').on("click",function(){
		
		if($(this).attr('data-code')=='C1'){
			$(this).parentsUntil('tbody').detach();
		} else {
			//alert($(this).attr('name'));
			$(this).closest('tr').toggleClass('dyn_delete_marked');
			

		}
		
		
	});


}
/*FOR DELETEING TR*/
function DELETE_TR(){
	$('._DELETE_TR').on("click",function(){
		var TargetTR=$(this).parentsUntil('tr').parent();
		TargetTR.detach();
	});
	
}

function DELETE_DETACH(){
	$('._DELETE_DETACH').on("click",function(event){
		var TargetTR=$(this).parentsUntil('tr').parent();
		TargetTR.detach();
	});
	
}

/*FOR DELETEING TR*/
function DELETE_TR_WARN(){
	$('._DELETE_TR_WARN').on("click",function(event){
		var TargetTR=$(this).parentsUntil('tr').parent();
		TargetTR.detach();
		GRANDTOTALPRICE();
	});
	
}

function UPDATE_TR_COUNTER(SelectedTable){
	var counter=0;

	$('table[data-table='+SelectedTable+'] tr').each( function(){ 
		//Update TR COUNTER													  
		if( $(this).attr('data-counter')!= undefined ){
			//alert( $(this).attr('data-counter') );
			$(this).attr('data-counter',counter);
			UPDATE_TR_TD(SelectedTable,counter);
			counter++;
		}
	});
	
	UPDATE_TR_TD(SelectedTable,'restofdata');
}
function UPDATE_TR_TD(SelectedTable,counter){
	
	if(counter!=='restofdata'){
		$('table[data-table='+SelectedTable+'] tr[data-counter='+counter+'] td ._CELL ._DATA').each( function(){
			$(this).attr('data-pos',counter); //console.log($(this).attr('data-pos')); 
		});
	} else { 
		$('table[data-table='+SelectedTable+'] tr td ._CELL ._DATA').each( function(){ 
			//console.log($(this).attr('id'));
			var pos = $(this).attr('data-pos'); 
			//console.log(pos);
			var newname = $(this).attr('data-f').concat(pos,']');
			
			if($(this).attr('name')==''){ 
				//console.log($(this).attr('id'));
				$(this).attr('name', newname ); //console.log($(this).attr('data-f')); 
				$(this).attr('id', newname ); //console.log($(this).attr('data-f')); 
			} else { 
				//console.log($(this).attr('id'));
				pos = $(this).attr('data-pos'); 
				var name = $(this).attr('name');
				var n = name.lastIndexOf('#');
				//console.log(name+'--->'+n);
				var name_tmp = name.slice(0,n+1).concat(pos,']');
				console.log(name_tmp);
				$(this).attr('name', name_tmp ); //console.log($(this).attr('data-f')); 
				$(this).attr('id', name_tmp ); //console.log($(this).attr('data-f')); 
				
			}
			
		});
		
	}

	
}
