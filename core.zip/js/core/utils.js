// JavaScript Document
$(document).ready(function () {
						
});
function ConfirmDialog(msg){
	var msg;
	if(msg=="") msg="Confirm deletion";
	
	if(confirm(msg)==true){
		return true;
	}
	else{
		return false;
	}
}//ConfirmDialog