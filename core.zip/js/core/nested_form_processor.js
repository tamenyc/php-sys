// JavaScript Document
$(document).ready(function () {
	
	//For ._ADD action
	AddRow();
	//For ._DELETE action
	DeleteRow();
	//move up
	MoveRowUp();
	//move down
	MoveRowDown();
	
	//removes _DIV_O without input fields inside
	//this is a patch needed to compliment what php generator function failed to do; 
	//That is not to prive _DIV_O without any inputs inside
	CleanUpZone_Patch();
	
	
});
 
function CleanUpZone_Patch(){	
	$('div[div_type="_DIV_O"]').each(function(){
		//var divDataSet=$(this).attr("data-set");
		var divStringPrev=$(this).attr("data-stringprev");
				
		if(!$(this).children().hasClass('_FOMRIP') && divStringPrev!="") { 
			//console.log( divName+"-"+divStringPrev);	
			$(this).detach();
		}
	});
}

function MoveRowUp(){
	$('._MOVEUP').on("click",function(){
		$(this).parent().insertBefore($(this).parent().prev());	
		LoopDataUpdate($(this).parent().attr("data-set"));
	});
}

function MoveRowDown(){
	$('._MOVEDOWN').on("click",function(){
		$(this).parent().insertAfter($(this).parent().next());	
		LoopDataUpdate($(this).parent().attr("data-set"));
	});
}


function DeleteRow(){
	$('._DELETE').on("click",function(){
		$(this).parent().detach();		
		LoopDataUpdate($(this).parent().attr("data-set"));
	});
}

function AddRow(counter){

	$('._ADD').on("click",function(){ 
		//get this wrapper Name
		var parentNAME=$(this).parent().attr("name"); //alert(parentNAME);
		
		//get main wrapper Name
		var parentMAINNAME=$(this).parent().parent().attr("name");
		
		//CLONE
		$($('div[name="'+parentNAME+'"]')).clone(true).insertAfter($(this).parent());

		
		//console.log( parentMAINNAME);
		LoopDataUpdate(parentMAINNAME);
		
		//CLEARS THE CLONED DATA VALUE
		var nextName=$(this).parent().next().attr("name");
		$('div[name="'+nextName+'"] ._FOMRIP').each(function(){
			$(this).val("");													
		});

	});
	

}

function LoopDataUpdate(parentMAINNAME){
	console.log( parentMAINNAME);
	var localCounter=0;
	$('div[name="'+parentMAINNAME+'"]').children('div').each(function(){

		var getName=$(this).attr("data-name");
		var getPrevString=$(this).attr("data-stringprev");
		var getDataCounter=$(this).attr("data-counter");
		//console.log(localCounter+getDataCounter);
		
		//update if different
		if(localCounter!=getDataCounter){
			$(this).attr("data-counter",localCounter);
			if(getPrevString!=""){
				$(this).attr("name",getPrevString+'['+getName+']['+localCounter+']');
			} else {
				$(this).attr("name",getName+'['+localCounter+']');
			}

		}
		//UPDATE INPUT FIELDS
		//console.log( $(this).children().attr('data-tag') );
		var newName=$(this).attr('name');
		$(this).children('._FOMRIP').each(function(){
			
			var ipName=$(this).attr('data-name');
			//console.log( ipName );
			$(this).attr('name', newName+'['+ipName+']');
		});
		//UPDATE CHILDREN DIV
		$(this).children('div').each(function(){			
			//update
			var thisDataName=$(this).attr("data-name");
			var thisDataCounter=$(this).attr("data-counter");
			$(this).attr("data-stringprev", newName);	
			$(this).attr("name",newName+'['+thisDataName+']['+thisDataCounter+']');
			LoopDataUpdate(newName);
		});
		
		//console.log( getName );
		LoopDataUpdate(getName);
		
		//increment counter
		localCounter=localCounter+1;
		
		//console.log( $(this).children().attr('name'));
	});
	/*$('div[name="'+parentMAINNAME+'"]').children().each(function(){
		$('#topmessages').append($(this).attr('name')+'<br>');
	});*/
}